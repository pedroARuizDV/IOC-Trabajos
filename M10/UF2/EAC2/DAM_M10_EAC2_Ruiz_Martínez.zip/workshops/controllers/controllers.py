# -*- coding: utf-8 -*-
# from odoo import http


# class Workshops(http.Controller):
#     @http.route('/workshops/workshops/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/workshops/workshops/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('workshops.listing', {
#             'root': '/workshops/workshops',
#             'objects': http.request.env['workshops.workshops'].search([]),
#         })

#     @http.route('/workshops/workshops/objects/<model("workshops.workshops"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('workshops.object', {
#             'object': obj
#         })

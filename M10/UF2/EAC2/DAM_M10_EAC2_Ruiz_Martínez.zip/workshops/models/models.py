# -*- coding: utf-8 -*-


from odoo import models, fields, api


class Workshop(models.Model):
     _name = 'workshop.workshop'
     _description = 'Workshop'

     name = fields.Char(String="Name Workshop", required=True)
     workshop_activity = fields.Many2one('workshop.activity')
     workshop_date = fields.Date(String="WorkShop Date", default=fields.Date.today)
     workshop_room = fields.Many2one('workshop.room')
     hours_session = fields.Integer(String='Hours Session', required=True)
     hours_number = fields.Integer('Hours Number', compute='_getHours')
     trainer = fields.Many2one('hr.employee', required=True)
     participants = fields.Many2many('res.partner')
     number_session = fields.Integer('Number Session', compute='_number_sessions')

     def _getHours(self):
         for record in self:
             Activity = record.workshop_activity
             record.hours_number = Activity.getHours

     def _number_sessions(self):
         for record in self:
             hours_s = record.hours_session
             hours_n = record.hours_number
             record.number_session = hours_n / hours_s


class Activity(models.Model):
    _name = 'workshop.activity'
    _description = 'Activity'

    name = fields.Char(String="Name Activity", required=True)
    description = fields.Text(String='Description')
    hours_number = fields.Integer(String='Hours Number', required=True)
    active = fields.Boolean('Active', default=True)

    def name_get(self):
        result = []
        for record in self:
            name = '(' + record.name + ') ' + record.description
            result.append((record.id, name))
        return result

    @property
    def getHours(self):
        return self.hours_number


class Room(models.Model):
    _name = 'workshop.room'
    _description = 'Room class'

    name = fields.Char(String='Room Name', required=True)
    address = fields.Text(String='Room Address', required=True)



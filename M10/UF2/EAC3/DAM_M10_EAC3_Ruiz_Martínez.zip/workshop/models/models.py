# -*- coding: utf-8 -*-

from odoo import models, fields, api
from datetime import timedelta


class activity(models.Model):
    _name = 'workshop.activity'
    _description = 'Activity\'s Database'

    name = fields.Char(size=32, string='Name', index=True, required=True)
    description = fields.Text(string="Description")
    no_hours = fields.Integer(string="Hours number")
    active = fields.Boolean('Active', default=True)

    def name_get(self):
        result = []
        for record in self:
            name = record.name + ' ' + record.description
            result.append((record.id, name))
        return result

class room(models.Model):
    _name = 'workshop.room'
    _description = 'Room\'s Database'

    name = fields.Char(size=32, string='Name', index=True, required=True)
#    description = fields.Text(string="Description")
    adress = fields.Char(size=64, string="Room adress")

class workshop(models.Model):
    _name = 'workshop.workshop'
    _description = 'Workshop\'s Database'

    name = fields.Char(size=32, string='Workshop\'s name',required=True, index=True)
    date = fields.Date('Workshop date')
    no_sessions = fields.Integer(compute='_no_sessions', string="Number of Sessions")
    hours_per_session = fields.Integer(string="Hours per session")
    id_activity = fields.Many2one('workshop.activity', required=True, string="Workshop\'s Activity")
    no_hours = fields.Integer(related='id_activity.no_hours', store=False, string="Hours number")
    id_trainer = fields.Many2one('hr.employee', string="Trainer")
    participants = fields.Many2many('res.partner', string="Participants")
    id_room = fields.Many2one('workshop.room', requiered=True, string="Workshop\'s Room")

    def _no_sessions(self):
        for record in self:
            if record.no_hours%record.hours_per_session == 0:
                record.no_sessions = record.no_hours/record.hours_per_session
            else: record.no_sessions = record.no_hours/record.hours_per_session+1

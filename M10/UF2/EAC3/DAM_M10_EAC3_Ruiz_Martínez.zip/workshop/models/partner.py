from odoo import models, fields

class Partipantes(models.Model):
    _inherit = 'res.partner'

    workshop_id = fields.Many2many('workshop.workshop')




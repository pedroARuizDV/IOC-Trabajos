package esthersanchez.ioc.cat.eac3_p3_sanchez_e;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.drawable.AnimationDrawable;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    AnimationDrawable titolSimpsons;
    ImageView iTitol, iEngVerd, iEngBlau, iEngVermell, iUll, iDonut;
    MediaPlayer audio;
    private Animation animGirarVerd, animGirarVermell, animGirarBlau, animUll, animDonut;
    boolean bInvisible;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        InicialitzacioViews();

    }

    @Override
    public void onWindowFocusChanged(boolean focus) {
        super.onWindowFocusChanged(focus);
        titolSimpsons.start();
    }

    private void InicialitzacioViews() {

        iTitol = findViewById(R.id.simpsonsAnim);
        iEngVerd = findViewById(R.id.verdView);
        iEngBlau = findViewById(R.id.blauView);
        iEngVermell = findViewById(R.id.vermellView);
        iUll = findViewById(R.id.ullView);
        iDonut = findViewById(R.id.donutView);

        ferInvisible();

        iTitol.setBackgroundResource(R.drawable.simpsons_anim);
        titolSimpsons = (AnimationDrawable) iTitol.getBackground();

        animGirarVerd = AnimationUtils.loadAnimation(this, R.anim.anim_girar_verd);
        animGirarVermell = AnimationUtils.loadAnimation(this, R.anim.anim_girar_vermell);
        animGirarBlau = AnimationUtils.loadAnimation(this, R.anim.anim_girar_blau);
        animUll = AnimationUtils.loadAnimation(this, R.anim.anim_ull);
        animDonut = AnimationUtils.loadAnimation(this, R.anim.anim_donut);

        audio = MediaPlayer.create(this, R.raw.the_simpsons);
        audio.setLooping(true);
    }

    private void ferInvisible(){
        bInvisible = true;

        iEngVerd.setVisibility(View.GONE);
        iEngBlau.setVisibility(View.GONE);
        iEngVermell.setVisibility(View.GONE);
        iUll.setVisibility(View.GONE);
        iDonut.setVisibility(View.GONE);
    }

    private void pararAnimacions() {
        iEngVerd.clearAnimation();
        iEngBlau.clearAnimation();
        iEngVermell.clearAnimation();
        iUll.clearAnimation();
        iDonut.clearAnimation();
    }

    private void ferVisible(){
        bInvisible = false;

        iEngVerd.setVisibility(View.VISIBLE);
        iEngBlau.setVisibility(View.VISIBLE);
        iEngVermell.setVisibility(View.VISIBLE);
        iUll.setVisibility(View.VISIBLE);
        iDonut.setVisibility(View.VISIBLE);
    }

    private void iniciarAnimacions() {
        iEngVermell.startAnimation(animGirarVermell);
        iEngVerd.startAnimation(animGirarVerd);
        iEngBlau.startAnimation(animGirarBlau);
        iUll.startAnimation(animUll);
        iDonut.startAnimation(animDonut);
    }

    public void clickTitol(View view) {
        if (bInvisible){
            ferVisibleIniciarAnimacio();
        }else{
            ferInvisiblePararAnimacio();
        }
    }

    private void ferVisibleIniciarAnimacio() {
        ferVisible();
        iniciarAnimacions();
    }

    private void ferInvisiblePararAnimacio() {
        ferInvisible();
        pararAnimacions();
    }

    public void reproduirMusica(View view) {
        if(audio.isPlaying()){
            audio.pause();
        } else{
            audio.start();
        }
    }
}

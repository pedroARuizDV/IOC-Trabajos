package esthersanchez.ioc.cat.eac3_p2_sanchez_esther;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;

import android.Manifest;
import android.annotation.TargetApi;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.util.Locale;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private static final int REQUEST_LOCATION_PERMISSION = 1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        // Obtinc el Fragment i notifico que el mapa està apunt per ser utilitzat
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }

    //Inicialitzacio del mapa quan està apunt per pintar-se
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        // Les coordenades on vull centrar el mapa
        LatLng terrassa = new LatLng(41.55, 1.982);

        // Les coordenades de la feina
        LatLng feina = new LatLng(41.5698, 1.9943);

        // Afegeixo un marcador estàtic
        mMap.addMarker(new MarkerOptions().position(feina).title("feina"));

        // Centro el mapa
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(terrassa, 13f));


        // defineixo el tipus de mapa que vull visualitzar
        mMap.setMapType(GoogleMap.MAP_TYPE_TERRAIN);

        // Habilito la localització del dispositiu
        enableMyLocation(mMap);

        // afegeixo els controls de zoom al mapa
        mMap.getUiSettings().setZoomControlsEnabled(true);

        //Establim el listener del longclik per al mapa
        setMapLongClick(mMap);


    }

    // Afegeix un marcador de color blau al mapa quan l'usuari realitza un clic llarg.
    private void setMapLongClick(final GoogleMap mMap) {

        mMap.setOnMapLongClickListener(new GoogleMap.OnMapLongClickListener() {
            @Override
            public void onMapLongClick(LatLng latLng) {
                String snippet = String.format(Locale.getDefault(),
                        getString(R.string.lat_long_snippet),
                        latLng.latitude,
                        latLng.longitude);

                mMap.addMarker(new MarkerOptions()
                        .position(latLng)
                        .title(getString(R.string.dropped_pin))
                        .snippet(snippet)
                        .icon(BitmapDescriptorFactory.defaultMarker
                                (BitmapDescriptorFactory.HUE_BLUE)));
            }
        });
    }

    //Mostro la meva ubicacó (punt blau) al mapa si tinc permisos
    private void enableMyLocation(GoogleMap map) {

        // Comprovo si tinc permís
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            // habilito la meva localització
            map.setMyLocationEnabled(true);
        } else {
            //Demano els permisos al usuari
            ActivityCompat.requestPermissions(this, new String[]
                            {Manifest.permission.ACCESS_FINE_LOCATION},
                    REQUEST_LOCATION_PERMISSION);
        }
    }


    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        // comprovo si el usuari ha permès activar la localitzacio
        switch (requestCode) {
            case REQUEST_LOCATION_PERMISSION:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED)
                    enableMyLocation(mMap);
                else
                    Toast.makeText(this, getString(R.string.no_permis), Toast.LENGTH_LONG).show();
                break;
        }
    }

    //Mostro la meva ubicació mitjançant un Toast si tinc permisos.
    public void showMyLocation(View view) {

        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) !=
                PackageManager.PERMISSION_GRANTED  ){
            //Com no tinc permisos els demano al usuari
            requestPermissions(new String[]{
                            android.Manifest.permission.ACCESS_FINE_LOCATION},
                    REQUEST_LOCATION_PERMISSION);
            return ;
        }

        //Ja tinc permisos
        LocationManager locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        Location myLocation=locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
        if (myLocation == null)
        {
            myLocation = locationManager.getLastKnownLocation(LocationManager.PASSIVE_PROVIDER);

        }

        double lat = myLocation.getLatitude();
        double lon = myLocation.getLongitude();

        // Mostro la meva ubicació mitjançant un Toast
        String ubicacio = String.format(Locale.getDefault(),
                getString(R.string.ubicacio),
                lat, lon);
        Toast toast = Toast.makeText(getApplicationContext(), ubicacio, Toast.LENGTH_SHORT);
        toast.show();


        }



}

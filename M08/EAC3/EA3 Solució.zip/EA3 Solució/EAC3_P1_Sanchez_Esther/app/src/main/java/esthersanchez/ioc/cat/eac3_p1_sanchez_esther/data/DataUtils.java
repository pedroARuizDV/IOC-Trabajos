package esthersanchez.ioc.cat.eac3_p1_sanchez_esther.data;

import android.content.res.Resources;

import java.util.ArrayList;
import java.util.List;

import esthersanchez.ioc.cat.eac3_p1_sanchez_esther.R;

/**
 * Helper class for providing content of travels
 */
public class DataUtils {


    // An array of Travel items.
    public static final List<Travel> TRAVEL_ITEMS = new ArrayList<>();

    // The ID for the index of Travels names.
    public static final String TRAVEL_ID_KEY = "item_id";

    // The number of travels
    private static final int COUNT = 5;

    static {
        // Add some sample travels.
        for (int i = 0; i < COUNT; i++) {
            addItem(createTravel(i));
        }
    }

    private static void addItem(Travel item) {
        TRAVEL_ITEMS.add(item);

    }

    private static Travel createTravel(int position) {
        String newTravel;
        String newContent;
        switch (position) {
            case 0:
                newTravel = "Granada";
                newContent = "Granada és un municipi i una ciutat espanyola, capital de la província homònima," +
                        " a la comunitat autònoma d\' Andalusia. Està situada al centre de la comarca de la Vega" +
                        " de Granada, a una altitud de 738 msnm, en una àmplia depressió intrabètica" +
                        " formada pel riu Genil, i al peu del massís més alt de la península Ibèrica," +
                        " serra Nevada, que condiciona la seva climatologia. \n" +
                         "\n" +
                        " El 2009, l\' habitaven 234.325 persones," +
                        " i 498.365 comptant l\' àrea metropolitana. \n" +
                        "\n" +
                        " Els barris són molt diferents entre si," +
                        " en part per la contínua immigració fins a la dècada del 1990.\" " +
                        " Els més importants són el Zaidín, l\' Albaicín, el Sacromonte, el Realejo, la Chana," +
                        " l\' Almanjáyar i la Cartuja.\n" +
                        "\n" +
                        " Va ser capital del Regne zirida de Granada, durant el segle xi, i del Regne nassarita" +
                        " de Granada entre els segle xiii i Vxv. Després de la presa de la ciutat pels reis Catòlics," +
                        " es va mantenir com a capital del Regne castellà de Granada, ja simple" +
                        " jurisdicció territorial, fins al 1833.\n" +
                        "\n" +
                        " A l\' escut municipal ostenta els títols de « molt noble, molt lleial, nomenada," +
                        " gran, celebèrrima i heroica ciutat de Granada ». Granada constitueix un nucli" +
                        " receptor de turisme, a causa dels seus monuments i la proximitat de la seva estació" +
                        " d\' esquí professional, la zona històrica coneguda com a Alpujarras i la part" +
                        " de la costa granadina coneguda com a costa Tropical.";
                break;
            case 1:
                newTravel = "Tenerife";
                newContent = "Tenerife és la més gran de les illes que componen l'arxipèlag de les Canàries, " +
                        "on ocupa una posició central respecte de les illes de Gran Canària, " +
                        "La Gomera i La Palma. La capital és Santa Cruz de Tenerife, i la segona ciutat " +
                        "més poblada de l'illa és San Cristóbal de La Laguna, ciutat que a més és" +
                        " Patrimoni de la Humanitat des de l'any 1999. A més, Tenerife és també l'illa " +
                        "més extensa i poblada de la regió Macaronèsia.\n" +
                        "\n" +
                        "L'illa és a l'oceà Atlàntic, a poc més de 300 km del continent africà i" +
                        " a uns 1.300 km de la península Ibèrica. Té 2.034 km² de superfície i " +
                        "una curiosa forma triangular. Al centre de l'illa s'alça el pic del Teide, " +
                        "un volcà que, amb els seus 3.718 m d'altura, és el punt més alt de l'Estat " +
                        "espanyol.És l'illa més poblada de Canàries i d'Espanya. A l'illa es" +
                        " troba el Parc Nacional del Teide que va ser declarat Patrimoni de la Humanitat." +
                        " També compta amb el massís d'Anaga que des de 2013 és Reserva de la Biosfera.\n" +
                        "\n" +
                        "El Cabildo de Tenerife és l'òrgan de govern de l'illa." +
                        " Es va constituir el 16 de març de 1913 a Santa Cruz de Tenerife, " +
                        "en una sessió celebrada a l'Ajuntament de la ciutat en la qual també es " +
                        "va escollir la primera corporació.";
                break;
            case 2:
                newTravel = "Goteborg";
                newContent = "Göteborg (Àudio ? i  escolteu-ne la pronunciació en suec) és la segona ciutat més gran de Suècia i la cinquena dels països nòrdics. Té una població d'aproximadament 533.000 habitants, i amb la seva àrea metropolitana arriba fins als 1,1 milions d'habitants. Fundada l'any 1621, el seu nom significa \"ciutat o fortalesa dels gots\".\n" +
                        "\n" +
                        "Situada a mig camí entre Oslo (capital de Noruega) i Copenhaguen (capital de Dinamarca), i a la desembocadura del riu Göta Älv, la ciutat és un centre de transports de la part oest de Suècia. Té el port comercial més gran del país, i gran empreses industrials com Volvo i SKF són controlades des de Göteborg.";
                break;
            case 3:
                newTravel = "Atenes";
                newContent = "Atenes (en grec modern Αθήνα [romanitzat com Athina], en català medieval Cetines) és la capital de Grècia, la capital de la regió grega de l'Àtica i la ciutat més gran del país.\n" +
                        "\n" +
                        "Té una població de 664.046 (cens del 2011) i una superfície de 38,964 km². L'àrea metropolitana d'Atenes, que inclou la regió de l'Àtica excepte algunes illes, és de 3,7 milions de persones,[1] al voltant d'un terç de la població total del país.\n" +
                        "\n" +
                        "És el centre de la vida econòmica, cultural i política grega, però Atenes també és important per haver estat una poderosa polis i un important centre del coneixement de l'Antiga Grècia.\n" +
                        "\n" +
                        "El centre de la ciutat es troba al voltant de el turó de l'Acròpoli, i de la Plaça Síndagma (o plaça de la Constitució), on es troba l'antic Palau Reial, que allotja el Parlament grec i altres edificis públics del segle XIX. La majoria de les zones antigues de la ciutat es concentren al voltant d'aquest centre.\n" +
                        "\n" +
                        "Durant l'època clàssica de Grècia, Atenes va tenir una gran importància en el desenvolupament de la democràcia. Va ser també un centre cultural on van viure molts dels artistes, escriptors i filòsofs de l'Antiguitat. Aquestes contribucions d'Atenes al pensament de la seva època van tenir una gran influència en el desenvolupament de Grècia, de Roma i de la cultura occidental. És una de les ciutats on més restes arqueològiques s'han trobat i, a més de les construccions d'aquesta època, es conserven també monuments romans i romans d'Orient, a banda de construccions modernes i contemporànies.\n" +
                        "\n" +
                        "Atenes va ser la seu dels primers Jocs Olímpics moderns posteriors a l'Antiga Grècia, els Jocs Olímpics d'Atenes de 1896. Tot i ser candidata als del centenari, el 1996 (finalment la seu escollida va ser Atlanta, als EUA), va ser designada seu per segona vegada pels primers Jocs Olímpics del tercer mil·lenni, els Jocs Olímpics de 2004. També va ser seu dels Jocs Olímpics intercalats de 1906.";
                break;
            case 4:
                newTravel = "Copenhaguen";
                newContent = "Copenhaguen (København en danès) és la capital i la ciutat més gran" +
                        " de Dinamarca. La població de la ciutat és d'1.181.000 habitants. " +
                        "El nom danès de la ciutat prové de la deformació de Købmandshavn, que " +
                        "significa \"port dels mercaders\", fent referència a l'estratègica " +
                        "localització de la ciutat a l'entrada de la mar Bàltica, a l'illa de Sjælland. " +
                        "El nom català prové de l'alemany Kopenhagen. Copenhaguen és la seu del parlament," +
                        " el Folketing i de la monarquia danesa.";
                break;
            default:
                newTravel = "";
                newContent = ".";
                break;
        }
        return new Travel(newTravel, newContent);
    }


    /**
     * A Travel item represented by a a name and details.
     */
    public static class Travel {
        public final String name;
        public final String content;

        public Travel(String name, String content) {
            this.name = name;
            this.content = content;

        }

        @Override
        public String toString() {
            return name;
        }
    }
}

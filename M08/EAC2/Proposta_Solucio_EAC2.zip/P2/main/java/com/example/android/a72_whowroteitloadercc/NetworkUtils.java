package com.example.android.a72_whowroteitloadercc;

import android.net.Uri;
import android.util.Log;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;


public class NetworkUtils {

    private static final String LOG_TAG = NetworkUtils.class.getSimpleName();


    // Base URL for Books API
    private static final String BOOK_BASE_URL =  "https://www.googleapis.com/books/v1/volumes?";
    // Parametre per buscar (query)
    private static final String QUERY_PARAM = "q";
    // Parametre que limita els resultats de la recerca
    private static final String MAX_RESULTS = "maxResults";
    // Parameter pel filtrar print type
    private static final String PRINT_TYPE = "printType";
    // Parameter per descarregar llibres en format epub
    private static final String DOWNLOADABLE = "download";


    static String getBookInfo(String queryString, String ebookString){

        HttpURLConnection urlConnection = null;
        BufferedReader reader = null;
        String bookJSONString = null;

        try {
            //Construim la consulta de tipus URI.
            //Limitem a 10 resultats


            Uri builtURI;

            if (ebookString != null){
                // S'ha clickat al checkbox eBook
                builtURI= Uri.parse(BOOK_BASE_URL).buildUpon()
                        .appendQueryParameter(QUERY_PARAM, queryString)
                        .appendQueryParameter(MAX_RESULTS, "10")
                        .appendQueryParameter(PRINT_TYPE, "books")
                        .appendQueryParameter(DOWNLOADABLE, ebookString)
                        .build();

            }else{
                builtURI = Uri.parse(BOOK_BASE_URL).buildUpon()
                        .appendQueryParameter(QUERY_PARAM, queryString)
                        .appendQueryParameter(MAX_RESULTS, "10")
                        .appendQueryParameter(PRINT_TYPE, "books")
                        .build();

            }


            // Convertim la URI a URL
            URL requestURL = new URL(builtURI.toString());

            // Obrim la connexió utilitzant HttpURLConnection
            urlConnection = (HttpURLConnection) requestURL.openConnection();
            urlConnection.setRequestMethod("GET");
            urlConnection.connect();

            // Obtenim el inputStream
            InputStream inputStream = urlConnection.getInputStream();

            // Creem un buffered Reader
            reader = new BufferedReader(new InputStreamReader(inputStream));


            StringBuilder builder = new StringBuilder();

            String line;
            while ((line = reader.readLine()) != null) {
                // afegim la linia actual al string
                builder.append(line);
                builder.append("\n");
            }

            if (builder.length() == 0) {
                // Està buit, retornem null
                return null;
            }

            // Convertim el StringBuilder a string
            bookJSONString = builder.toString();

        } catch (IOException e){
            e.printStackTrace();
        } finally {
            // Tanquem la connexió
            if (urlConnection != null) {
                urlConnection.disconnect();
            }
            // Tanquem el reader
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        // Escrivim la resposta JSON al log
        Log.d(LOG_TAG, bookJSONString);

        return bookJSONString;
    }
}

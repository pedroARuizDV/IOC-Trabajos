package com.example.android.a72_whowroteitloadercc;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.loader.app.LoaderManager;
import androidx.loader.content.Loader;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


public class MainActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<String> {

    // Variables de classe
    private EditText mBookInput;
    private TextView mTitleText;
    private TextView mAuthorText;
    private CheckBox mEPubCheckBox;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mBookInput = (EditText)findViewById(R.id.bookInput);
        mTitleText = (TextView)findViewById(R.id.titleText);
        mAuthorText = (TextView)findViewById(R.id.authorText);
        mEPubCheckBox =findViewById(R.id.ePub);

        //Comprovem que el LoadManager està iniciat
        if (LoaderManager.getInstance(this).getLoader(0) != null) {
            LoaderManager.getInstance(this).initLoader(0, null, this);
        }
    }


    public void searchBooks(View view) {
        // Obtenim el string introduit al EditText
        String queryString = mBookInput.getText().toString();

        // Amaguem el teclat quan l'usuari premi el botó
        InputMethodManager inputManager = (InputMethodManager)
                getSystemService(Context.INPUT_METHOD_SERVICE);
        if (inputManager != null) {
            inputManager.hideSoftInputFromWindow(view.getWindowToken(),
                    InputMethodManager.HIDE_NOT_ALWAYS);
        }

        // Obenim l'estat de la connexió
        ConnectivityManager connMgr = (ConnectivityManager)
                getSystemService(Context.CONNECTIVITY_SERVICE);

        Network networkInfo = null;

        if (connMgr != null) {
            networkInfo = connMgr.getActiveNetwork(); //API mínima 23
        }

        // Si hi ha connexió a Internet i el string introduït no és buit
        // is not empty, start a FetchBook AsyncTask.
        if (networkInfo != null && queryString.length() != 0) {
           //Enviem un bundle per enviar-lo al AsyncTaskLoader
            Bundle queryBundle = new Bundle();
            queryBundle.putString("queryString", queryString);
            if (mEPubCheckBox.isChecked()) queryBundle.putString("download", "epub");
            LoaderManager.getInstance(this).restartLoader(0, queryBundle, this);
            mAuthorText.setText("");
            mTitleText.setText(R.string.loading);
        }
        // No hi ha connexió a internet
        else {
            if (queryString.length() == 0) {
                mAuthorText.setText("");
                mTitleText.setText(R.string.no_search_term);
            } else {
                mAuthorText.setText("");
                mTitleText.setText(R.string.no_network);
            }
        }
    }

    @NonNull
    @Override
    public Loader<String> onCreateLoader(int id, @Nullable Bundle args) {
        String queryString = "";
        String epubString = "";

        if (args != null) {
            queryString = args.getString("queryString");
            epubString = args.getString("download");
        }

        return new BookLoader(this, queryString, epubString );
    }

    //cridat quan es finalitza la càrrega; s'actualitza la interfície dusuari amb els resultats
    @Override
    public void onLoadFinished(@NonNull Loader<String> loader, String data) {
        try {
            // Convert la resposta a un objecte JSON
            JSONObject jsonObject = new JSONObject(data);
            // Obtenim el JSONArray dels llibres
            JSONArray itemsArray = jsonObject.getJSONArray("items");


            int i = 0;
            String title = null;
            String authors = null;

            // Recorrem la llista i quan trobem el primer autor i títol no buit parem la búsqueda
            while (i < itemsArray.length() &&
                    (authors == null && title == null)) {
                // Obtenim la informació del element actual
                JSONObject book = itemsArray.getJSONObject(i);
                JSONObject volumeInfo = book.getJSONObject("volumeInfo");

                // Intentem obtenir l'autor i el títol del element actual.
                try {
                    title = volumeInfo.getString("title");
                    authors = volumeInfo.getString("authors");
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                // Ens movem al següent element
                i++;
            }

            // Si els dos no son null, mostrem el resultat
            if (title != null && authors != null) {
                mTitleText.setText(title);
                mAuthorText.setText(authors);
            } else {
                // Si no n'hem trobat cap, mostrem el missatge
                mTitleText.setText(R.string.no_response);
                mAuthorText.setText("");
            }

        } catch (JSONException e) {
            mTitleText.setText(R.string.no_response);
            mAuthorText.setText("");
            e.printStackTrace();
        }
    }


    @Override
    public void onLoaderReset(@NonNull Loader<String> loader) {

    }

}


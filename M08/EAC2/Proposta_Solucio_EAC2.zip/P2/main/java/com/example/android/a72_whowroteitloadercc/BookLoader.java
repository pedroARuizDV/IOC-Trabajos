package com.example.android.a72_whowroteitloadercc;

import android.content.Context;

import androidx.annotation.Nullable;
import androidx.loader.content.AsyncTaskLoader;

public class BookLoader extends AsyncTaskLoader<String> {

    private String mQueryString;
    private String mEpubString;

    BookLoader(Context context, String queryString, String ePubString) {
        super(context);
        mQueryString = queryString;
        mEpubString = ePubString;
    }

    @Override
    protected void onStartLoading() {
        super.onStartLoading();

        forceLoad();
    }

    @Nullable
    @Override
    public String loadInBackground() {
        return NetworkUtils.getBookInfo(mQueryString, mEpubString);
    }

}

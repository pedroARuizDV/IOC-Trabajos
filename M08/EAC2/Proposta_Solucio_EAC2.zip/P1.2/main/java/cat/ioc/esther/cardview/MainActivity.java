package cat.ioc.esther.cardview;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.res.TypedArray;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import cat.ioc.esther.cardview.R;

import java.util.ArrayList;
import java.util.Collections;


public class MainActivity extends AppCompatActivity {

    private RecyclerView mRecyclerView;
    private ArrayList<Travel> mTravelsData;
    private TravelAdapter mAdapter;
    private TypedArray travelsImageResources;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicalitzem el recyclerView
        mRecyclerView = findViewById(R.id.recyclerView);


        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Inicialitzem la llista buida
        mTravelsData = new ArrayList<>();

        // Inicialitzem el adaptador i l'assignem al recyclerView
        mAdapter = new TravelAdapter(this, mTravelsData);
        mRecyclerView.setAdapter(mAdapter);

        // Inicialitzem les dades a la llista
        initializeData();

        ItemTouchHelper helper = new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(ItemTouchHelper.LEFT |
                                                                                                ItemTouchHelper.RIGHT |
                                                                                                ItemTouchHelper.DOWN |
                                                                                                ItemTouchHelper.UP,
                                                                                        ItemTouchHelper.LEFT |
                                                                                                ItemTouchHelper.RIGHT) {
            @Override
            public boolean onMove(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder,
                                  RecyclerView.ViewHolder target) {
                int from = viewHolder.getAdapterPosition();
                int to = target.getAdapterPosition();
                Collections.swap(mTravelsData, from, to);
                mAdapter.notifyItemMoved(from, to);
                return true;
            }

            @Override
            public void onSwiped(RecyclerView.ViewHolder viewHolder, int direction) {
                mTravelsData.remove(viewHolder.getAdapterPosition());
                mAdapter.notifyItemRemoved(viewHolder.getAdapterPosition());
            }
        });
        helper.attachToRecyclerView(mRecyclerView);
    }


    private void initializeData() {
        // Obtenim el array d'strings declarat al fitxer strings.xml
        String[] travelsList = getResources()
                .getStringArray(R.array.travels_titles);
        String[] travelsInfo = getResources()
                .getStringArray(R.array.travels_info);
        travelsImageResources = getResources().obtainTypedArray(R.array.travels_images);

        // Netegem les dades per evitar duplicacions
        mTravelsData.clear();

        // Afegim al ArrayList els nous objectes Travel amb la informació de cada viatge
        for(int i=0;i<travelsList.length;i++){
            mTravelsData.add(new Travel(travelsList[i],travelsInfo[i],travelsImageResources.getResourceId(i,0)));
        }

        travelsImageResources.recycle();
        // Notifiquem al adaptador que les dades han canviat
        mAdapter.notifyDataSetChanged();
    }

    public void resetTravels(View view) {

        initializeData();
    }
}
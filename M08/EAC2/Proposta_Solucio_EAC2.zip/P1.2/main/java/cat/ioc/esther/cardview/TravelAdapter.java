package cat.ioc.esther.cardview;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import cat.ioc.esther.cardview.R;

import java.util.ArrayList;


class TravelAdapter extends RecyclerView.Adapter<TravelAdapter.ViewHolder>  {

    private ArrayList<Travel> mTravelData;
    private Context mContext;


    TravelAdapter(Context context, ArrayList<Travel> travelslData) {
        this.mTravelData = travelslData;
        this.mContext = context;
    }


    @Override
    public TravelAdapter.ViewHolder onCreateViewHolder(
            ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(mContext).
                inflate(R.layout.list_item, parent, false));
    }


    @Override
    public void onBindViewHolder(TravelAdapter.ViewHolder holder,
                                 int position) {
        // obtè el objecte viatge actual
        Travel currentTravel = mTravelData.get(position);

        // Enllaça els TextView amb l'objecte viatge actual
        holder.bindTo(currentTravel);
    }


    @Override
    public int getItemCount() {
        return mTravelData.size();
    }



    class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        private TextView mTitleText;
        private TextView mInfoText;
        private ImageView mTravelsImage;


        ViewHolder(View itemView) {
            super(itemView);

            mTitleText = itemView.findViewById(R.id.title);
            mInfoText = itemView.findViewById(R.id.subTitle);
            mTravelsImage = itemView.findViewById(R.id.travelsImage);

            // Establim un Listener onClick a tot el groupView
            itemView.setOnClickListener(this);
        }

        void bindTo(Travel currentTravel){
            mTitleText.setText(currentTravel.getTitle());
            mInfoText.setText(currentTravel.getInfo());
            Glide.with(mContext).load(currentTravel.getImageResource()).into(mTravelsImage);
        }

        @Override
        public void onClick(View v) {
            Travel currentTravel = mTravelData.get(getAdapterPosition());
            Intent detailIntent = new Intent(mContext, DetailActivity.class);
            detailIntent.putExtra("title", currentTravel.getTitle());
            detailIntent.putExtra("image_resource", currentTravel.getImageResource());
            mContext.startActivity(detailIntent);
        }
    }
}

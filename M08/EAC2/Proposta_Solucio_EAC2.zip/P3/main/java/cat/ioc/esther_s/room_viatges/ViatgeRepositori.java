package cat.ioc.esther_s.room_viatges;


import android.app.Application;
import android.os.AsyncTask;

import androidx.lifecycle.LiveData;

import java.util.List;

public class ViatgeRepositori {

    private ViatgeDao mViatgeDao;
    private LiveData<List<Viatge>> mTotsViatges;

    ViatgeRepositori(Application application){
        ViatgeRoomDatabase db = ViatgeRoomDatabase.getDatabase(application);
        mViatgeDao = db.viatgeDao();
        mTotsViatges = mViatgeDao.getTotsViatges();
    }

    LiveData<List<Viatge>> getTotsViatges(){
        return mTotsViatges;
    }

    public void afegir (Viatge viatge){
        new afegirAsyncTask(mViatgeDao).execute(viatge);
    }

    public void update(Viatge viatge)  {
        new actualitzaAsyncTask(mViatgeDao).execute(viatge);
    }

    public void esborrarTot(){
        new esborrarTotAsyncTask(mViatgeDao).execute();
    }

    public void esborrarViatge(Viatge viatge){
        new esborrarAsyncTask(mViatgeDao).execute(viatge);
    }

    private static class afegirAsyncTask extends AsyncTask<Viatge, Void, Void> {
        private ViatgeDao mAsyncTaskDao;

        afegirAsyncTask(ViatgeDao dao){
            mAsyncTaskDao = dao;
        }

        @Override
        protected Void doInBackground(final Viatge... viatges) {
            mAsyncTaskDao.afegir(viatges[0]);
            return null;
        }
    }

    private static class esborrarTotAsyncTask extends AsyncTask<Void, Void, Void> {
        private ViatgeDao mAsyncTaskDao;

        esborrarTotAsyncTask(ViatgeDao dao){
            mAsyncTaskDao = dao;
        }

        @Override
        protected Void doInBackground(Void... voids) {
            mAsyncTaskDao.esborrarTot();
            return null;
        }
    }

    private static class esborrarAsyncTask extends AsyncTask<Viatge, Void, Void> {
        private ViatgeDao mAsyncTaskDao;

        esborrarAsyncTask(ViatgeDao dao){
            mAsyncTaskDao = dao;
        }

        @Override
        protected Void doInBackground(final Viatge... params) {
            mAsyncTaskDao.esborrarViatge(params[0]);
            return null;
        }
    }

    private static class actualitzaAsyncTask extends AsyncTask<Viatge, Void, Void> {
        private ViatgeDao mAsyncTaskDao;

        actualitzaAsyncTask(ViatgeDao dao){
            mAsyncTaskDao = dao;
        }

        @Override
        protected Void doInBackground(final Viatge... params) {
            mAsyncTaskDao.actualitzarViatge(params[0]);
            return null;
        }
    }
}

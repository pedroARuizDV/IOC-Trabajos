package cat.ioc.esther_s.room_viatges;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface ViatgeDao {

     @Insert(onConflict = OnConflictStrategy.IGNORE)
    void afegir(Viatge viatge);

    @Query("DELETE FROM tViatge")
    void esborrarTot();

    @Query("SELECT * FROM tViatge ORDER BY viatge ASC")
    LiveData<List<Viatge>> getTotsViatges();

    @Query("SELECT * FROM tViatge LIMIT 1")
    Viatge[] getTotViatges();

    @Delete
    void esborrarViatge(Viatge viatge);

    @Update
    void actualitzarViatge(Viatge... viatge);

}

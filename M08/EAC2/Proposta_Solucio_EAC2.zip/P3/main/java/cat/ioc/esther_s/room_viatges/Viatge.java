package cat.ioc.esther_s.room_viatges;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

// Anotacio per crear la taula viatge a la base de dades
@Entity(tableName = "tViatge")
public class Viatge {

    // Parametres de la columna
    @PrimaryKey(autoGenerate = true)    // Clau primaria
    private int id;
    @NonNull                            // No pot ser null
    @ColumnInfo(name = "viatge")        // Nom de la columna
    private String mViatge;

    /**
     * Constructor del objecte Viatge
     * @param viatge Nom del viatge a crear
     */
    public Viatge(@NonNull String viatge){
        this.mViatge = viatge;
    }
    @Ignore
    public Viatge(int id, @NonNull String viatge) {
        this.id = id;
        this.mViatge = viatge;
    }

    public int getId(){return this.id;}

    public void setId(int id) {
        this.id = id;
    }

    public String getViatge(){return this.mViatge;}
}
package cat.ioc.esther_s.room_viatges;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.content.Intent;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import static cat.ioc.esther_s.room_viatges.MainActivity.EXTRA_DATA_ID;
import static cat.ioc.esther_s.room_viatges.MainActivity.EXTRA_DATA_UPDATE_VIATGE;

import cat.ioc.esther_s.room_viatges.R;

public class NouViatgeActivity extends AppCompatActivity {

    public static final String EXTRA_REPLY =
            "cat.ioc.esther_s.room_viatges.REPLY";
    public static final String EXTRA_REPLY_ID = "cat.ioc.esther_s.room_viatges.REPLY_ID";

    private EditText mEditViatgeView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nou_viatge);

        mEditViatgeView = findViewById(R.id.edit_viatge);
        int id = -1 ;

        final Bundle extras = getIntent().getExtras();

        if (extras != null) {
            String word = extras.getString(EXTRA_DATA_UPDATE_VIATGE, "");
            if (!word.isEmpty()) {
                mEditViatgeView.setText(word);
                mEditViatgeView.setSelection(word.length());
                mEditViatgeView.requestFocus();
            }
        }

        final Button button = findViewById(R.id.button_save);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent replyIntent = new Intent();
                if (TextUtils.isEmpty(mEditViatgeView.getText())) {
                    setResult(RESULT_CANCELED, replyIntent);
                } else {
                    String viatge = mEditViatgeView.getText().toString();
                    replyIntent.putExtra(EXTRA_REPLY, viatge);
                    if (extras != null && extras.containsKey(EXTRA_DATA_ID)) {
                        int id = extras.getInt(EXTRA_DATA_ID, -1);
                        if (id != -1) {
                            replyIntent.putExtra(EXTRA_REPLY_ID, id);
                        }
                    }
                    setResult(RESULT_OK, replyIntent);
                }

                finish();
            }
        });
    }
}

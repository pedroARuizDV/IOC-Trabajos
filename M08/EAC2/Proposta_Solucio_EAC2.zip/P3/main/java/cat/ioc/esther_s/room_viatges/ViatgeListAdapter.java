package cat.ioc.esther_s.room_viatges;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class ViatgeListAdapter extends RecyclerView.Adapter<ViatgeListAdapter.ViatgeViewHolder> {

    private final LayoutInflater mInflater;
    private List<Viatge> mViatges;
    private static ClickListener clickListener;

    ViatgeListAdapter(Context context){mInflater = LayoutInflater.from(context);}

    @NonNull
    @Override
    public ViatgeViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = mInflater.inflate(R.layout.recyclerview_item, parent, false);
        return new ViatgeViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ViatgeViewHolder holder, int position) {
        if (mViatges != null) {
            Viatge current = mViatges.get(position);
            holder.viatgeItemView.setText(current.getViatge());
        } else {
            holder.viatgeItemView.setText(R.string.no_viatges);
        }

    }

    void setViatges(List<Viatge> viatges){
        mViatges = viatges;
        notifyDataSetChanged();
    }

    public Viatge getPosicioViatge(int posicio) {
        return mViatges.get(posicio);
    }


    @Override
    public int getItemCount() {
        if (mViatges != null)
            return mViatges.size();
        else return 0;
    }

    class ViatgeViewHolder extends RecyclerView.ViewHolder {
        private final TextView viatgeItemView;

        private ViatgeViewHolder(View itemView) {
            super(itemView);
            viatgeItemView = itemView.findViewById(R.id.viatge);
        }
    }

    public void setOnItemClickListener(ClickListener clickListener) {
        ViatgeListAdapter.clickListener = clickListener;
    }

    public interface ClickListener {
        void onItemClick(View v, int position);
    }
}
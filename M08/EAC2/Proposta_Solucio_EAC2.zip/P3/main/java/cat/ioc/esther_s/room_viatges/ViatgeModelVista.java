package cat.ioc.esther_s.room_viatges;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import java.util.List;

public class ViatgeModelVista extends AndroidViewModel {
    private ViatgeRepositori mRepositori;
    private LiveData<List<Viatge>> mTotsViatges;

    public ViatgeModelVista(@NonNull Application application) {
        super(application);
        mRepositori = new ViatgeRepositori(application);
        mTotsViatges = mRepositori.getTotsViatges();
    }

    LiveData<List<Viatge>> getTotsViatges(){return mTotsViatges; }

    public void afegir(Viatge viatge) {mRepositori.afegir(viatge);}

    public void esborrarTot(){mRepositori.esborrarTot();}

    public void esborrarViatge(Viatge viatge){mRepositori.esborrarViatge(viatge);}

    public void actualitzar(Viatge viatge) {
        mRepositori.update(viatge);
    }
}

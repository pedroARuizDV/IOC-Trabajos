package cat.ioc.esther_s.room_viatges;

import android.content.Context;
import android.os.AsyncTask;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;

//Si canvia la estructura de la base de dades s'ha d'incrementar la versió
@Database(entities = {Viatge.class}, version = 1, exportSchema = false)
public abstract class ViatgeRoomDatabase extends RoomDatabase {

    private static ViatgeRoomDatabase INSTANCIA;

    private static RoomDatabase.Callback sRoomCallback = new RoomDatabase.Callback(){

        @Override
        public void onOpen(@NonNull SupportSQLiteDatabase db) {
            super.onOpen(db);
            new PoblarDbAsync(INSTANCIA).execute();
        }
    };

    public static ViatgeRoomDatabase getDatabase(final Context context){

        // Comprovem si la base de dades es null
        if(INSTANCIA == null){
            // Sincronitzem la base de dades
            synchronized (ViatgeRoomDatabase.class){
                // Si la base de dades es null, creem la base de dades
                if(INSTANCIA == null){
                    INSTANCIA = Room.databaseBuilder(context.getApplicationContext(),
                            ViatgeRoomDatabase.class, "viatge_database")
                            .fallbackToDestructiveMigration()
                            .addCallback(sRoomCallback)
                            .build();
                }
            }
        }
        return INSTANCIA;
    }
    public abstract ViatgeDao viatgeDao();



    // Carrega la base de dades en backgound. Inserim uns viatges per començar

    private static class PoblarDbAsync extends AsyncTask<Void, Void, Void> {

        private final ViatgeDao mDao;


        private static String[] viatges = {"França", "Italia", "Suïssa", "Bèlgica", "Àustria",
                "Alemanya", "Regne Unit", "Marroc"};

        PoblarDbAsync(ViatgeRoomDatabase db) {
            mDao = db.viatgeDao();
        }

        @Override
        protected Void doInBackground(final Void... params) {

            if (mDao.getTotViatges().length < 1) {
                for (int i = 0; i <= viatges.length - 1; i++) {
                    Viatge viatge = new Viatge(viatges[i]);
                    mDao.afegir(viatge);
                }
            }

            return null;
        }
    }
}

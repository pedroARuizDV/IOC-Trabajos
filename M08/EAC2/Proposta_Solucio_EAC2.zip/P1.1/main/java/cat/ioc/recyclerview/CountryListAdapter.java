package cat.ioc.recyclerview;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class CountryListAdapter extends RecyclerView.Adapter<CountryListAdapter.CountryViewHolder> {

    private final List<String> countryList;
    private LayoutInflater inflater;

    public CountryListAdapter(Context context, List<String> countryList) {
        inflater = LayoutInflater.from(context);
        this.countryList = countryList;
    }

    @NonNull
    @Override
    public CountryListAdapter.CountryViewHolder onCreateViewHolder(
            @NonNull ViewGroup parent,
            int viewType
    ) {
        View view = inflater.inflate(R.layout.countrylist_item, parent, false);
        return new CountryViewHolder(view, this);
    }

    @Override
    public void onBindViewHolder(@NonNull CountryListAdapter.CountryViewHolder holder, int position) {
        String currentCountry = countryList.get(position);
        holder.countryItemView.setText(currentCountry);
    }

    @Override
    public int getItemCount() {
        return countryList.size();
    }

    class CountryViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
        final TextView countryItemView;
        final CountryListAdapter countryListAdapter;

        CountryViewHolder(View itemView, CountryListAdapter adapter) {
            super(itemView);
            countryItemView = itemView.findViewById(R.id.country);
            this.countryListAdapter = adapter;
            countryItemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            int position = getLayoutPosition();
            //Obtenim la posició del item que s'ha clickat
            String element = countryList.get(position);
            //Busquem si ja s'ha realitzat el viatge
            if (element.contains(" - Realitzat!")){
                // Li treiem realitzat
                element = element.replace(" - Realitzat!","");
                countryList.set(position, element);
            }else{
                //Li posem realitzat
                countryList.set(position,  element + " - Realitzat!");
            }
            //Notifica al adaptador que les dades han canviat i així refresca el que es mostra en el recyclerView
            countryListAdapter.notifyDataSetChanged();
        }
    }
}

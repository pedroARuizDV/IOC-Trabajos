package cat.ioc.recyclerview;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;

public class MainActivity extends AppCompatActivity {

    private final String[] countryArray = {"França", "Italia", "Suïssa", "Bèlgica", "Àustria",
    "Alemanya", "Regne Unit", "Marroc"};

    private RecyclerView recyclerView;
    private CountryListAdapter countryListAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        final List<String> countryList = new LinkedList<>(Arrays.asList(countryArray));
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView = findViewById(R.id.recyclerview);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = findViewById(R.id.fab);
        final EditText edt_nouPais = findViewById(R.id.edt_nouPais);

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String sNouPais = edt_nouPais.getText().toString();
                if (sNouPais.isEmpty()){
                    Toast.makeText(getApplicationContext(),R.string.msg_nou_pais_buit,Toast.LENGTH_LONG).show();

                }else{
                    int countryListSize = countryList.size();
                    countryList.add(sNouPais);
                    edt_nouPais.setText("");

                    recyclerView.getAdapter().notifyItemInserted(countryListSize);
                    recyclerView.smoothScrollToPosition(countryListSize);
                }


            }
        });
        countryListAdapter = new CountryListAdapter(this, countryList);
        recyclerView.setAdapter(countryListAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}

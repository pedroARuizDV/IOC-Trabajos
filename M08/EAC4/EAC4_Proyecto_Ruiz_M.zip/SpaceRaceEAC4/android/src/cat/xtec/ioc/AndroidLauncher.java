package cat.xtec.ioc;

import android.os.Bundle;

import com.badlogic.gdx.backends.android.AndroidApplication;
import com.badlogic.gdx.backends.android.AndroidApplicationConfiguration;
import cat.xtec.ioc.SpaceRace;

public class AndroidLauncher extends AndroidApplication {
	@Override
	protected void onCreate (Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		AndroidApplicationConfiguration config = new AndroidApplicationConfiguration();

		// Deshabilitar sensores que no utilizamos
		config.useAccelerometer = false;
		config.useCompass = false;
		//
		//Impedimos que se apague la pantalla
		config.useWakelock = true;
		// Ponemos el modo inmersivo para coultar botones software
		config.useImmersiveMode = true;

		// Aplicamos la configuración
		initialize(new SpaceRace(), config);
	}
}

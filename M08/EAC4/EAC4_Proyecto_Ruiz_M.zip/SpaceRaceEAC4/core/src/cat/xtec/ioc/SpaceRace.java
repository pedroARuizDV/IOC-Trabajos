package cat.xtec.ioc;


import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import cat.xtec.ioc.helpers.AssetManager;
import cat.xtec.ioc.screens.GameScreen;
import cat.xtec.ioc.screens.SplashScreen;


/**
 * Clase que se encarga de cargar los recursos y
 * controlar las pantallas del juego
 */
public class SpaceRace extends Game {

	
	@Override
	public void create () {
		// Al iniciar el juego cargamos los recursos
		AssetManager.load();
		// Definimos la pantalla principal como en la pantalla
		setScreen(new SplashScreen(this));
	}


	
	@Override
	public void dispose () {
		super.dispose();
		//Gdx.app.log("LifeCycle", "dispose()");
		AssetManager.dispose();
	}
}

package cat.xtec.ioc.objects;

import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.math.Circle;
import com.badlogic.gdx.math.Intersector;
import com.badlogic.gdx.scenes.scene2d.actions.RepeatAction;
import com.badlogic.gdx.scenes.scene2d.actions.RotateByAction;

import java.util.Random;
import cat.xtec.ioc.helpers.AssetManager;
import cat.xtec.ioc.utils.Methods;
import cat.xtec.ioc.utils.Settings;

public class Asteroid extends Scrollable {

    // Variable que representa con un circulo los asteroides
    private Circle collisionCircle;

    Random r;

    int assetAsteroid;


    /**
     * Constructor
     *
     * @param x
     * @param y
     * @param width
     * @param height
     * @param velocity
     */
    public Asteroid(float x, float y, float width, float height, float velocity) {
        super(x, y, width, height, velocity);

        // Creamos el circulo
        collisionCircle = new Circle();

        /* Acciones */
        r = new Random();
        assetAsteroid = r.nextInt(8);
        setOrigin();

        // Rotación
        RotateByAction rotateAction = new RotateByAction();
        rotateAction.setAmount(-90f);
        rotateAction.setDuration(0.2f);

        // Acción de repetición
        RepeatAction repeat = new RepeatAction();
        repeat.setAction(rotateAction);
        repeat.setCount(RepeatAction.FOREVER);

        // Equivalent:
        // this.addAction(Actions.repeat(RepeatAction.FOREVER, Actions.rotateBy(-90f, 0.2f)));

        this.addAction(repeat);

    }

    public void setOrigin() {
        this.setOrigin(width/2 + 1, height/2);
    }

    @Override
    public void act(float delta) {
        super.act(delta);

        // Actualizamos el circulo de collidesBonusNormal (punto central del asteroide y del radio)
        collisionCircle.set(position.x + width / 2.0f, position.y + width / 2.0f, width / 2.0f);
    }

    public void reset(float newX) {
        super.reset(newX);
        // Obtenemos un número aleatorio entre MIN y MAX
        float newSize = Methods.randomFloat(Settings.MIN_ASTEROID, Settings.MAX_ASTEROID);
        // Modificamos la altura y la anchura según el aleatorio anterior
        width = height = 34 * newSize;
        // La posición será un valor aleatorio entre 0 y la altura
        // de la aplicación menos la altura
        position.y = new Random().nextInt(Settings.GAME_HEIGHT - (int) height);

        assetAsteroid = r.nextInt(7);
        setOrigin();
    }



    @Override
    public void draw(Batch batch, float parentAlpha) {
        super.draw(batch, parentAlpha);
        //batch.draw((TextureRegion) AssetManager.asteroidAnim.getKeyFrame(runTime), position.x,position.y, width, height);
        batch.draw(
                AssetManager.asteroid[assetAsteroid],
                position.x,
                position.y,
                this.getOriginX(),
                this.getOriginY(),
                width,
                height,
                this.getScaleX(),
                this.getScaleY(),
                this.getRotation());
    }

        /**
         * Método que comprueba si hay una colisión. En caso afirmativo, retorna true
         * @param nau
         * @return
         */
        public boolean collides(Superman nau) {
            if (position.x <= nau.getX() + nau.getWidth()) {
                // Comprobamos si han colisionado siempre que el asteroide se encuentre a la misma altura que el superman
                return (Intersector.overlaps(collisionCircle, nau.getCollisionRect()));
            }
            return false;
        }



}

package cat.xtec.ioc.utils;

public class Settings {

    // Medida del juego, se escalará según la necesidad
    public static final int GAME_WIDTH = 240;
    public static final int GAME_HEIGHT = 135;

    // Propiedades de la nava
    public static final float SUPERMAN_VELOCITY = 50;
    public static final int SUPERMAN_WIDTH = 48;
    public static final int SUPERMAN_HEIGHT = 12;
    public static final float SUPERMAN_STARTX = 20;
    public static final float SUPERMAN_STARTY = GAME_HEIGHT/2 - SUPERMAN_HEIGHT /2;

    // Rango de valores para cambiar la medida del asteroide
    public static final float MAX_ASTEROID = 1.5f;
    public static final float MIN_ASTEROID = 0.5f;

    // Configuración scrollable
    public static final int ASTEROID_SPEED = -150;
    public static final int ASTEROID_GAP = 75;
    public static final int BG_SPEED = -100;

    // TODO Exercici 2: Propietats per la moneda
    public static final int SCORE_INCREASE_ESPECIAL = 100; // s'incrementa en 100 cada cop que toca una moneda
    public static final int SCORE_INCREASE_NORMAL = 50;
    public static final int SCORE_SPEED = -175;

}

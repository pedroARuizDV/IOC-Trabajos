package cat.xtec.ioc.helpers;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.InputProcessor;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.Stage;

import cat.xtec.ioc.objects.Superman;
import cat.xtec.ioc.screens.GameScreen;

public class InputHandler implements InputProcessor {

    // Entero para la gestión del movimiento de arrastre
    int previousY = 0;

    // Objetos necesarios
    private Superman superman;
    private GameScreen screen;

    // Umbral
    int umbral = 2; //pixeles

    // hit
    private Vector2 stageCoord;
    private Stage stage;


    /**
     * Constructor
     * @param screen Objeto de tipo GameScreen
     */
    public InputHandler (GameScreen screen) {
        // Obtenemos todos los elementos necesarios
        this.screen = screen;
        superman = screen.getSpacecraft();
        //hit
        stage = screen.getStage();
    }


    @Override
    public boolean keyDown(int keycode) {
        return false;
    }

    @Override
    public boolean keyUp(int keycode) {
        return false;
    }

    @Override
    public boolean keyTyped(char character) {
        return false;
    }

    @Override
    public boolean touchDown(int screenX, int screenY, int pointer, int button) {
        switch (screen.getCurrentState()) {
            case READY:
                // Si fem clic comencem el joc
                screen.setCurrentState(GameScreen.GameState.RUNNING);
                break;
            case RUNNING:
                previousY = screenY;
                stageCoord = stage.screenToStageCoordinates(new Vector2(screenX, screenY));
                Actor actorHit = stage.hit(stageCoord.x, stageCoord.y, true);
                if (actorHit != null) {
                    Gdx.app.log("HIT", actorHit.getName());
                }
                break;
            // Si l'estat és GameOver tornem a iniciar el joc
            case GAMEOVER:
                screen.reset();
                break;
        }

        return true;
    }

    @Override
    public boolean touchUp(int screenX, int screenY, int pointer, int button) {
        // Cuando dejamos ir el dedo acabamos un movimiento
        // y ponemos la nave al estado normal
        superman.goStraight();

        stageCoord = stage.screenToStageCoordinates(new Vector2(screenX, screenY));
        Actor actorHit = stage.hit(stageCoord.x, stageCoord.y, true);
        if (actorHit != null) {
            Gdx.app.log("HIT", actorHit.getName());
        }

        // Gestión botón Pause
        if(actorHit != null && actorHit.getName().equals("Pausa")) {
            screen.setCurrentState(GameScreen.GameState.READY);
            GameScreen.container.setVisible(false); // Quitamos la visibilidad de la puntuación
            GameScreen.pause.setVisible(false); // quitamos la visibilidad del botón de pause
            AssetManager.music.setVolume(0.05f); // Bajamos el volumen del juego
            GameScreen.puntuacion = AssetManager.puntActual.getInteger("puntuacion");
        }

        return true;
    }

    @Override
    public boolean touchDragged(int screenX, int screenY, int pointer) {
        // Ponemos un umbral para evitar gestionar eventos cuando el dedo esta quieto
        if (Math.abs(previousY - screenY) > umbral)
            // Si la Y es mayor que la que tenemos guardada, es que va hacia abajo
            if (previousY < screenY) {
                superman.goDown();
            } else {
                // En caso contrario va hacia arriba
                superman.goUp();
            }
        // Guardamos la posición de la Y
        previousY = screenY;
        return true;
    }

    @Override
    public boolean mouseMoved(int screenX, int screenY) {
        return false;
    }

    @Override
    public boolean scrolled(float amountX, float amountY) {
        return false;
    }
}

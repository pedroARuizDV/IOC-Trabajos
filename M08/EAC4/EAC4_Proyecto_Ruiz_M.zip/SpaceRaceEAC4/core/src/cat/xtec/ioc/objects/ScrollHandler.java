package cat.xtec.ioc.objects;

import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.Group;
import com.badlogic.gdx.scenes.scene2d.actions.Actions;
import com.badlogic.gdx.scenes.scene2d.ui.Container;
import com.badlogic.gdx.scenes.scene2d.ui.Image;

import java.util.ArrayList;
import java.util.Random;

import cat.xtec.ioc.helpers.AssetManager;
import cat.xtec.ioc.utils.Methods;
import cat.xtec.ioc.utils.Settings;

public class ScrollHandler extends Group {

    // Fondo de pantalla
    Background bg, bg_back;

    // Asteroides
    int numAsteroids;
    ArrayList<Asteroid> asteroids;

    // BonusNormal  <------
    int numBonusNormal, numBonusEspecial;
    ArrayList<BonusNormal> bonusNormal;
    ArrayList<BonusEspecial> bonusEspecial;

    // Objeto random
    Random r;

    //Container
    Container container;


    public ScrollHandler() {
        // Creamos los dos fondos
        bg = new Background(0, 0, Settings.GAME_WIDTH * 2, Settings.GAME_HEIGHT, Settings.BG_SPEED);
        bg_back = new Background(bg.getTailX(), 0, Settings.GAME_WIDTH * 2, Settings.GAME_HEIGHT, Settings.BG_SPEED);

        // Añadimos el fondo (actors) al grupo
        addActor(bg);
        addActor(bg_back);

        // Creamos el objeto random
        r = new Random();

        // Comenzamos con 3 asteroides
        numAsteroids = 3;

        // Numero de bonus normal
        numBonusNormal = 2;

        // Número de bonus especial
        numBonusEspecial = 1;

        // Creamos el arraylist de asteroide
        asteroids = new ArrayList<>();

        // Creamos el arraylist de bonusNormal
        bonusNormal = new ArrayList<>();

        // Creamos el arrayList de bonusEspecial
        bonusEspecial = new ArrayList<>();

        // Definimos una medida aleatoria entre el minimo y el maximo
        float newSize = Methods.randomFloat(Settings.MIN_ASTEROID, Settings.MAX_ASTEROID) * 34;

        // Añadimo el primer asteroide al array i al grupo
        Asteroid asteroid = new Asteroid(Settings.GAME_WIDTH, r.nextInt(Settings.GAME_HEIGHT - (int) newSize), newSize, newSize, Settings.ASTEROID_SPEED);
        asteroids.add(asteroid);
        addActor(asteroid);

        // Des de el segundo hasta el último asteroide
        for (int i = 1; i < numAsteroids; i++) {
            // Creamos la medida aleatoria
            newSize = Methods.randomFloat(Settings.MIN_ASTEROID, Settings.MAX_ASTEROID) * 34;
            // Añadimos el asteroide
            asteroid = new Asteroid(asteroids.get(asteroids.size() - 1).getTailX() + Settings.ASTEROID_GAP, r.nextInt(Settings.GAME_HEIGHT - (int) newSize), newSize, newSize, Settings.ASTEROID_SPEED);
            // Añadimos el asteroide al arraylist
            asteroids.add(asteroid);
            // Añadimo el asteroide al grupo de actores
            addActor(asteroid);
        }

        // Añadimos el primer bonusNormal al array y al grupo
        BonusNormal bn = new BonusNormal(Settings.GAME_WIDTH, Settings.GAME_HEIGHT - 16, 16, 16, Settings.SCORE_SPEED);
        bonusNormal.add(bn);
        addActor(bn);

        // Añidimos a partir del segundo bonusNormal <------
        for (int i = 1; i < numBonusNormal; i++) {
            bn = new BonusNormal(bonusNormal.get(bonusNormal.size() - 1).getTailX() + Settings.ASTEROID_GAP, r.nextInt(Settings.GAME_HEIGHT - (int) 16), 16, 16, Settings.SCORE_SPEED);
            bonusNormal.add(bn);
            addActor(bn);
        }

        // Añadimos el primer bonusEspecial
        BonusEspecial be = new BonusEspecial(Settings.GAME_WIDTH, Settings.GAME_HEIGHT - 16, 16, 16, Settings.ASTEROID_SPEED);
        bonusEspecial.add(be);
        addActor(be);



    }

    @Override
    public void act(float delta) {
        super.act(delta);
        // Si algún elemento se encuentra fuera de la pantalla, hacemos un reset del mismo
        if (bg.isLeftOfScreen()) {
            bg.reset((bg_back.getTailX()));
        } else if (bg_back.isLeftOfScreen()) {
            bg_back.reset(bg.getTailX());
        }

        for (int i = 0; i < asteroids.size(); i++) {
            Asteroid asteroid = asteroids.get(i);
            if (asteroid.isLeftOfScreen()) {
                if (i == 0) {
                    asteroid.reset(asteroids.get(asteroids.size() - 1).getTailX() + Settings.ASTEROID_GAP);
                } else {
                    asteroid.reset(asteroids.get(i - 1).getTailX() + Settings.ASTEROID_GAP);
                }
            }
        }

        // <------------
        for (int i = 0; i < bonusNormal.size(); i++) {
            BonusNormal bn = bonusNormal.get(i);
            if (bn.isLeftOfScreen()) {
                if (i == 0) {
                    bn.reset(bonusNormal.get(bonusNormal.size() - 1).getTailX() + Settings.ASTEROID_GAP);
                } else {
                    bn.reset(bonusNormal.get(i - 1).getTailX() + Settings.ASTEROID_GAP);
                }
            }
        }

        for (int i = 0; i < bonusEspecial.size(); i++) {
            BonusEspecial be = bonusEspecial.get(i);
            if (be.isLeftOfScreen()) {
                if (i == 0) {
                    be.reset(bonusEspecial.get(bonusEspecial.size() - 1).getTailX() + Settings.ASTEROID_GAP);
                } else {
                    be.reset(bonusEspecial.get(i - 1).getTailX() + Settings.ASTEROID_GAP);
                }
            }
        }

    }

    /**
     * Método que comprueba si algún asteroide colisiona con la nave.
     * En caso de que alguno colisione, retornaremos true
     * @param nau
     * @return
     */
    public boolean collides (Superman nau) {
        // Comprovamos las collidesBonusNormal entre cada asteroide y la nave
        for (Asteroid asteroid: asteroids) {
            if (asteroid.collides(nau)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Método que verifica si ha habido una colisión con los bonus normales
     * @param nau
     * @return
     */
    public boolean collidesBonusNormal(Superman nau) {
        //Comprobamos las collidesBonusNormal con los bonusNormal
        for (BonusNormal bn: bonusNormal) {
            if (bn.collides(nau)) {
                // Si hay colisión resetemos
                bn.reset(0.0f);
                return true;
            }
        }
        return false;
    }

    /**
     * Método que verifica si ha habido una colisión con los bonus especial
     * @param nau
     * @return
     */
    public boolean collidesBonusEspecial(Superman nau) {
        //Comprobamos las collidesBonusNormal con los bonusNormal
        for (BonusEspecial be: bonusEspecial) {
            if (be.collides(nau)) {
                // Si hay colisión resetemos
                //be.addAction(Actions.sequence(Actions.scaleTo(1.5f, 1.5f, 0.2f), Actions.scaleTo(1,1,0.2f)));
                be.reset(0.0f);
                return true;
            }
        }
        return false;
    }


    public void reset() {
        // Posem el primer asteroid fora de la pantalla per la dreta
        asteroids.get(0).reset(Settings.GAME_WIDTH);
        // Calculem les noves posicions de la resta d'asteroids.
        for (int i = 1; i < asteroids.size(); i++) {
            asteroids.get(i).reset(asteroids.get(i - 1).getTailX() + Settings.ASTEROID_GAP);
        }

        // Ponemos el primer bonusNormal fuera de la pantalla por la derecha
        bonusNormal.get(0).reset(Settings.GAME_WIDTH);
        // Calculamos las nuevas posiciones del resto de bonusNormal
        for (int i = 1; i < bonusNormal.size(); i++) {
            bonusNormal.get(i).reset(bonusNormal.get(i - 1).getTailX() + Settings.ASTEROID_GAP);
        }

        // Ponemos el primer bonusEspecial fuera de la pantalla por la derecha
        bonusEspecial.get(0).reset(Settings.GAME_WIDTH);
        // Calculamos las nuevas posiciones del resto de bonusEspecial
        for (int i = 1; i < bonusEspecial.size(); i++) {
            bonusEspecial.get(i).reset(bonusEspecial.get(i - 1).getTailX() + Settings.ASTEROID_GAP);
        }
    }


    // Getter
    public ArrayList<Asteroid> getAsteroids() {
        return  asteroids;
    }

    public ArrayList<BonusNormal> getBonusNormal() {
        return bonusNormal;
    }

    public ArrayList<BonusEspecial> getBonusEspecial() {
        return bonusEspecial;
    }

}

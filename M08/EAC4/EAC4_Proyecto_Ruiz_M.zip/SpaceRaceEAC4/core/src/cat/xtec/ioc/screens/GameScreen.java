package cat.xtec.ioc.screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.GlyphLayout;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.actions.Actions;
import com.badlogic.gdx.scenes.scene2d.ui.Container;
import com.badlogic.gdx.utils.viewport.Viewport;

import java.util.ArrayList;

import cat.xtec.ioc.helpers.AssetManager;
import cat.xtec.ioc.helpers.InputHandler;
import cat.xtec.ioc.objects.ScrollHandler;
import cat.xtec.ioc.objects.Superman;
import cat.xtec.ioc.utils.Settings;
import cat.xtec.ioc.objects.*;

public class GameScreen implements Screen {

    // Estado del juego
    public enum GameState {
        READY, RUNNING, GAMEOVER
    }

    private GameState currentState;
    private Stage stage;
    private Superman superman;
    private ScrollHandler scrollHandler;
    public static Pause pause;

    // Representación de figuras geométricas
    private ShapeRenderer shapeRenderer;
    // Para obtener el batch del "stage"
    private Batch batch;

    // Para controlar la animación de la explosión
    private float explosionTime = 0;

    // Preparamos el textlayout para escribir texto
    public static GlyphLayout textLayout, textLayoutPuntuacion;


    // Para guardar la puntuación después del pause
    public static int puntuacion = 0;
    // Marcador superior
    public static int marcador;
    public static Container container;

    /**
     * Constructor
     */
    public GameScreen(Batch prevBatch, Viewport prevViewport) {

        // Reseteamos la puntuacion del juego
        AssetManager.puntActual.putInteger("puntuacion", 0);
        AssetManager.puntActual.flush();
        marcador = 0;

        // Iniciamos la música
        AssetManager.music.play();

        // Creamos el ShapeRenderer
        shapeRenderer = new ShapeRenderer();

        // Creamos el "stage y le asignamos el viwport"
        stage = new Stage(prevViewport, prevBatch);
        // Recuperamos el batch para servirlo posteriormente
        batch = stage.getBatch();

        // Creamos la nave y el resto de objetos
        superman = new Superman(Settings.SUPERMAN_STARTX,
                Settings.SUPERMAN_STARTY,
                Settings.SUPERMAN_WIDTH,
                Settings.SUPERMAN_HEIGHT);
        scrollHandler = new ScrollHandler();

        // Instanciamos el botón de pause y lo posicionamos
        pause = new Pause(Settings.GAME_WIDTH - 18, 2, 16, 16);

        // Inicializamos el contenedor de la puntuación del marcador
        container = new Container(AssetManager.marcador);
        container.setTransform(true);
        container.center();
        container.setPosition(AssetManager.marcador.getX()+50, AssetManager.marcador.getY()+10);

        // Añadimos los actores al "stage"
        stage.addActor(scrollHandler);
        stage.addActor(superman);
        stage.addActor(pause);
        stage.addActor(container);

        //Damos nombre al actor
        superman.setName("superman");

        //Damos nombre al actor pause
        pause.setName("Pausa");

        // Iniciamos el texto en el estado READY
        textLayout = new GlyphLayout();
        textLayout.setText(AssetManager.font, "Are you\nReady?");

        // Iniciamos el marcador
        textLayoutPuntuacion = new GlyphLayout();

        // Iniciamos el estado inicial
        currentState = GameState.READY;

        // Asignamos como gestor de entrada la clase "InputHandler"
        Gdx.input.setInputProcessor(new InputHandler(this));
    }


    /**
     * Método para dibujar los elementos.
     */
    private void drawElements(){

        // Recogemos las propiedades del Batch del "Stage"
        shapeRenderer.setProjectionMatrix(batch.getProjectionMatrix());
        // Inicializamo sl shaperenderer
        //shapeRenderer.begin(ShapeRenderer.ShapeType.Filled);
        shapeRenderer.begin(ShapeRenderer.ShapeType.Line);

        // Definimos el color (verde)
        shapeRenderer.setColor(new Color(0, 1, 0, 1)); // Ojo con la importación

        // Pintamos la nave
        shapeRenderer.rect(superman.getX(), superman.getY(), superman.getWidth(), superman.getHeight());

        // Pintamos el pause
        shapeRenderer.rect(pause.getX(), pause.getY(), pause.getWidth(), pause.getHeight());

        // Recogemos todos los Asteroid
        ArrayList<Asteroid> asteroids = scrollHandler.getAsteroids();
        Asteroid asteroid;

        for (int i = 0; i < asteroids.size(); i++) {
            asteroid = asteroids.get(i);
            switch (i) {
                case 0:
                    shapeRenderer.setColor(1,0,0,1);
                    break;
                case 1:
                    shapeRenderer.setColor(0,0,1,1);
                    break;
                case 2:
                    shapeRenderer.setColor(1,1,0,1);
                    break;
                default:
                    shapeRenderer.setColor(1,1,1,1);
                    break;
            }
            shapeRenderer.circle(asteroid.getX() + asteroid.getWidth()/2, asteroid.getY() + asteroid.getWidth()/2, asteroid.getWidth()/2);
        }

        shapeRenderer.end();
    }



     @Override
    public void show() {

    }

    @Override
    public void render(float delta) {
        // Dibujamos y actualizamos todos los actores del "stage"
        stage.draw();

        // Depenent de l'estat del joc farem unes accions o unes altres
        switch (currentState) {
            case GAMEOVER:
                updateGameOver(delta);
                break;
            case RUNNING:
                // Si presionamos en cualquier parte de la pantalla después del pause...
                renaudar();
                updateRunning(delta);
                break;
            case READY:
                updateReady();
                break;
        }

    }

    public void renaudar() {
        if(Gdx.input.isTouched()) {
            container.setVisible(true);
            pause.setVisible(true);
            AssetManager.music.setVolume(0.2f);
        }
    }

    private void updateReady() {
        // Dibuixem el marcador al centre de la pantalla

        // Resetar puntuaciones
        /*AssetManager.puntActual.putInteger("puntuacion", 0);
        AssetManager.puntActual.flush();
        AssetManager.puntMax.putInteger("puntMax", 0);
        AssetManager.puntMax.flush();*/

        batch.begin();
        AssetManager.font.draw(
                batch,
                textLayout,
                (Settings.GAME_WIDTH / 2) - textLayout.width / 2,
                (Settings.GAME_HEIGHT / 2) - textLayout.height / 2);
        batch.end();
    }


    private void updateRunning(float delta)  {
        stage.act(delta);

        // Si hay una colisión con un asteroide...
        if (scrollHandler.collides(superman)) {

            pause.setVisible(false);
            container.setVisible(false);
            AssetManager.explosionSound.play();

            /*AssetManager.puntActual.putInteger("puntuacion", marcador);
            AssetManager.puntActual.flush();*/

            // Mostramos el score de la partida
            puntuacion(marcador);
            // Reseteamos el marcador
            marcador = 0;
            // Cuando volvemos a iniciar el juego después del gameover, reseteamos el marcador
            AssetManager.marcador.setText("Puntuacion: " + marcador);

            // Si hi ha hagut col·lisió: Reproduïm l'explosió i posem l'estat a GameOver
            stage.getRoot().findActor("superman").remove();
            textLayout.setText(AssetManager.font, "Game Over :'(");
            currentState = GameState.GAMEOVER;

        // Si hay una colisión con un bonus normal...
        } else if(scrollHandler.collidesBonusNormal(superman)) {
            // Hacemos sonar el coin
            AssetManager.coinBonus.play();

            // Actualizamos el marcador
            marcador += Settings.SCORE_INCREASE_NORMAL;
            AssetManager.marcador.setText("Puntuacion: " + marcador);

            // Guarmos la puntación actual
            AssetManager.puntActual.putInteger("puntuacion", marcador);
            AssetManager.puntActual.flush();

            // Si la puntuación Máxima es menor que el marcador actual, guardamos el nuevo Score
            if(AssetManager.puntMax.getInteger("puntMax") < marcador) {
                AssetManager.puntMax.putInteger("puntMax", marcador);
                AssetManager.puntMax.flush();
            }


        } else if(scrollHandler.collidesBonusEspecial(superman)) {
            // Hacemos sonar el coin
            AssetManager.coinBonus.play();

            // Actualizamos el marcador
            marcador += Settings.SCORE_INCREASE_ESPECIAL;
            AssetManager.marcador.setText("Puntuacion: " + marcador);

            // Guarmos la puntación actual
            AssetManager.puntActual.putInteger("puntuacion", marcador);
            AssetManager.puntActual.flush();

            // Si la puntuación Máxima es menor que el marcador actual, guardamos el nuevo Score
            if(AssetManager.puntMax.getInteger("puntMax") < marcador) {
                AssetManager.puntMax.putInteger("puntMax", marcador);
                AssetManager.puntMax.flush();
            }

            // Si cogemos un bonus redimensionamos la puntuación
            container.addAction(Actions.sequence(Actions.scaleTo(1.5f, 1.5f, 0.5f), Actions.scaleTo(1,1,0.5f)));
        }

    }


    private void updateGameOver(float delta) {
        stage.act(delta);

        batch.begin();
        AssetManager.font.draw(batch, textLayout, (Settings.GAME_WIDTH - textLayout.width) / 2, (Settings.GAME_HEIGHT - textLayout.height) / 2);

        // Si hi ha hagut col·lisió: Reproduïm l'explosió i posem l'estat a GameOver
        batch.draw((TextureRegion) AssetManager.explosionAnim.getKeyFrame(explosionTime, false), (superman.getX() + superman.getWidth() / 2) - 32, superman.getY() + superman.getHeight() / 2 - 32, 64, 64);
        // Mostramos la puntuación final
        AssetManager.fontScore.draw(batch, textLayoutPuntuacion, Settings.GAME_WIDTH/2 - textLayoutPuntuacion.width/2, 100);
        batch.end();
        explosionTime += delta;
    }

    /**
     * Método que muestra un mensaje dependiendo de la puntuación
     * @param puntuacion
     */
    public void puntuacion(int puntuacion) {
        if (puntuacion < 100) {
            textLayoutPuntuacion.setText(AssetManager.fontScore,
                    "Score: " + puntuacion + "\nEres un manta");
        } else if (puntuacion >= 150) {
            textLayoutPuntuacion.setText(AssetManager.fontScore,
                    "Score: " + puntuacion + "\nEres un crack!!");
        } else if (puntuacion < 150 || puntuacion >= 100) {
            textLayoutPuntuacion.setText(AssetManager.fontScore,
                    "Score: " + puntuacion + "\nUsuario inexperto");
        }
    }

    public void reset() {

        // Posem el marcador d'inici
        textLayout.setText(AssetManager.font, "Are you\nReady?");
        // Cridem als restart dels elements.
        superman.reset();
        scrollHandler.reset();

        // Posem l'estat a 'Ready'
        currentState = GameState.READY;

        // Afegim la nau a l'stage
        stage.addActor(superman);
        stage.addActor(container);
        stage.addActor(pause);


        // Posem a 0 les variables per controlar el temps jugat i l'animació de l'explosió
        explosionTime = 0.0f;

    }


    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {
        shapeRenderer.dispose();
        stage.dispose();
        batch.dispose();

    }

    // Getters

    public Stage getStage() {
        return stage;
    }

    public Superman getSpacecraft() {
        return superman;
    }

    public ScrollHandler getScrollHandler() {
        return scrollHandler;
    }

    public GameState getCurrentState() {
        return currentState;
    }

    public void setCurrentState(GameState currentState) {
        this.currentState = currentState;
    }



}

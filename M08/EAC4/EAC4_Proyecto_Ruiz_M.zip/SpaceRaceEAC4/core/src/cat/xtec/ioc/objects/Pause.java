package cat.xtec.ioc.objects;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.Touchable;

import cat.xtec.ioc.helpers.AssetManager;
import cat.xtec.ioc.utils.Settings;

public class Pause  extends Actor {

    private Vector2 position;
    private int width, height;

    // Rectangulo que representará la nave
    private Rectangle collisionRect;

    public Pause (float x, float y ,int width, int height) {
        this.width = width;
        this.height = height;

        position = new Vector2(x, y);
        // Creamos el rectangulo de collidesBonusNormal
        collisionRect = new Rectangle();

        setBounds(position.x, position.y, width, height);
        setTouchable(Touchable.enabled);
    }

    public void act(float delta) {
        super.act(delta);

        collisionRect.set(position.x, position.y, width, height);

        // HIT
        setBounds(position.x, position.y, width, height);
    }

    @Override
    public void draw(Batch batch, float parentAlpha) {
        super.draw(batch, parentAlpha);
        batch.draw(getPauseRegion(), position.x, position.y, width, height);

    }

    public TextureRegion getPauseRegion() {
        return AssetManager.pause;
    }

    public void reset() {
        // La posem a la posició inicial i a l'estat normal
        /*position.x = Settings.SUPERMAN_STARTX;
        position.y = Settings.SUPERMAN_STARTY;
        direction = SUPERMAN_STRAIGHT;*/
        collisionRect = new Rectangle();
    }

    // Getters de los atributos principales
    public float getX() {
        return position.x;
    }

    public float getY() {
        return position.y;
    }

    public float getWidth() {
        return width;
    }

    public float getHeight() {
        return height;
    }

    public Rectangle getCollisionRect() {
        return collisionRect;
    }
}

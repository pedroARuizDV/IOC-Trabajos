package cat.xtec.ioc.objects;

import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.scenes.scene2d.Actor;

public class Scrollable extends Actor {

    protected Vector2 position; //Vector de posicion
    protected float velocity; //Velocidad del elemento
    protected float width; //ancho de los elementos
    protected float height; // alto delos elementos
    protected boolean leftOfScreen; // para saber si el elemento está fuera de la pantalla cuando sobrepasa el 0 del eje X

    /**
     * Constructor
     * @param x
     * @param y
     * @param width
     * @param height
     * @param velocity
     */
    public Scrollable (float x, float y, float width, float height, float velocity) {
        position = new Vector2(x, y);
        this.velocity = velocity;
        this.width = width;
        this.height = height;
        leftOfScreen = false;
    }

    /**
     * Método que se encarga de desplazar el elemento en el eje X.
     * Controla la variable boolean "leftOfScreen" y la pone en true
     * @param delta
     */
    public void act(float delta) {
        super.act(delta);
        // Desplazamos el objeto en el eje de "X"
        position.x += velocity * delta;

        // Si se encuentra fuera de la pnatalla, cambiamos la variable a true
        if (position.x + width < 0) {
            leftOfScreen = true;
        }
    }

    /**
     * Asigna una nueva posición al elemento y pone a "false" "leftOfScreen"
     * @param newX
     */
    public void reset (float newX) {
        position.x = newX;
        leftOfScreen = false;
    }

    /**
     * Getter
     * @return
     */
    public boolean isLeftOfScreen() {
        return leftOfScreen;
    }

    /**
     * Retorna la posición del elemento mas su ancho.
     * @return
     */
    public float getTailX() {
        return position.x + width;
    }

    /**
     * Getter posicion X
     * @return
     */
    public float getX() {
        return position.x;
    }

    /**
     * Getter posicion Y
     * @return
     */
    public float getY() {
        return position.y;
    }

    /**
     * Getter ancho
     * @return
     */
    public float getWidth() {
        return width;
    }

    /**
     * Getter alto
     * @return
     */
    public float getHeight() {
        return height;
    }


}

package cat.xtec.ioc.objects;

import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.math.Vector2;
import cat.xtec.ioc.helpers.AssetManager;
import cat.xtec.ioc.utils.Settings;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.scenes.scene2d.Touchable;

public class Superman extends Actor {

    // Diferentes posiciones de la "SpaceCraft": recta, subiendo y bajando
    public static final int SUPERMAN_STRAIGHT = 0; //derecha
    public static final int SUPERMAN_UP = 1; //subiendo
    public static final int SUPERMAN_DOWN = 2; // bajando




    // Parámetros de la "Superman"
    private Vector2 position;
    private int width, height;
    private int direction;

    // Rectangulo que representará la nave
    private Rectangle collisionRect;


    private SpriteBatch spriteBatch;



    /**
     * Constructor
     * @param x
     * @param y
     * @param width
     * @param height
     */
    public Superman(float x, float y, int width, int height) {
        // Inicializamos los argumentos segun la llamada del constructor
        this.width = width;
        this.height = height;
        position = new Vector2(x, y);

        // Iniciamos la "Superman" al estado normal
        direction = SUPERMAN_STRAIGHT;

        // Creamos el rectangulo de collidesBonusNormal
        collisionRect = new Rectangle();

        // Para la gestión de hit
        setBounds(position.x, position.y, width, height);
        setTouchable(Touchable.enabled);

        spriteBatch = new SpriteBatch();

    }

    @Override
    public void act(float delta) {
        super.act(delta);

        // Movemos la "Superman" dependiendo de la dirección
        // controlando que no salga del la pantalla
        switch (direction) {
            case SUPERMAN_UP: // Controlamos la subida
               if (this.position.y - Settings.SUPERMAN_VELOCITY * delta >= 0) {
                   this.position.y -= Settings.SUPERMAN_VELOCITY * delta;
               }
               break;
            case SUPERMAN_DOWN: // Controlamos la bajada
                if (this.position.y + height + Settings.SUPERMAN_VELOCITY * delta <= Settings.GAME_HEIGHT) {
                   this.position.y += Settings.SUPERMAN_VELOCITY * delta;
                }
                break;
            case SUPERMAN_STRAIGHT:
                break;
        }
        collisionRect.set(position.x, position.y + 3, width, 12);

        // HIT
        setBounds(position.x, position.y, width, height);
    }



    @Override
    public void draw(Batch batch, float parentAlpha) {
        super.draw(batch, parentAlpha);
        //batch.draw(AssetManager.superman, position.x, position.y, width, height);
        batch.draw(getSpacecraftTexture(), position.x, position.y, width, height);
    }

    /**
     * Obtenemos el TextureRegion dependiendo de la posición de la superman
     * @return
     */
    public TextureRegion getSpacecraftTexture() {
        switch (direction) {
            case SUPERMAN_STRAIGHT:
                return AssetManager.superman;
            case SUPERMAN_UP:
                return AssetManager.supermanUp;
            case SUPERMAN_DOWN:
                return AssetManager.supermanDown;
            default:
                return AssetManager.superman;
        }
    }

    public void reset() {
        // La posem a la posició inicial i a l'estat normal
        position.x = Settings.SUPERMAN_STARTX;
        position.y = Settings.SUPERMAN_STARTY;
        direction = SUPERMAN_STRAIGHT;
        collisionRect = new Rectangle();
    }

    // Getters de los atributos principales
    public float getX() {
        return position.x;
    }

    public float getY() {
        return position.y;
    }

    public float getWidth() {
        return width;
    }

    public float getHeight() {
        return height;
    }

    // Cambiamos la dirección de la "Superman": Sube
    public void goUp() {
        direction = SUPERMAN_UP;
    }

    // Cambiamos la dirección de la "Superman": Baja
    public void goDown() {
        direction = SUPERMAN_DOWN;
    }

    // Ponemos la "Superman" a su estado original
    public void goStraight() {
        direction = SUPERMAN_STRAIGHT;
    }

    public Rectangle getCollisionRect() {
        return collisionRect;
    }



}

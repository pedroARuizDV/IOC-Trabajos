package cat.xtec.ioc.helpers;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Preferences;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.files.FileHandle;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.ui.Label;


public class AssetManager {

    // Texturas
    public static Texture sheet, sheet_bonus, sheet_pause, backgroundTexture, superTexture;


    // Nave y fondo
    public static TextureRegion superman, supermanDown, supermanUp, background, pause, bonus_normal, bonus_especial;

    // Preferences
    public static Preferences puntActual, puntMax;

    // Asteroide
    public static TextureRegion[] asteroid;
    public static Animation asteroidAnim;

    // Bonus - Animación
    public static Animation bonus_normal_Anim, bonus_especial_Anim;

    // Explosión
    public static TextureRegion[] explosion;
    public static Animation explosionAnim;

    // Sonidos
    public static Sound explosionSound, coinBonus;
    public static Music music;

    // Fuente
    public static BitmapFont font, fontPuntuacion, fontScore, fontPuntMax;


    /////
    public static Label.LabelStyle textStylePuntuacion;
    public static Label marcador;



    public static void load() {

        // Cargamos la Textura del pause y el textureregion
        sheet_pause = new Texture(Gdx.files.internal("pause_icon32.png"));
        sheet_pause.setFilter(Texture.TextureFilter.Nearest, Texture.TextureFilter.Nearest);

        //supermanUp = new TextureRegion(sheet_ryu, 27, 0, 27, 36);

        pause = new TextureRegion(sheet_pause, 0,0, 32, 32);
        pause.flip(false, true);
        ////////////////////

        // Cargamos las texturas y le aplicamos el método de escalado "nearest"
        sheet = new Texture(Gdx.files.internal("sheet.png"));
        sheet.setFilter(Texture.TextureFilter.Nearest, Texture.TextureFilter.Nearest);

        // Cargamos las preferencias para poder guardar y recuperar la puntuación
        puntActual = Gdx.app.getPreferences("puntuacion");
        puntMax = Gdx.app.getPreferences("puntMax");


        // Cargamos las texturas del bonus
        sheet_bonus = new Texture(Gdx.files.internal("bonus.png"));
        sheet_bonus.setFilter(Texture.TextureFilter.Nearest, Texture.TextureFilter.Nearest);

        // Cargamos las textura de superman
        superTexture = new Texture(Gdx.files.internal("sheet_super.png"));
        superTexture.setFilter(Texture.TextureFilter.Nearest, Texture.TextureFilter.Nearest);

        // Cargamos el textureRegion de Superman en estado normal
        superman = new TextureRegion(superTexture, 0, 0, 48, 12);
        superman.flip(false, true);

        // Cargamos el textureRegion de Superman cuando sube
        supermanUp = new TextureRegion(superTexture, 48, 0, 48, 12);
        supermanUp.flip(false, true);;

        // Cargamos el textureRegion de Superman cuando baja
        supermanDown = new TextureRegion(superTexture, 96, 0, 48, 12);
        supermanDown.flip(false, true);


        // Cargamos el TextureRegion del bonus_normal
        bonus_normal = new TextureRegion(sheet_bonus, 64,0, 64,64);
        bonus_normal.flip(false, true);

        // Cargamos el TextureRegion del bonus_especial
        bonus_especial = new TextureRegion(sheet_bonus, 0,0, 64,64);
        bonus_especial.flip(false, true);

        // Cargamos la animación del bonus normal
        bonus_normal_Anim = new Animation(0.2f, bonus_normal);
        bonus_normal_Anim.setPlayMode(Animation.PlayMode.LOOP_REVERSED);

        // Cargamos la animación del bonus especial
        bonus_especial_Anim = new Animation(0.2f, bonus_especial);
        bonus_especial_Anim.setPlayMode(Animation.PlayMode.LOOP_REVERSED);


        asteroid = new TextureRegion[15];
        for(int i = 0; i < asteroid.length; i++) {
            asteroid[i] = new TextureRegion(sheet, i * 34, 15, 34, 34);
            asteroid[i].flip(false, true);
        }

        // Creamos la animación del asteroide y hacemos que se ejecute continuamente en sentido anti-horario
        asteroidAnim = new Animation(0.05f, asteroid);
        asteroidAnim.setPlayMode(Animation.PlayMode.LOOP_REVERSED);


        // Creamos los 16 estados de la explosión
        explosion = new TextureRegion[16];
        // Cargamos los 16 estados de las explosiones
        int index = 0;
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 8; j++) {
                explosion[index++] = new TextureRegion(sheet, j * 64,  i * 64 + 49, 64, 64);
            }
        }

        // finalmente creamos la animación
        explosionAnim = new Animation(0.04f, explosion);

        // Fonde pantalla
        //Tamaño 480x135 pixeles
        backgroundTexture = new Texture(Gdx.files.internal("background.png"));

        // Cargamos el TextureRegion para el background
        background = new TextureRegion(backgroundTexture, 0, 0, 480, 135);
        background.flip(false, true);

        /******************************* Sounds *************************************/
        // Sonidos explosiones
        explosionSound = Gdx.audio.newSound(Gdx.files.internal("sounds/explosion.wav"));
        coinBonus = Gdx.audio.newSound(Gdx.files.internal("sounds/coinBonus.wav"));

        // Musica del juego
        music = Gdx.audio.newMusic(Gdx.files.internal("sounds/Fighting.ogg"));
        music.setVolume(0.2f);
        music.setLooping(true);

        /******************************* Text *************************************/
        // Font Space
        FileHandle fontFile = Gdx.files.internal("fonts/nueva.fnt");
        font = new BitmapFont(fontFile, true);
        font.getData().setScale(0.4f);

        // Font Score
        fontScore = new BitmapFont(fontFile, true);
        fontScore.getData().setScale(0.3f);

        // Font puntuación máxima
        fontPuntMax = new BitmapFont(fontFile, true);
        fontPuntMax.getData().setScale(0.3f);

        // Font Marcador
        fontPuntuacion = new BitmapFont(fontFile, true);
        fontPuntuacion.getData().setScale(0.3f);
        textStylePuntuacion = new Label.LabelStyle(fontPuntuacion, null);

        // Font Marcador
        marcador = new Label("Puntuacion: " + 0, textStylePuntuacion);
        marcador.setPosition(2, 2);

    }


    public static void dispose() {
        // Descartamos los recursos
        sheet.dispose();
        explosionSound.dispose();
        music.dispose();
        sheet_bonus.dispose();
        backgroundTexture.dispose();
        sheet_pause.dispose();
        font.dispose();
        fontScore.dispose();
        fontPuntMax.dispose();
        fontPuntuacion.dispose();
        superTexture.dispose();
    }


}

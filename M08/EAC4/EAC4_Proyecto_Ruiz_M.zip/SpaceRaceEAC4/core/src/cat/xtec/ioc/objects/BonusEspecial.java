package cat.xtec.ioc.objects;

import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.math.Circle;
import com.badlogic.gdx.math.Intersector;
import com.badlogic.gdx.scenes.scene2d.actions.RepeatAction;
import com.badlogic.gdx.scenes.scene2d.actions.RotateByAction;

import java.util.Random;

import cat.xtec.ioc.helpers.AssetManager;
import cat.xtec.ioc.utils.Settings;

public class BonusEspecial extends Scrollable {

    private Circle collisionCircle;
    int bonus;
    Random r;

    /**
     * Constructor
     *
     * @param x
     * @param y
     * @param width
     * @param height
     * @param velocity
     */
    public BonusEspecial(float x, float y, float width, float height, float velocity) {
        super(x, y, width, height, velocity);

        // Creamos el circulo para controlar las collidesBonusNormal
        collisionCircle = new Circle();

        r = new Random();
        bonus = r.nextInt(1);
        setOrigin();

        // Rotación
        RotateByAction rotateAction = new RotateByAction();
        rotateAction.setAmount(-90f);
        rotateAction.setDuration(0.2f);

        // Acción de repetición
        RepeatAction repeat = new RepeatAction();
        repeat.setAction(rotateAction);
        repeat.setCount(RepeatAction.FOREVER);
        this.addAction(repeat);
    }

    @Override
    public void act(float delta) {
        super.act(delta);

        // Actualizamos el circulo de collidesBonusNormal (punto central del asteroide y del radio)
        collisionCircle.set(position.x + width / 2.0f, position.y + width / 2.0f, width / 2.0f);
    }


    public void reset (float newX) {
        super.reset(newX);

        width = height = 16;
        position.y = new Random().nextInt(Settings.GAME_HEIGHT - (int) height);
        position.x = Settings.GAME_WIDTH;
        bonus = r.nextInt(1);
        setOrigin();
    }

    public void setOrigin() {
        this.setOrigin(width/2 + 1, height/2);
    }

    @Override
    public void draw(Batch batch, float parentAlpha) {
        super.draw(batch, parentAlpha);
        batch.draw(
                AssetManager.bonus_especial,
                position.x,
                position.y,
                this.getOriginX(),
                this.getOriginY(),
                width,
                height,
                this.getScaleX(),
                this.getScaleY(),
                this.getRotation());
    }

    public boolean collides(Superman nau) {
        if (position.x <= nau.getX() + nau.getWidth()) {
            // Comprobamos si han colisionado siempre que el asteroide se encuentre a la misma altura que el superman
            return (Intersector.overlaps(collisionCircle, nau.getCollisionRect()));
        }
        return false;
    }
}

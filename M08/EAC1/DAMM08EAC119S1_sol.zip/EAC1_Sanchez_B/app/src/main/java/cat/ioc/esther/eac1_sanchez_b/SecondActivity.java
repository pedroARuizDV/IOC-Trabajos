package cat.ioc.esther.eac1_sanchez_b;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        TextView tx = findViewById(R.id.txtEnviat);
        tx.setText(getIntent().getExtras().getString(MainActivity.EXTRA_MSG));
    }
}

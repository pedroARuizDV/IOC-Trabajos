package cat.ioc.esther.eac1_sanchez_b;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText edtSaluda;
    private EditText edtWeb;
    private EditText edtTrucada;
    private EditText edtComparteix;
    private EditText edtEnvia;

    private static final String LOG_TAG_MAIN = "PrimeraPantalla";
    public static final String EXTRA_MSG = "TextEnviat";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edtSaluda = findViewById(R.id.edtSaluda);
        edtWeb = findViewById(R.id.edtWeb);
        edtTrucada = findViewById(R.id.edtTrucada);
        edtComparteix = findViewById(R.id.edtCompartir);
        edtEnvia = findViewById(R.id.edtEnviar);

        Log.i(LOG_TAG_MAIN,"Soc Esther Sanchez");
    }

    public void saluda(View view) {
        String missatge = edtSaluda.getText().toString();
        if (missatge.trim().isEmpty()){
            Toast.makeText(this,getString(R.string.hint_nom), Toast.LENGTH_LONG).show();
        }else {
            missatge =getString(R.string.missatge_benvinguda)+ " " + missatge;
            Toast.makeText(this, missatge, Toast.LENGTH_LONG).show();
        }
    }

    public void obreWeb(View view) {
        String url = edtWeb.getText().toString();
        if (url.trim().isEmpty()){
            Toast.makeText(this,getString(R.string.hint_web), Toast.LENGTH_LONG).show();
        }else {
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setData(Uri.parse(url));
            if (i.resolveActivity(getPackageManager()) != null) {
                startActivity(i);
            } else {
                Log.d(LOG_TAG_MAIN, getString(R.string.error_web));
            }
        }
    }

    public void truca(View view) {
        String telefon = edtTrucada.getText().toString();
        if (telefon.trim().isEmpty()){
            Toast.makeText(this,getString(R.string.hint_trucada), Toast.LENGTH_LONG).show();
        }else {
            Intent i = new Intent(Intent.ACTION_DIAL);
            i.setData(Uri.parse("tel:" + telefon));
            if (i.resolveActivity(getPackageManager()) != null) {
                startActivity(i);
            } else {
                Log.d(LOG_TAG_MAIN, getString(R.string.error_telefon));
            }
        }
    }

    public void comparteix(View view) {
        String text = edtComparteix.getText().toString();
        if (text.trim().isEmpty()){
            Toast.makeText(this,getString(R.string.hint_compartir), Toast.LENGTH_LONG).show();
        }else {
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("text/plain");
            i.putExtra(Intent.EXTRA_TEXT, text);
            if (i.resolveActivity(getPackageManager()) != null) {
                startActivity(Intent.createChooser(i, ""));
            } else {
                Log.d(LOG_TAG_MAIN, getString(R.string.error_compartir));
            }
        }
    }

    public void envia(View view) {
        String text = edtEnvia.getText().toString();
        if (text.trim().isEmpty()){
            Toast.makeText(this,getString(R.string.hint_enviar), Toast.LENGTH_LONG).show();
        }else {
            Intent i = new Intent(this,SecondActivity.class);

            i.putExtra(EXTRA_MSG, text);
            startActivity(i);
        }
    }
}

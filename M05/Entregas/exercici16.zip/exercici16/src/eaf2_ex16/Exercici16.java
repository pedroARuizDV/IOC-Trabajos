package eaf2_ex16;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Button;
import org.eclipse.core.databinding.DataBindingContext;
import org.eclipse.core.databinding.observable.value.IObservableValue;
import org.eclipse.jface.databinding.swt.WidgetProperties;
import org.eclipse.core.databinding.beans.PojoProperties;
import org.eclipse.core.databinding.observable.Realm;
import org.eclipse.jface.databinding.swt.SWTObservables;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;

public class Exercici16 extends Shell {
	
	// CONSTANTES //
	private final String PREU_HORA = "[1-9]{1}|[10-99]{2}|100"; //de 1 a 100
	private final String NUM_HORES = "[1-9]{1}|[10-23]{2}"; //de 0 a 23
	private final String SORTIDA_DOMINICLI = "[0-1]{1}"; //de 0 a 1
	private final String TIPUS_LLICENCIA = "[1-3]{1}"; //de 1-3
	
	private final double MAX_PRECIO_HORAS = 100;
	private final double MIN_PRECIO_HORAS = 1;
	private final double MAX_HORAS = 23;
	private final double MIN_HORAS = 1;
	private final int MIN_LICENCIA = 1;
	private final int MEDIUM_LICENCIA = 2;
	private final int MAX_LICENCIA = 3;
	private final int MAX_SORTIDA = 1;
	private final int MIN_SORTIDA = 0;
	// FIN CONSTANTES //	
	
	private DataBindingContext m_bindingContext;
	private Text preuHora;
	private Text numHores;
	private Text textSortida;
	private Text textLlicencia1;
	private Text textAssistencia;
	private Text textImportTotal;
	private Text textMensaje;
	private Text textLlicencia2;
	private Text textImportLlicencia;
	private Text textImportDomicili;
	private Button btnSeleccionar;
	private Button btnRestablir;
	private Button btnCalcular;	
	
	// Atributos para el c�lculo del importe total
	private double preuAssistencia; 
	private double importLlicencia;
	private double importDomicili;

	/**
	 * Launch the application.
	 * @param args
	 */
	public static void main(String args[]) {
		Display display = Display.getDefault();
		Realm.runWithDefault(SWTObservables.getRealm(display), new Runnable() {
			public void run() {
				try {
					Display display = Display.getDefault();
					Exercici16 shell = new Exercici16(display);
					shell.open();
					shell.layout();
					while (!shell.isDisposed()) {
						if (!display.readAndDispatch()) {
							display.sleep();
						}
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the shell.
	 * @param display
	 */
	public Exercici16(Display display) {
		super(display, SWT.SHELL_TRIM);
		
		Group grpMen = new Group(this, SWT.NONE);
		grpMen.setToolTipText("Introdueix el preu per hora");
		grpMen.setText("Par\u00E0metres Pressupost");
		grpMen.setBounds(10, 10, 693, 106);
		
		Label lblPreu = new Label(grpMen, SWT.NONE);
		lblPreu.setBounds(10, 26, 55, 15);
		lblPreu.setText("Preu hora");
		
		Label lblNmeroDhores = new Label(grpMen, SWT.NONE);
		lblNmeroDhores.setBounds(10, 63, 96, 15);
		lblNmeroDhores.setText("N\u00FAmero d'hores");
		
		preuHora = new Text(grpMen, SWT.BORDER);
		preuHora.setToolTipText("Introduce el precio de cada hora");
		preuHora.setBounds(141, 23, 76, 21);
		
		numHores = new Text(grpMen, SWT.BORDER);
		numHores.setToolTipText("Introduce el n\u00FAmero de horas");
		numHores.setBounds(141, 60, 76, 21);
		
		btnSeleccionar = new Button(grpMen, SWT.NONE);
		btnSeleccionar.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				String msg = null;
				double preuH;
				double numH;
				try {				
					preuH = new Double(preuHora.getText());
					numH = new Double(numHores.getText());
					compruebaPreuHora(preuH, numH);
				}catch(NumberFormatException ex) {
					if(!preuHora.getText().matches(PREU_HORA)) {
						preuHora.setFocus();
						preuHora.selectAll();
						msg = "Debe ser numerico (real) y estar entre 1-100.";
					}else if(!numHores.getText().matches(NUM_HORES)) {
						numHores.setFocus();
						numHores.selectAll();
						msg = "Debe ser numerico (real) y estar entre 1-23.";
					}
					textMensaje.setText("Valor err�neo: " + msg);
				}
			}
		});
		btnSeleccionar.setBounds(262, 56, 75, 25);
		btnSeleccionar.setText("Seleccionar");
		
		Group grpImportPressupost = new Group(this, SWT.NONE);
		grpImportPressupost.setText("Import Pressupost");
		grpImportPressupost.setBounds(10, 145, 693, 311);
		
		Label lblNewLabel = new Label(grpImportPressupost, SWT.NONE);
		lblNewLabel.setBounds(10, 37, 82, 15);
		lblNewLabel.setText("Tipus llic\u00E8ncia");
		
		Label lblNewLabel_1 = new Label(grpImportPressupost, SWT.NONE);
		lblNewLabel_1.setBounds(10, 72, 94, 15);
		lblNewLabel_1.setText("Sortida domicili");
		
		Label lblNewLabel_2 = new Label(grpImportPressupost, SWT.NONE);
		lblNewLabel_2.setBounds(10, 133, 94, 15);
		lblNewLabel_2.setText("Preu assist\u00E8ncia");
		
		Label lblNewLabel_3 = new Label(grpImportPressupost, SWT.NONE);
		lblNewLabel_3.setBounds(10, 280, 67, 15);
		lblNewLabel_3.setText("Import total");
		
		btnCalcular = new Button(grpImportPressupost, SWT.NONE);
		btnCalcular.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				String msg = null;
				int tipusLlicencia;
				int sortida;
				try {					
					tipusLlicencia = new Integer(textLlicencia1.getText());
					sortida = new Integer(textSortida.getText());
					compruebaLlicenciaSortida(tipusLlicencia, sortida);
				}catch(NumberFormatException ex) {
					if(!textLlicencia1.getText().matches(TIPUS_LLICENCIA)) {
						textLlicencia1.setFocus();
						textLlicencia1.selectAll();
						msg = "Debe ser numerico (entero) y estar entre 1-3";
					}else if(!textSortida.getText().matches(SORTIDA_DOMINICLI)) {
						textSortida.setFocus();
						textSortida.selectAll();
						msg = "Debe ser numerico (entero) y estar entre 0-1";
					}
					textMensaje.setText("Valor err�neo: " + msg);
					
				}
				
			}
		});
		btnCalcular.setEnabled(false);
		btnCalcular.setBounds(330, 67, 75, 25);
		btnCalcular.setText("Calcular");	
		
		btnRestablir = new Button(grpImportPressupost, SWT.NONE);
		btnRestablir.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				//Borramos todos los cuadros de texto			
				preuHora.setText("");				
				numHores.setText("");
				textMensaje.setText("");			
				textSortida.setText("");				
				textLlicencia1.setText("");				
				textAssistencia.setText("");				
				textImportTotal.setText("");				
				textMensaje.setText("");				
				textLlicencia2.setText("");				
				textImportLlicencia.setText("");				
				textImportDomicili.setText("");			
				
				//Deshabilitamos men� inferior y habilitamos superior
				habilitarDeshabilitar(true, false, false);
				
				//ponemos el foco en preuHora
				preuHora.setFocus();
				
				//Reiniciamos campos de clase				
				preuAssistencia = 0; 
				importLlicencia = 0;
				importDomicili = 0;
				
			}
		});
		btnRestablir.setEnabled(false);
		btnRestablir.setBounds(237, 67, 75, 25);
		btnRestablir.setText("Restablir");			
		
		textLlicencia1 = new Text(grpImportPressupost, SWT.BORDER);
		textLlicencia1.setToolTipText("Introduce tipo licencia: 1-2-3");
		textLlicencia1.setEnabled(false);
		textLlicencia1.setBounds(138, 34, 76, 21);
		
		textSortida = new Text(grpImportPressupost, SWT.BORDER);
		textSortida.setToolTipText("Introduce 0 si no se ha salido y 1 si se ha salido");
		textSortida.setEnabled(false);
		textSortida.setBounds(138, 69, 76, 21);
		
		textAssistencia = new Text(grpImportPressupost, SWT.BORDER);
		textAssistencia.setEditable(false);
		textAssistencia.setEnabled(false);
		textAssistencia.setBounds(138, 127, 76, 21);
		
		Label lblNewLabel_4 = new Label(grpImportPressupost, SWT.NONE);
		lblNewLabel_4.setBounds(237, 133, 87, 15);
		lblNewLabel_4.setText("Tipus llic\u00E8ncia");
		
		Label lblNewLabel_5 = new Label(grpImportPressupost, SWT.NONE);
		lblNewLabel_5.setBounds(237, 169, 87, 15);
		lblNewLabel_5.setText("Import lic\u00E8ncia");
		
		Label lblNewLabel_6 = new Label(grpImportPressupost, SWT.NONE);
		lblNewLabel_6.setBounds(237, 207, 87, 15);
		lblNewLabel_6.setText("Import domicili");
		
		textImportTotal = new Text(grpImportPressupost, SWT.BORDER);
		textImportTotal.setEditable(false);
		textImportTotal.setEnabled(false);
		textImportTotal.setBounds(138, 280, 76, 21);
		
		textMensaje = new Text(grpImportPressupost, SWT.BORDER);
		textMensaje.setEditable(false);
		textMensaje.setEnabled(false);
		textMensaje.setBounds(237, 280, 446, 21);
		
		textLlicencia2 = new Text(grpImportPressupost, SWT.BORDER);
		textLlicencia2.setEditable(false);
		textLlicencia2.setEnabled(false);
		textLlicencia2.setBounds(353, 127, 330, 21);
		
		textImportLlicencia = new Text(grpImportPressupost, SWT.BORDER);
		textImportLlicencia.setEnabled(false);
		textImportLlicencia.setEditable(false);
		textImportLlicencia.setBounds(353, 166, 76, 21);
		
		textImportDomicili = new Text(grpImportPressupost, SWT.BORDER);
		textImportDomicili.setEnabled(false);
		textImportDomicili.setEditable(false);
		textImportDomicili.setToolTipText("Prueba ayuda");
		textImportDomicili.setBounds(353, 204, 76, 21);
		createContents();
		m_bindingContext = initDataBindings();
	}

	/**
	 * Create contents of the shell.
	 */
	protected void createContents() {
		setText("Presupost T\u00E8cnic Inform\u00E0tic");
		setSize(729, 505);

	}

	@Override
	protected void checkSubclass() {
		// Disable the check that prevents subclassing of SWT components
	}
	protected DataBindingContext initDataBindings() {
		DataBindingContext bindingContext = new DataBindingContext();
		//
		IObservableValue observeEditableTextObserveWidget = WidgetProperties.editable().observe(preuHora);
		IObservableValue editableTextObserveValue = PojoProperties.value("editable").observe(preuHora);
		bindingContext.bindValue(observeEditableTextObserveWidget, editableTextObserveValue, null, null);
		//
		IObservableValue observeEditableTextObserveWidget_1 = WidgetProperties.editable().observe(preuHora);
		IObservableValue textTextObserveValue = PojoProperties.value("text").observe(preuHora);
		bindingContext.bindValue(observeEditableTextObserveWidget_1, textTextObserveValue, null, null);
		//
		return bindingContext;
	}
	
	/**
	 * M�todo que comprueba si los valores pasados por par�metro (preuH, hores) est�n en rago.
	 * Si no est�n en rango, muestra error en consecuencia. Si est�n en rago asigna valor de la 
	 * operaci�n preuH * hores al atributo de clase "preuAssistencia".
	 * 
	 * @param preuH -> Recibe el precio por hora.
	 * @param hores -> Recibo las horas trabajadas.
	 */
	protected void compruebaPreuHora(double preuH, double hores) {
		if(preuH < MIN_PRECIO_HORAS || preuH > MAX_PRECIO_HORAS) {
			textMensaje.setText("Error: El valor debe ser mayor a 0  menor/igual a 100");
			preuHora.setFocus();
			preuHora.selectAll();
		}else if(hores < MIN_HORAS || hores > MAX_HORAS) {
			textMensaje.setText("Error: El valor debe ser mayor a 0 y menor a 24");
			numHores.setFocus();
			numHores.selectAll();
		}else {			
			habilitarDeshabilitar(false, true, false);
			
			//Borramos cuadro texto mensaje y ponemos el focus textLlicencia1
			textMensaje.setText("");
			textLlicencia1.setFocus();
			preuAssistencia = preuH * hores;
		}
	}
	
	/**
	 * M�todo comprueba los par�metros (int tipLlicencia, int sortida) est�n dentro del rango.
	 * Si los par�metros est�n en los rangos permitidos asigna el valor de los atributos7
	 * "preuAssistencia" y "importDomicili".
	 * 
	 * @param tipLlicencia  -> Recibe el tipo de licencia (1-2-3)
	 * @param sortida		-> Recibo 0 si no se ha salido y 1 si se ha salido.
	 */
	protected void compruebaLlicenciaSortida(int tipLlicencia, int sortida) {
				
		if(tipLlicencia < MIN_LICENCIA || tipLlicencia > MAX_LICENCIA) {
			textLlicencia1.setFocus();
			textLlicencia1.selectAll();
			textMensaje.setText("Error: el valor debe ser mayor a 1 o menor/igual a 3");
		}else if(sortida < MIN_SORTIDA || sortida > MAX_SORTIDA) {
			textSortida.setFocus();
			textSortida.selectAll();
			textMensaje.setText("Error: el valor debe ser 0 o 1");
		}else {
			//Si todo ha ido bien borramos cuadro de texto mensaje
			textMensaje.setText("");
			
			//Habilitamos el resto de cajas de texto
			habilitarDeshabilitar(false, true, true);
						
			//Mostramos el valor de preuAssistencia
			textAssistencia.setText("" + preuAssistencia);
			
			//Asignamos importe a domicilio
			if(sortida == 1) {
				importDomicili  = 30;								
			}
			
			//Mostramos importe a domicilio
			textImportDomicili.setText("" + importDomicili);
			
			//Asignamos tipus licencia
			switch(tipLlicencia) {
				case MIN_LICENCIA:
					textLlicencia2.setText("No s�ha instal�lat cap software amb llic�ncia.");	
					break;
				case MEDIUM_LICENCIA:
					textLlicencia2.setText("S�ha instal�lat SO amb llic�ncia.");					
					importLlicencia = 50;
					break;
				case MAX_LICENCIA:
					textLlicencia2.setText("S�ha instal�lat SO amb llic�ncia i Suite ofim�tica amb llic�ncia.");					
					importLlicencia = 100;
					break;					
			}
			
			//Mostramos precio del tipo de licencia
			textImportLlicencia.setText("" + importLlicencia);
			
			//Calculamos importe
			calcularImportTotal();
				
		}
	}
	
	
	/**
	 * M�todo que habilita/deshabilita los diferentes botones/cuadros de texto
	 * @param menuS
	 * @param menuI
	 * @param subMenuI
	 */
	protected void habilitarDeshabilitar(boolean menuS, boolean menuI, boolean subMenuI) {
		//Men� superior (menuS)
		preuHora.setEnabled(menuS);
		numHores.setEnabled(menuS);		
		btnSeleccionar.setEnabled(menuS);
		
		//Men� inferior (menuI)
		textSortida.setEnabled(menuI);
		textLlicencia1.setEnabled(menuI);		
		btnRestablir.setEnabled(menuI);
		btnCalcular.setEnabled(menuI);		
		
		//cajas de texto inferior no editables (subMenuI)
		textAssistencia.setEnabled(subMenuI); //
		textImportTotal.setEnabled(subMenuI); //
		textMensaje.setEnabled(subMenuI); //
		textLlicencia2.setEnabled(subMenuI); //
		textImportLlicencia.setEnabled(subMenuI); //
		textImportDomicili.setEnabled(subMenuI); //
	}
	
	
	/**
	 * M�todo que calcula el importe total
	 */
	protected void calcularImportTotal() {
		double importTotal = preuAssistencia + importLlicencia + importDomicili; 
		textImportTotal.setText(""+importTotal);
	}
	
	
}

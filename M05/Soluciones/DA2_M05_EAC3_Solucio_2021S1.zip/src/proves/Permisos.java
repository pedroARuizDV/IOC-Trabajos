// Fitxer Permisos.java
package proves;
/**
 * Classe que cont� m�todes per determinar els permisos
 * @author �lex Milan
 * @version 1.0.0
 */

public class Permisos {
	
	/**
     * M�tode que converteix un perm�s num�ric en una valor de tipus text.
     * @param permis: perm�s que s'atorga.
     * El perm�s ha der ser un n�mero enter compr�s entre 0 i 9.
     * @throws PermisIncorrecteException si perm�s no est� entre el rang [0,9]
     * @return Permis textual atorgat.
     * 
     */ 
	public static String determinaPermisos(int permis) throws PermisIncorrecteException{
		if(permis>=0 && permis<=9) {
			if (permis==9) return "Total";
			else if (permis>6) return "Alt";
			else if (permis>3) return "Moderat";
			else if (permis>0) return "Baix";
			else return "Sense permisos";
		}
		else throw new PermisIncorrecteException("Permis " + permis + " incorrecte."); 
	}
}
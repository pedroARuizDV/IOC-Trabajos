// Fitxer PermisIncorrecteException.java

package proves;
/**
 * Excepci� que indica que el valor d'un perm�s �s incorrecte.
 * @author �lex Milan
 *
 */

@SuppressWarnings("serial")
public class PermisIncorrecteException extends Exception {
	public PermisIncorrecteException(String missatge) {
		super(missatge);
	}
}
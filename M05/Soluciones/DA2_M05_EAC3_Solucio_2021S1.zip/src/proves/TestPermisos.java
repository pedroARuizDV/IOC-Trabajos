package proves;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TestPermisos {

	@Test
	void test1() throws PermisIncorrecteException {
		assertThrows(PermisIncorrecteException.class, () -> {	Permisos.determinaPermisos(-1);
		});
	}
	@Test
	void test2() throws PermisIncorrecteException {
		assertEquals(Permisos.determinaPermisos(1),"Baix");
	}
	
	@Test
	void test3() throws PermisIncorrecteException {
		assertEquals(Permisos.determinaPermisos(3),"Baix");
	}
	
	@Test
	void test4() throws PermisIncorrecteException {
		assertEquals(Permisos.determinaPermisos(6),"Moderat");
	}
	
	@Test
	void test5() throws PermisIncorrecteException {
		assertEquals(Permisos.determinaPermisos(8),"Alt");
	}
	
	@Test
	void test6() throws PermisIncorrecteException {
		assertEquals(Permisos.determinaPermisos(9),"Total");
	}
	
	@Test
	void test7() throws PermisIncorrecteException {
		assertThrows(PermisIncorrecteException.class, () -> {	Permisos.determinaPermisos(10);
		});
	}

}

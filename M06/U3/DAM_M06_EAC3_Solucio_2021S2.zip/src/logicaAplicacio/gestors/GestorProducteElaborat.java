/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logicaAplicacio.gestors;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import logicaAplicacio.model.MateriaPrimera;
import logicaAplicacio.model.ProducteElaborat;

/**
 * Classe que gestiona la persistencia dels objectes de la classe logicaAplicacio.model.ProducteElaborat
 * @author professor
 */
public class GestorProducteElaborat {
    private EntityManager em = null;

    /**
     * Crea un gestor de producte que treballara amb l'EntityManager em
     * @param em context on es fan persistents els cap
     */
    public GestorProducteElaborat (EntityManager em) {
       this.em = em;
    }

    /**
     * Consultar tots els productes elaborats de la base de dades
     * @return Llista amb tots els productes elaborats de la base de dades
     */
    public List<ProducteElaborat> obtenirProductesElaborats() {
        Query q = em.createNamedQuery("ProducteElaborat.tots");
        List<ProducteElaborat> resultat=q.getResultList();
        for(ProducteElaborat b:resultat){
           em.detach(b);
        }
        return resultat;
    }
   
    /**
     * Obte una llista amb tots els productes elaborats de la base de dades amb un preu igual o superior al donat
     * @param preu preu dels productes
     * @return llistat amb els productes elaborats a la base de dades amb un preu igual o superior al donat
     */
    public List<ProducteElaborat> obtenirProducteElaboratPerPreu(float preu) {
        Query q = em.createNamedQuery("ProducteElaborat.perPreu");
        q.setParameter("preuventa", preu);
        List<ProducteElaborat> resultat = q.getResultList();
        resultat.forEach((a) -> {
            em.detach(a);
        });
        return resultat;
    }
    
    /**
     * Obté una llista amb totes les materies primeres necessaries per aquest producte elaborat
     * @param id identificador del producte elaborat
     * @return llista amb totes les materies primeres necessaries per aquest producte elaborat
     */
    public List<MateriaPrimera> obtenirMateriesPrimeresDelProducteElaborat(int id) {
        ProducteElaborat base=em.find(ProducteElaborat.class, id);
        if(base!=null){
            em.detach(base);
            List<MateriaPrimera> listmp = base.getMateriesPrimeres();
            listmp.forEach((a) ->{
              em.detach(a);
            });
            return listmp;
        }else {
            return null;
        }
    }
    
     /**
     * Incrementa el preu de tots els productes eslaborats de la base de dades en un percentatge determinat
     * @param percentantge tant per cent (%) d'increment 
     */
    public void IncrementaPreu(float percentantge){
        Query q = em.createNamedQuery("ProducteElaborat.incrementa");
        q.setParameter("percentatge", percentantge);
        em.getTransaction().begin();
        q.executeUpdate();
        em.getTransaction().commit();
      
    }

}

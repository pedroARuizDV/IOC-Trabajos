package eac2.ex1.gestors;

import java.sql.Array;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import eac2.ex1.model.Canal;
import java.sql.Statement;
import java.sql.Types;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Classe que gestiona la persistencia dels objectes de la classe model.Canal
 * @author professor
 */
public class GestorCanal {

    private Connection conn = null;
    private PreparedStatement p = null;    
    private StringBuilder pStr = null;      

    /**
     * Crea un gestor de Canal que treballara amb la connexio conn
     * @param conn connexio a traves de la qual es fan persistents dels canals
     */
    public GestorCanal(Connection conn) {
       this.conn = conn;
    }
    
    /**
     * Crea un Canal en la base de dades. Si ja n'hi ha algun amb el seu mateix codi, llenca una excepcio.
     * @param can canal a crear
     * @throws gestors.GestorException en cas d'error a la base de dades que pot ser, entre altres, clau duplicada.
     */
    public void inserir(Canal can) throws GestorException  {
        //TODO codificar el metode inserir
        try {  
            
            pStr = new StringBuilder();
            pStr.append("INSERT INTO canal (id, nom, tema, numvideos, propietari, subscriptors ) ");
            pStr.append("VALUES(?,?,?,?,(?,?,?,?),?)");
            p = conn.prepareStatement(pStr.toString());
            
            //Capturamos los parametros
            p.setInt(1, can.getId());
            p.setString(2, can.getNom());
            p.setString(3, can.getTema());
            p.setInt(4, can.getNumVideos());         
            
            //propietari
            p.setString(5, can.getNick());
            p.setString(6, can.getNomUsuari());
            p.setBoolean(7, can.isMajorEdat());
            p.setString(8, can.getResidencia());            
            
            //subscriptores
            Array obj = conn.createArrayOf("varchar", can.getSubscriptors().toArray());            
            p.setArray(9, obj);
            
            //Ejecutamos la insercción
            p.executeUpdate();           
            
        } catch(SQLException e) {            
            if(e.getSQLState().equals("23505")) {                
                throw new GestorException("Error: Código -> " + e.getSQLState() + " El ID " + can.getId() + " ya existe.");                
            } else if(e.getSQLState().equals("28000")) {
                throw new GestorException("Error: Código -> " + e.getSQLState() + " Usuario o contraseña errónea");      
            } else if(e.getSQLState().equals("08001")){
                throw new GestorException("Error: Código -> " + e.getSQLState() + " Problemas en la conexión");     
            } else {                
                throw new GestorException(e.getSQLState());  
            }           
            
        } 
    }

    
    /**
     * Esborra de la base de dades un canal amb un codi determinat
     * @param canId codi del canal lasse a esborrar
     * @throws gestors.GestorException si el codi no correspon a cap canal de la base de dades
     * o hi ha un error en l'acces a la base de dades
     */
   
    public void eliminar(int canId) throws GestorException {
       //TODO codificar el metode eliminar
       try {
            //Comprobamos que existe el canl y si no, lanzamos la excepción
            if(obtenirCanal(canId) != null) {
               System.out.println("Canal con ID: " + canId + " borrado correctamente.");
            } else {
               throw new GestorException("Error: el ID: " + canId + " No existe");                              
            }
           
           pStr = new StringBuilder();
           pStr.append("DELETE FROM canal ");
           pStr.append("WHERE id = ?");
           p = conn.prepareStatement(pStr.toString());
           p.setInt(1, canId);
           p.executeUpdate();     
           
       }catch(SQLException e) {            
            if(e.getSQLState().equals("28000")) {
                throw new GestorException("Error: Código -> " + e.getSQLState() + " Usuario o contraseña errónea");      
            } else if(e.getSQLState().equals("08001")){
                throw new GestorException("Error: Código -> " + e.getSQLState() + " Problemas en la conexión");     
            } else {
                throw new GestorException(e.getSQLState());
            }           
       } 
    }


    
    /**
     * Obte el canal de la base de dades amb un determinat codi.
     * @param canId codi del canal a obtenir
     * @return canal amb canId o null si no hi ha cap canal amb aquest id a la base de dades
     * @throws gestors.GestorException en cas d'error a la base de dades
     */
   
    public Canal obtenirCanal(int canId) throws GestorException  {
        //TODO codificar el metode obtenirCanal
        Canal canal = null;
        ResultSet result = null;
        try {            
            pStr = new StringBuilder();
            pStr.append("SELECT id, nom, tema, numVideos, (propietari).*, subscriptors FROM canal ");
            pStr.append("WHERE id = ?");             
            p = conn.prepareStatement(pStr.toString());           
            p.setInt(1, canId);
            result = p.executeQuery();            
            
            while(result.next()) {
                Array arraySubscriptores = result.getArray("subscriptors");
                String[] subscriptores = (String[])arraySubscriptores.getArray();                  
                canal = new Canal(result.getInt("id"),
                                  result.getString("nom"),
                                  result.getString("tema"),
                                  result.getInt("numvideos"),
                                  subscriptores,
                                  result.getString("nick"),
                                  result.getString("nomUsuari"),
                                  result.getBoolean("majorEdat"),
                                  result.getString("residencia"));                         
            }
            
        }catch(SQLException e) {
            if(e.getSQLState().equals("28000")) {
                throw new GestorException("Error: Código -> " + e.getSQLState() + " Usuario o contraseña errónea");      
            } else if(e.getSQLState().equals("08001")){
                throw new GestorException("Error: Código -> " + e.getSQLState() + " Problemas en la conexión");     
            } else {
                throw new GestorException(e.getSQLState());
            }           
        }          
        return canal;
    }

    /**
     * Retorna una llista dels canals als quals aquest usuari esta subscrit
     * @param subscriptor subscriptor utilitzat per a obtenir la llista de canals
     * @return Llista amb els canals de la base de dades que contenen un subscriptor al seu array de llistes de subscriptors
     * @throws gestors.GestorException en cas d'error a la base de dades
     */
    
    public List<Canal> obtenirCanalPerSubscriptor(String subscriptor) throws GestorException  {
        List<Canal> canals = new ArrayList<>();
        ResultSet result = null;                
        try {                
            pStr = new StringBuilder();
            pStr.append("SELECT id FROM canal ");
            pStr.append("WHERE ? = ANY(subscriptors)");             
            p = conn.prepareStatement(pStr.toString());           
            p.setString(1, subscriptor);
            result = p.executeQuery();
            
            while(result.next()) {
                canals.add(obtenirCanal(result.getInt("id")));
            }              

        } catch(SQLException e) {
             if(e.getSQLState().equals("28000")) {
                throw new GestorException("Error: Código -> " + e.getSQLState() + " Usuario o contraseña errónea");      
            } else if(e.getSQLState().equals("08001")){
                throw new GestorException("Error: Código -> " + e.getSQLState() + " Problemas en la conexión");     
            } else {
                throw new GestorException(e.getSQLState());
            }           
        } 
		
        return canals;
    }
    

}

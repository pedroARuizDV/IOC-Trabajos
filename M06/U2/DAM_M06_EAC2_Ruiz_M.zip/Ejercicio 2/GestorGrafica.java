/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eac2.ex2.gestors;

import javax.persistence.EntityManager;
import eac2.ex2.model.TargetaGrafica;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;


/**
 * Classe que gestiona la persistencia dels objectes de la classe model.TargetaGrafica
 * @author professor
 */
public class GestorGrafica {
    
    
    private EntityManager gfx = null;
    
    
    /**
     * Crea un gestor de targetes grafiques que treballara amb l'EntityManager TargetaGrafica
     * @param dispositiu context on es fan persistentents les targetes
     */
    public GestorGrafica(EntityManager dispositiu) {
        
       this.gfx = dispositiu;
       
    }
    
    
    /**
     * Dona d'alta una grafica en la base de dades. Si ja n'hi ha alguna amb el seu mateix nombre de serie, llenca una excepcio.
     * @param fitxa fitxa de la grafica a donar d'alta
     * @throws gestors.GestorException en cas d'error a la base de dades que pot ser, entre altres, clau duplicada.
     */
    public void inserir(TargetaGrafica fitxa) throws GestorException {
        //TODO codificar el metode inserir         
        if(gfx.find(TargetaGrafica.class, fitxa.getNombreSerie())!=null) {            
            throw new GestorException("Error: artículo repetido ("+fitxa.getNombreSerie()+")");
        } else {            
            gfx.getTransaction().begin();
            gfx.persist(fitxa);               
            gfx.getTransaction().commit();
            System.out.println(fitxa.getModel() + " Añadido");            
        } 
    }

    
    /**
     * Modifica la fitxa d'una grafica de la base de dades. Si no n'hi ha cap amb el seu nombre de serie, llenca una excepcio.
     * @param fitxa fitxa de la grafica actualitzat
     * @throws gestors.GestorException en cas d'error a la base de dades que pot ser, entre altres, clau duplicada.
     */
    public void modificar(TargetaGrafica fitxa) throws GestorException {
        //TODO codificar el metode modificar      
        if(gfx.find(TargetaGrafica.class, fitxa.getNombreSerie())==null) {
            throw new GestorException("Error: artículo no existe ("+fitxa.getNombreSerie()+")");
        } else {
            gfx.getTransaction().begin();            
            gfx.merge(fitxa);            
            gfx.getTransaction().commit();
            System.out.println(fitxa.getModel() + " modificado");
        }     
    }    
    
    
    /**
     * Esborra la fitxa d'una grafica amb un determinat numero de serie
     * @param nombreSerie nombre serie de la gràfica a esborrar
     * @throws gestors.GestorException si el nombre de serie no correspon a cap grafica de la base de dades
     */
    public void eliminar(int nombreSerie) throws GestorException {
        //TODO codificar el metode eliminar      
        if(gfx.find(TargetaGrafica.class, nombreSerie)==null) {
            throw new GestorException("Error: artículo con Número de serie " + nombreSerie + " no existe ");
        } else {
            TargetaGrafica t = gfx.find(TargetaGrafica.class, nombreSerie);
            gfx.getTransaction().begin();
            gfx.remove(t);            
            gfx.getTransaction().commit();   
            System.out.println("Eliminado: " + t.getModel());
        }        
    }

   
    /**
     * Obte la grafica de la base de dades amb un numero de serie determinat
     * @param nombreSerie nombre serie de la gràfica a obtenir
     * @return fitxa de la gràfica amb aquell nombre serie o null si no hi ha cap grafica a la base de dades amb aquest numero de serie
     */
    public TargetaGrafica obtenirTargetaGrafica(int nombreSerie) {
        TargetaGrafica t = null;	
        if(gfx.find(TargetaGrafica.class, nombreSerie)==null) {
            System.out.println("No se ha encontrado una gráfica con ese número de serie.");
        } else {
            t = gfx.find(TargetaGrafica.class, nombreSerie);             
        }
        return t; 
    }
    
 
}



/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package eac2.ex1.solucio;

import java.sql.Array;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import eac2.ex1.gestors.GestorException;
import eac2.ex1.model.Canal;

/**
 * Classe que gestiona la persistencia dels objectes de la classe model.Canal
 * @author professor
 */
public class GestorCanal {

    private Connection conn = null;

    /**
     * Crea un gestor de Canal que treballara amb la connexio conn
     * @param conn connexio a traves de la qual es fan persistents dels canals
     */
    public GestorCanal(Connection conn) {
       this.conn = conn;
    }
    
    /**
     * Crea un Canal en la base de dades. Si ja n'hi ha algun amb el seu mateix codi, llenca una excepcio.
     * @param can canal a crear
     * @throws gestors.GestorException en cas d'error a la base de dades que pot ser, entre altres, clau duplicada.
     */
    public void inserir(Canal can) throws GestorException  {
        try {
            
            PreparedStatement ps=conn.prepareStatement("INSERT INTO canal (id, nom, tema, numVideos, propietari, subscriptors) VALUES (?,?,?,?,(?,?,?,?),?)");
            
            ps.setInt(1, can.getId());
            ps.setString(2, can.getNom());
            ps.setString(3, can.getTema());
            ps.setInt(4, can.getNumVideos());
            ps.setString(5, can.getNick());
            ps.setString(6, can.getNomUsuari());
            ps.setBoolean(7, can.isMajorEdat());
            ps.setString(8, can.getResidencia());
            ps.setArray(9, obteArraySubscriptors(can));
            
            ps.executeUpdate();
            
        } catch (SQLException ex) {
            
            throw new GestorException(ex.getMessage());
        }
    }

    /**
     * Obte un array de subscriptors en format varchar de posgres
     * @param can el Canal del qual es vol treure l'array de subscriptors
     * @return l'array de subscriptors
     * @throws GestorException 
     */    
    private Array obteArraySubscriptors(Canal can) throws GestorException {
    	try {
            
            String[] arrSubs = can.getSubscriptors().toArray(new String[0]);  
            
            return conn.createArrayOf("varchar", arrSubs);
            
        } catch (SQLException ex) {
            
            throw new GestorException(ex.getMessage());
        }
	}

	/**
     * Esborra de la base de dades un canal amb un codi determinat
     * @param canId codi del canal lasse a esborrar
     * @throws gestors.GestorException si el codi no correspon a cap canal de la base de dades
     * o hi ha un error en l'acces a la base de dades
     */
   
    public void eliminar(int canId) throws GestorException {
        try {
            
            PreparedStatement ps=conn.prepareStatement("DELETE FROM canal WHERE id=?");
            
            ps.setInt(1,canId);
            
            if(ps.executeUpdate()==0){
                
                throw new GestorException("El canal no existeix a la base de dades");
            }
        } catch (SQLException ex) {
            
            throw new GestorException(ex.getMessage());
        }
    }


    
    /**
     * Obte el canal de la base de dades amb un determinat codi.
     * @param canId codi del canal a obtenir
     * @return canal amb canId o null si no hi ha cap canal amb aquest id a la base de dades
     * @throws gestors.GestorException en cas d'error a la base de dades
     */
   
    public Canal obtenirCanal(int canId) throws GestorException  {

        try {
            
            PreparedStatement ps=conn.prepareStatement("SELECT id, nom, tema, numVideos, (propietari).nick, (propietari).nomUsuari, (propietari).majorEdat, (propietari).residencia, subscriptors FROM canal WHERE id = ?");
            
            ps.setInt(1, canId);
            
            ResultSet rs=ps.executeQuery();
            
            if(rs.next()){
                
                return recuperaCanal(rs);
            }
            
            return null;
            
        } catch (SQLException ex) {
            
            throw new GestorException(ex.getMessage());
        }
    }

    /**
     * Crea un nou canal a partir de les dades d'un resultSet de SQL
     * @param rs el resultSet amb les dades d'un Canal
     * @return el canal creat
     * @throws GestorException 
     */
    private Canal recuperaCanal(ResultSet rs) throws GestorException {
        try {
            
            Canal pr = new Canal();
            
            String[] subscriptors = null;
            
            pr.setId(rs.getInt("id"));
            pr.setNom(rs.getString("nom"));
            pr.setTema(rs.getString("tema"));
            pr.setNumVideos(rs.getInt("numVideos"));
            subscriptors=(String[])rs.getArray("subscriptors").getArray();
            pr.setSubscriptors(Arrays.asList(subscriptors));
            pr.setNick(rs.getString("nick"));
            pr.setNomUsuari(rs.getString("nomUsuari"));
            pr.setMajorEdat(rs.getBoolean("majorEdat"));
            pr.setResidencia(rs.getString("residencia"));

            return pr;
            
        } catch (SQLException ex) {
            
            throw new GestorException(ex.getMessage());
        }
	}

	/**
     * Retorna una llista dels canals als quals aquest usuari esta subscrit
     * @param subscriptor subscriptor utilitzat per a obtenir la llista de canals
     * @return Llista amb els canals de la base de dades que contenen un subscriptor al seu array de llistes de subscriptors
     * @throws gestors.GestorException en cas d'error a la base de dades
     */
    
    public List<Canal> obtenirCanalPerSubscriptor(String subscriptor) throws GestorException  {
try {
            
            List<Canal> lp=new ArrayList<>();
            
            PreparedStatement ps=conn.prepareStatement("SELECT id, nom, tema, numVideos, (propietari).nick, (propietari).nomUsuari, (propietari).majorEdat, (propietari).residencia, subscriptors FROM canal WHERE ? = ANY (subscriptors)");
            
            ps.setString(1, subscriptor);
            
            ResultSet rs=ps.executeQuery();
            
            while(rs.next()){
                
                lp.add(recuperaCanal(rs));
            }
            
            return lp;
            
        } catch (SQLException ex) {
            
            throw new GestorException(ex.getMessage());
        }
    }
    

}

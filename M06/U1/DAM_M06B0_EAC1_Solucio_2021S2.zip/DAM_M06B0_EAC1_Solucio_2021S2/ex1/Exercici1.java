/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//args >> /home/vant/proves i
//args >> /home/vant/proves e
//args >> /home/vant/proves fitxer1
package eac1.ex1;

import java.io.File;
import java.io.FileFilter;
import java.io.IOException;

/**
 *
 * @author professor
 */
public class Exercici1 {
	/**
	 * @param args the command line arguments
	 * @throws java.io.IOException
	 */
	public static void main(String[] args) throws IOException {

		//Testing per no haver de cridar desde consola
		//args = new String[]{"D:\\test","E",">","100"};
		//args = new String[]{"D:\\","L","D"};
		File carpetaDesti; // Carpeta que llistarem
		String arg1 = null; // Operaci� a fer
		String arg2 = null;

		// Primer argument de la l�nia d'ordres
		carpetaDesti = new File(args[0]);

		// Segon argument de la l�nia d'ordres
		arg1 = args[1];
		arg2 = args[2];

		System.out.println(arg1);
		// Lambda expression - filtre per comprovar fitxers no ocults amb perm�s
		// d'escriptura
		FileFilter filter = (File arxiuSeleccionat) -> {
			// Arxiu �s un fitxer no ocult amb perm�s d'escriptura
			return (arxiuSeleccionat.isFile() && arxiuSeleccionat.canWrite() && !arxiuSeleccionat.isHidden());//
		};

		if (!(args.length == 3 || args.length == 4)) {

			finalitzar("Nombre d'arguments erronis");

		} else if (!carpetaDesti.isDirectory()) {

			finalitzar("El primer parametre es erroni");

		} else {// Parametres correctes, �s un fitxer no ocult amb perm�s d'escriptura

			// Esborrar tots els fitxers no ocults amb perm�s d'escriptura
			if (arg1.toUpperCase().equalsIgnoreCase("E")) {
				System.out.println(arg2);
				if (arg2.equals("<")) {
					//consultem el tamany en kb
					int tamany = Integer.parseInt(args[3]);
					FileFilter filterMenys = (File arxiuSeleccionat) -> {
						// Arxiu �s un fitxer no ocult amb perm�s d'escriptura amb tamany inferior al tamany donat
						return (arxiuSeleccionat.isFile() && arxiuSeleccionat.canWrite() && !arxiuSeleccionat.isHidden()
								&& arxiuSeleccionat.length()/1024 < tamany);//
					};
					esborraContingut(carpetaDesti.listFiles(filterMenys));
				} else if (arg2.equals(">")) {
					//consultem el tamany en kb
					int tamany = Integer.parseInt(args[3]);
					FileFilter filterMes = (File arxiuSeleccionat) -> {
						// Arxiu �s un fitxer no ocult amb perm�s d'escriptura amb tamany superior al tamany donat
						return (arxiuSeleccionat.isFile() && arxiuSeleccionat.canWrite() && !arxiuSeleccionat.isHidden()
								&& arxiuSeleccionat.length()/1024 >= tamany);//
					};
					esborraContingut(carpetaDesti.listFiles(filterMes));
				} else {
					finalitzar("El tercer parametre es erroni");
				}

				// Informaci� tots els fitxers no ocults amb perm�s d'escriptura
			} else if (arg1.toUpperCase().equalsIgnoreCase("L")) {

				if (arg2.toUpperCase().equalsIgnoreCase("D")) {
					FileFilter filterDir = (File arxiuSeleccionat) -> {
						// Arxiu �s un fitxer o dir no ocult amb perm�s d'escriptura
						return (arxiuSeleccionat.canWrite() && !arxiuSeleccionat.isHidden());//
					};
					infoSortida(carpetaDesti.listFiles(filterDir));
				} else if (arg2.toUpperCase().equalsIgnoreCase("N")) {
					FileFilter filterNo = (File arxiuSeleccionat) -> {
						// Arxiu �s un fitxer no ocult amb perm�s d'escriptura
						return (arxiuSeleccionat.isFile() && arxiuSeleccionat.canWrite() && !arxiuSeleccionat.isHidden());//
					};
					infoSortida(carpetaDesti.listFiles(filterNo));
				} else {
					finalitzar("El tercer parametre es erroni");
				}

			} else {

				finalitzar("El segon parametre es erroni");
			}

		}

	}

	// Esborra el contingut del directori
	private static void esborraContingut(File[] llistatItems) {
		System.out.println("Comen�a el proc�s d'esborrat:");
		int num = 0;
		for (File listedFile : llistatItems) {
			if (listedFile.delete()) {
				System.out.println("Fitxer: " + listedFile + " esborrat amb �xit");
				num++;
			}
		}
		System.out.println(num + " fitxers esborrats");

	}

	// Informaci� sortida
	private static void infoSortida(File[] llistatItems) {
		System.out.println(" Totals " + llistatItems.length + " fitxers no ocults amb perm�s d'escriptura");
		String nomFitxer;
		for (File listedFile : llistatItems) {
			nomFitxer = listedFile.getName();
			double tamany = listedFile.length()/1024.0;
			if (listedFile.isFile()) {
				System.out.println("\t>> " + nomFitxer + "\f " + tamany+ " kb");
			} else if(listedFile.isDirectory()){
				System.out.println("\t> " + nomFitxer );
			}
		}
	}

	// System.err amb codi d'error 2
	private static void finalitzar(String missatge) {
		System.err.println(missatge);
		System.exit(2);
	}

}

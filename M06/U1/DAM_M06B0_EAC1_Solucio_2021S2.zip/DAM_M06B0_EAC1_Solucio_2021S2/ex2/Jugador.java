/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eac1.ex2;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 * Contacte controlat
 * @author professor
 */
@XmlType(propOrder = {"nom", "pais", "rol", "fiContracte"})
public class Jugador {

    String nom, pais, rol, fiContracte;
    
    @XmlElement
    public String getNom() {
        return nom;
    }
    public void setNom(String nom) {
        this.nom = nom;
    }
    
    @XmlElement
    public String getPais() {
        return pais;
    }
    public void setPais(String pais) {
        this.pais = pais;
    }
    
    @XmlElement
    public String getRol() {
        return this.rol;
    }
    public void setRol(String rol) {
        this.rol = rol;
    }
    
    @XmlElement(name = "fi_contracte")
    public String getFiContracte() {
        return fiContracte;
    }
    public void setFiContracte(String fic) {
        this.fiContracte = fic;
    }
    
}

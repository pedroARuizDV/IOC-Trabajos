
package eac1.ex2;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

/**
 *
 * @author professor
 */
public class Exercici2 {

	public static void main(String[] args) throws FileNotFoundException, IOException {

		//Testing per no haver de cridar desde consola
		//args = new String[]{"P1noy","Dinamarca","ADC","2021-11-15","g2.xml","g2_updated.xml"};
		
		
		// Declaració i inicialització de variables
		String nom, pais, rol, fiContracte;

		nom = args[0];
		pais = args[1];
		rol = args[2];
		fiContracte = args[3];

		// Declaració i inicialització de variables
		String fileIn = args[4], fileOut = args[5];
		File fitxerOrigen = new File(fileIn), fitxerDesti = new File(fileOut);

		if (args.length != 6) {
			acaba("Nombre de paràmetres erroni");
		}

		System.out.println(fitxerOrigen.getAbsolutePath());
		if (!fitxerOrigen.isFile() || !fitxerOrigen.canRead()) {
			acaba("El cinquè parametre indica un fitxer inaccessible");
		}

		try {
			// Es crea el context indicant la classe arrel
			JAXBContext jaxbContext = JAXBContext.newInstance(Equip.class);
			// Es crea un Unmarshaller amb el context de la classe Equip
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			// Es fa servir el mètode unmarshal, per a obtenir les dades
			Equip conne = (Equip) jaxbUnmarshaller.unmarshal(fitxerOrigen);

			List<Jugador> plantilla = (List<Jugador>) conne.getPlantilla();

			boolean error = false;
			// Comprovar que l'equip pot fitxar
			error = !conne.isPotFitxar();
			// Comprovar si hi ha un jugador amb el mateix nom
			if(error) {
				acaba("Aquest equip no pot fitxar!");
			}
			
			for (int i = 0; i < plantilla.size(); i++) {

				if (plantilla.get(i).getNom().equals(nom)) {
					error = true;
					break;
				}
			}

			if (!error) {

				// Crear l'objecte tipus Jugador
				Jugador jug = new Jugador();
				jug.setNom(nom);
				jug.setPais(pais);
				jug.setRol(rol);
				jug.setFiContracte(fiContracte);
				// S'afegeix el jugador a la plantilla
				plantilla.add(jug);
				//s'augmenten el nombre de jugadors
				conne.setNombreJugadors(conne.getNombreJugadors()+1);
				// Es crear el Marshaller, bolcar l'equip sencer al fitxer XML
				Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
				jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);

				System.out.println("Jugador afegit: " + nom);

				// Es grava el fitxer desti amb la sortida formatada (aixo ultim s'indica en la
				// instruccio que segueix)
				jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
				jaxbMarshaller.marshal(conne, fitxerDesti);

				mostraFitxer(fitxerDesti);

			} else

				acaba("El jugador amb nom: " + nom + " ja existeix!");

		} catch (JAXBException je) {
			acaba("Error mentres s'escribia: " + je.getCause());
		} catch (NumberFormatException e) {
			acaba("Error de format: " + e.getCause());
		}

	}

	private static void acaba(String missatge) {
		System.err.println(missatge);
		System.exit(2);
	}

	private static void mostraFitxer(File f) {
		FileInputStream fis = null;
		try {
			fis = new FileInputStream(f);
			int caracter = fis.read();

			while (caracter != (-1)) {
				System.out.printf("%c", (char) caracter);
				caracter = fis.read();
			}
			tancar(fis);
		} catch (FileNotFoundException ex) {
			acaba("Arxiu no trobat: " + ex.getCause());
		} catch (IOException ex) {
			acaba("Error d'entrada/sortida: " + ex.getCause());
		} finally {
			tancar(fis);
		}
	}

	public static void tancar(Closeable aTancar) {
		try {
			if (aTancar != null) {
				aTancar.close();
			}
		} catch (IOException ex) {
			acaba("Error d'entrada/sortida: " + ex.getCause());
		}
	}

}
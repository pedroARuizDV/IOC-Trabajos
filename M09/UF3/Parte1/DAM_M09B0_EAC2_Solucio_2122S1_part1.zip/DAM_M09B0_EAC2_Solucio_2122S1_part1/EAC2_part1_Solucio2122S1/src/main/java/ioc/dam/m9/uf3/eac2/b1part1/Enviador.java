/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ioc.dam.m9.uf3.eac2.b1part1;


import java.io.BufferedReader; 
import java.io.FileReader; 
import java.io.IOException;
import java.io.OutputStream; 
import java.io.PrintWriter; 
import java.net.InetSocketAddress; 
import java.net.Socket;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Usuari
 */
public class Enviador {
  public static void main(String[] args) { 
      try {            
        // Creant socket client
      Socket clientSocket = new Socket();            
        // Establint la connexió
        
      InetSocketAddress addr = new InetSocketAddress("localhost", 5555);      
      clientSocket.connect(addr);
      
      OutputStream os = clientSocket.getOutputStream();
      
      // Obrint el fitxer            
      BufferedReader br;            
      br = new BufferedReader(new FileReader("F:\\prova.txt"));
       
    // Enviant el contingut del fitxer
    
       PrintWriter pw = new PrintWriter(os, true);            
       while (br.ready()) {        
           String line = br.readLine();
               pw.println(line);      
       }
      // Tancant el socket del client
      
      clientSocket.close();
      // Acabant          
     } catch (IOException e) {
         
        e.printStackTrace();    
     }
      
    } 
}

package ioc.dam.m9.uf3.eac2.b2Servidor;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;


public class ServidorXat {

    /**
     * @param args the command line arguments
     */

    public static void main(String[] args) {
          
        int port = 7777;
        int maxConnexions = 10; // Màxim de connexions a la vegada
        ServerSocket servidor = null; 
        Socket socket = null;
        MissatgesXat missatges = new MissatgesXat();
        
        try {
            // Es crea el serverSocket
            servidor = new ServerSocket(port, maxConnexions);
            
            // Bucle infinit per esperar connexions
            int i=0;
            while (true) {
                System.out.println("Servidor a l'espera de connexions.");
                socket = servidor.accept();
                System.out.println("Client "+i+ " amb la IP " + socket.getInetAddress().getHostName() + " connectat.");
                i++;
                //instancia a connexió client
                ConnexioClient cc = new ConnexioClient(socket, missatges);
                cc.start();
                
            }
        } catch (IOException ex) {
            System.out.println("Error: " + ex.getMessage());
        } finally{
            try {
                socket.close();
                servidor.close();
            } catch (IOException ex) {
                System.out.println("Error al tancar el servidor: " + ex.getMessage());
            }
        }
    }
}
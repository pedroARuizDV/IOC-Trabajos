package ioc.dam.m9.uf3.eac2.b1part1;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Usuari
 */
import java.io.BufferedReader; 
import java.io.IOException; 
import java.io.InputStream; 
import java.io.InputStreamReader; 
import java.net.InetSocketAddress; 
import java.net.ServerSocket; 
import java.net.Socket;

public class Receptor {
  public static void main(String[] args) {    
      try {            
        // Creant socket servidor     
        ServerSocket serverSocket = new ServerSocket();            
        // Realitzant el bind
      InetSocketAddress addr = new InetSocketAddress("localhost", 5555); 
          System.out.println("Esperant connexions");
      serverSocket.bind(addr);            // Aceptant connexions
      Socket newSocket = serverSocket.accept();            
      System.out.println("Conexió rebuda");
      InputStream is = newSocket.getInputStream();            
      BufferedReader br = new BufferedReader(new InputStreamReader(is));            
      String line = br.readLine();      
      while (line != null) {        
          System.out.println(line);
              line = br.readLine();                 
      }
        // Tancant el nou socket            
        
        newSocket.close();
        
      //Tancant el socket servidor      
        
        serverSocket.close();
      // Acabat          
        } catch (IOException e) {      
                    e.printStackTrace();    }  
                    } 
        }

package ioc.dam.m9.uf3.eac2.b2Client;

/**
 *
 * 
 */
public class ClientXat {
    
    public static void main(String[] args) {
        
        FinestraPrincipal c = new FinestraPrincipal();
        c.rebreMissatgesServidor();
    }
    
    
}

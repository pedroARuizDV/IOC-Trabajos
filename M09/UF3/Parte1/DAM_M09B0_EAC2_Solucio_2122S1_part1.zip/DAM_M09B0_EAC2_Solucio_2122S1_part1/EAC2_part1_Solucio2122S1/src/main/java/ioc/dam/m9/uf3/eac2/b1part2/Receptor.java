package ioc.dam.m9.uf3.eac2.b1part2;

 /* Donada una url i una etiqueta, mostra les línies de url on apareix l'etiqueta
 *  @params args: url tag
 */

import java.io.IOException; import java.net.DatagramPacket; 
import java.net.DatagramSocket; 
import java.net.InetSocketAddress;

public class Receptor {
  public static void main(String[] args) {    
      
     // Creant socket datagrama
      try {      
      InetSocketAddress addr = new InetSocketAddress("localhost", 5555);      
      DatagramSocket datagramSocket = new DatagramSocket(addr);
      
      System.out.println("Esperant connexions");
      
// Rebent missatge mensaje
      while (true) {        
          byte[] mensaje = new byte[32];        
      DatagramPacket datagrama1 = new DatagramPacket(mensaje, 32);        
      datagramSocket.receive(datagrama1);
        String pregunta = new String(mensaje);                
        if (pregunta.equals("Quina es la teva seria favorita?")) {                  
// Enviant mensaje
          String resposta = "Black List";           
          DatagramPacket datagrama2 = new DatagramPacket(resposta.getBytes(), resposta. getBytes().length, datagrama1.getAddress(), datagrama1.getPort());
          datagramSocket.send(datagrama2);        
        }
      }
      
    
 } catch (IOException e) {      
     e.printStackTrace();    
    } 
      
  } 
}
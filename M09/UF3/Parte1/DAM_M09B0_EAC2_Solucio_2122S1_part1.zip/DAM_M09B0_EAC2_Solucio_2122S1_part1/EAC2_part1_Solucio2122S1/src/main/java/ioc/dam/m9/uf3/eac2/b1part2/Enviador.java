/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ioc.dam.m9.uf3.eac2.b1part2;

import java.io.IOException; 
import java.net.DatagramPacket; 
import java.net.DatagramSocket; 
import java.net.InetAddress; 
import java.net.InetSocketAddress;

public class Enviador {
  public static void main(String[] args) {    
      try {      
      // Creant socket datagrama
      InetSocketAddress addr = new InetSocketAddress("localhost", 5556);      
      DatagramSocket datagramSocket = new DatagramSocket(addr);
      // Enviant missatge
      String pregunta = "Quina es la teva seria favorita?";      
      InetAddress addr1 = InetAddress.getByName("localhost");      
      DatagramPacket datagrama1 = new DatagramPacket(pregunta.getBytes(), pregunta.getBytes().length, addr1, 5555);      
      datagramSocket.send(datagrama1);
      
    // Rebent missatge
      
      byte[] missatge = new byte[32];     
      DatagramPacket datagrama2 = new DatagramPacket(missatge, 32);      
      datagramSocket.receive(datagrama2);
      String resposta = new String(missatge);
      System.out.println("Pregunta: "+pregunta);      
      System.out.println("Resposta: "+resposta);          
      } catch (IOException e) {      
          e.printStackTrace();    }  
  } 
}

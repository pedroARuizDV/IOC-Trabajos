Les dos parts del projecte de l'exercici B1 el trobareu a la carpeta B1

L'Exercici B2 consta de dos parts. El Servidor i el Client


Un cop implementat el que es demana a l'enunciat, heu 
d'executar primer la classe principal del servidor i tot seguit
la del client.


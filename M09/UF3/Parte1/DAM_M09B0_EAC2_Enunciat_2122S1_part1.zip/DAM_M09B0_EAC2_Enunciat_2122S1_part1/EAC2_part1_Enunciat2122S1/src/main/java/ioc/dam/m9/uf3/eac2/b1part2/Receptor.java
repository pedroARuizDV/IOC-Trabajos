package ioc.dam.m9.uf3.eac2.b1part2;

 /* Donada una url i una etiqueta, mostra les línies de url on apareix l'etiqueta
 *  @params args: url tag
 */

import java.io.IOException; import java.net.DatagramPacket; 
import java.net.DatagramSocket; 
import java.net.InetSocketAddress;

public class Receptor {
  public static void main(String[] args) {    
      
     // Creant socket datagrama
      
     //implementa
      
        // Rebent missatge mensaje
        // implementa                 
        // Enviant mensaje

         //implementa     
        }
      }
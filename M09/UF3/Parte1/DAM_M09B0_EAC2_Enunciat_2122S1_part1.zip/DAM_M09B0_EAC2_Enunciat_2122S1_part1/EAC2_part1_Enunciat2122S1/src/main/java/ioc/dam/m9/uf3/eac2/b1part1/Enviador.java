package ioc.dam.m9.uf3.eac2.b1part1;


import java.io.BufferedReader; 
import java.io.FileReader; 
import java.io.IOException;
import java.io.OutputStream; 
import java.io.PrintWriter; 
import java.net.InetSocketAddress; 
import java.net.Socket;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Usuari
 */
public class Enviador {
  public static void main(String[] args) { 
                 
        // Creant socket client
                
        // Establint la connexió
        
     
      
      // Obrint el fitxer            
     
       
    // Enviant el contingut del fitxer
    
     
     
      // Tancant el socket del client
      
    
      // Acabant          
    }
   
}
  
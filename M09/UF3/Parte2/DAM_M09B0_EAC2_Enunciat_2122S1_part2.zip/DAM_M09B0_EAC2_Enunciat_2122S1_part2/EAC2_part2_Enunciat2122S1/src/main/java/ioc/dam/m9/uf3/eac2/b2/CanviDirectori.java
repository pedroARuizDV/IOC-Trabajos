package ioc.dam.m9.uf3.eac2.b2;

import java.io.Serializable;

@SuppressWarnings("serial")
public class CanviDirectori implements Serializable {
	String ruta;

	public String getNomDirectori() {
		return ruta;
	}

	public CanviDirectori(String ruta) {
		this.ruta = ruta;
	}
} 

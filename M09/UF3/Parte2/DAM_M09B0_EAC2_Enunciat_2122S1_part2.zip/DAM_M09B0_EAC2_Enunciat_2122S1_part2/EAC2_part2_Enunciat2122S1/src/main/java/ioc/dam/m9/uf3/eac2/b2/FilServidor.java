/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ioc.dam.m9.uf3.eac2.b2;

import java.io.*;
import java.net.*;


public class FilServidor extends Thread {
	Socket socket;	
	ObjectOutputStream outObjecte;
	ObjectInputStream inObjecte;
	EstructuraFitxers NF;

	public FilServidor(Socket s, EstructuraFitxers nF) throws IOException {//
		socket = s;
		NF = nF;
		inObjecte = new ObjectInputStream(socket.getInputStream());
		outObjecte = new ObjectOutputStream(socket.getOutputStream());
	}

	//
	public void run() {
		try {
			// envio al client el objecte EstructuraFitxers 
			outObjecte.writeObject(NF);

			while (true) {
                            
                            
                            
                            //IMPLEMENTA
				// primer llegeixo el que em demana el client
				
					// escric en el stream
													
					//creo Fitxer en el Directori
					   					
					//System.out.println(fic.getNom() + "*" +fic.getDirectori());
										
			}
		} catch (IOException e) {
			// Quan el client tanca la connexion		
			try {
				inObjecte.close();
				outObjecte.close();
				socket.close();
				System.out.println("Tancant client");
			} catch (IOException ee) {
				ee.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	} // de run()
    
	private void EnviarFitxer(DemanaFitxer fitx) {
		File Fitxer = new File(fitx.getNomFitxer()); 
		// crea flux d'entrada
		FileInputStream filein = null;
		try {
			filein = new FileInputStream(Fitxer);
			long bytes = Fitxer.length();
			//System.out.println("Fitxer:" + fitx.getNomFitxer());
			byte[] buff = new byte[(int) bytes];
			int i, j = 0;
			
			while ((i = filein.read()) != -1) {// llegeix les dades del flux d'entrada
				//System.out.println(i);
				buff[j] = (byte) i;
				j++;
			}
			filein.close(); // tancar stream d'entrada
			Object ff = new ObteFitxer(buff);
			outObjecte.writeObject(ff);

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}// ..EnviarFitxer
}// ..FilServidor
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ioc.dam.m9.uf3.eac2.b2;

import javax.swing.*;
import javax.swing.event.*;

import java.io.*;
import java.net.Socket;
import java.util.ArrayList;
import java.awt.*;
import java.awt.event.*;


public class clientFitxers extends JFrame implements Runnable {
	
	static ArrayList<String> llistaDirectoris = new ArrayList<>();
	
	private static final long serialVersionUID = 1L;	
	static Socket socket;
	static EstructuraFitxers node = null;
	ObjectInputStream inObjecte;
	ObjectOutputStream outObjecte;
        EstructuraFitxers Arrel;

	// camps de capçalera part superior
	static JTextField cab = new JTextField();
	static JTextField cab2 = new JTextField();
	static JTextField cab3 = new JTextField();

	// camps de missatges part inferior
	private static JTextField camp = new JTextField();
	private static JTextField camp2 = new JTextField();

	// botons
	JButton botoCargar = new JButton("Pujar Fitxer");
	JButton botoDescargar = new JButton("Descargar Fitxer");
	JButton botoSortir = new JButton("Sortir");
	JButton botoEntrar = new JButton("Entrar en la Carpeta");
	
	// llista per les dades del Directori
	@SuppressWarnings("rawtypes")
	static JList llistaDirec = new JList();
	
	// contenidor
	private final Container c = getContentPane();	
	
	// per saber Directori i Fitxer seleccionat
	static String direcSelec = "";
	static String FitxerSelec = "";
	static String Fitxercomplet = "";

	// constructor
	public clientFitxers(Socket s) throws IOException {
		super("SERVIDOR DE FitxerS BÀSIC");
		socket = s;
		try {
			// fluxe de sortida -envio objecte
			outObjecte = new ObjectOutputStream(socket.getOutputStream());
			// fluxe d'entrada -rebo objecte
			inObjecte = new ObjectInputStream(socket.getInputStream());
		} catch (IOException e) {
			e.printStackTrace();
			System.exit(0);
		}
		camp.setBounds(new Rectangle(3, 385, 485, 30));
		camp.setForeground(Color.blue);
		camp.setFont(new Font("Verdana", Font.BOLD, 12));
		camp2.setBounds(new Rectangle(3, 415, 485, 30));
		camp2.setForeground(Color.blue);
		camp2.setFont(new Font("Verdana", Font.BOLD, 12));

		cab.setBounds(new Rectangle(5, 5, 400, 30));
		cab.setBorder(null);
		cab.setForeground(Color.blue);
		cab.setFont(new Font("Arial", Font.BOLD, 14));

		cab2.setBounds(new Rectangle(350, 5, 140, 30));
		cab2.setBorder(null);
		cab2.setFont(new Font("Arial", Font.BOLD, 14));
		cab2.setForeground(Color.blue);

		cab3.setBounds(new Rectangle(5, 34, 1000, 30));
		cab3.setBorder(null);
		cab3.setFont(new Font("Arial", Font.BOLD, 14));
		cab3.setForeground(Color.blue);

		botoCargar.setBounds(new Rectangle(350, 100, 140, 30));
		botoDescargar.setBounds(new Rectangle(350, 150, 140, 30));
		botoSortir.setBounds(new Rectangle(350, 200, 140, 30));
		botoEntrar.setBounds(new Rectangle(350, 250, 140, 30));
	
		llistaDirec.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);// SINGLE_INTERVAL_SELECTION);
		JScrollPane barraDesplazamiento = new JScrollPane(llistaDirec);
		barraDesplazamiento.setPreferredSize(new Dimension(335, 300));
		barraDesplazamiento.setBounds(new Rectangle(5, 65, 335, 300));
		c.add(barraDesplazamiento);
		c.setLayout(null);

		c.add(camp);
		camp.setEditable(false);
		c.add(camp2);
		camp2.setEditable(false);
		c.add(botoCargar);
		c.add(botoDescargar);

		c.add(botoSortir);
		
		botoEntrar.setEnabled(false);
		c.add(botoEntrar);

		c.add(cab);
		c.add(cab2);
		c.add(cab3);
		cab.setEditable(false);
		cab2.setEditable(false);
		cab3.setEditable(false);

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(510, 450);
		setVisible(true);
	
		
		// --click en el boto de entrar a carpeta
		botoEntrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				if(node.getPath() != llistaDirectoris.get((llistaDirectoris.size()-1))) {
					llistaDirectoris.add(direcSelec);
					direcSelec = direcSelec +"\\"+ node.getNom();
					cab3.setText("ARREL " + direcSelec);
					System.out.println(llistaDirectoris.get(llistaDirectoris.size()-1));
				}else {
					direcSelec = llistaDirectoris.get(llistaDirectoris.size()-1);
					System.out.println(direcSelec);
					llistaDirectoris.remove(llistaDirectoris.size()-1);
					cab3.setText("ARREL " + direcSelec);
					System.out.println(llistaDirectoris.get(llistaDirectoris.size()-1));
				}
				
				//
				CanviDirectori cd = new CanviDirectori(direcSelec);
				try {
					outObjecte.writeObject(cd);
					//obtinc de nou la llista de Fitxers
					node = (EstructuraFitxers) inObjecte.readObject();
				} catch (IOException | ClassNotFoundException e1) {
					e1.printStackTrace();
				}
				EstructuraFitxers[] llista = node.getLlista();
				direcSelec = node.getPath();
				try {
					omplirLlista(llista, node.getNumeFitx());
				} catch (FileNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				camp2.setText("Numero de Fitxers en el Directori: " + llista.length);
			}
		});

		// --clic en un element de la llista
		llistaDirec.addListSelectionListener(new ListSelectionListener() {
			public void valueChanged(ListSelectionEvent lse) {
				if (lse.getValueIsAdjusting()) {
					FitxerSelec = "";
					Fitxercomplet = "";
				    node = (EstructuraFitxers) llistaDirec.getSelectedValue();					
					if (node.isDir()) {
						// es un Directori
						botoEntrar.setEnabled(true);
                       camp.setText("Carpeta " );
					} else {
						// Es tracta d'un Fitxer
						botoEntrar.setEnabled(false);
						FitxerSelec = node.getNom();
						Fitxercomplet = node.getPath();
						camp.setText("Fitxer seleccionat: " + FitxerSelec);
					}// fin else
				}//
			}
		});// fin llista

		// --al fer click en el boto Sortir
		botoSortir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					socket.close();					
					System.exit(0);
				} catch (IOException ex) {
					ex.printStackTrace();
				}
			}
		});

		// --al fer clic en el botó Actualitzar
		
		
		// --al fer clic en el boto Descargar
		botoDescargar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {				
				if (Fitxercomplet.equals(""))
					return;
				System.out.println("Demano aquest Fitxer " + Fitxercomplet);
				DemanaFitxer demano = new DemanaFitxer(Fitxercomplet);

				try {
					outObjecte.writeObject(demano);
					// demano el Fitxer
					// S'obre un Fitxer per començar empezar a copiar el que es rebi
					 
					FileOutputStream fos = new FileOutputStream("src\\B3_Servidor_Fitxers"+FitxerSelec);
					// Es crea un ObjectInputStream del socket per llegir els
					// bytes del Fitxer
					// obtinc los bytes
					Object obtinc = inObjecte.readObject();
					if (obtinc instanceof ObteFitxer) {
				          ObteFitxer fic = (ObteFitxer)obtinc;						
						fos.write(fic.getContingutFitxer());
						fos.close();
						JOptionPane.showMessageDialog(null,	"Fitxer DESCARREGAT");
					}

				} catch (IOException e1) {e1.printStackTrace();} 
				  catch (ClassNotFoundException e1) {e1.printStackTrace();}
			}
		});// Fi botó descargar

		// --fer click al botó cargar
		botoCargar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFileChooser f = new JFileChooser();
				f.setFileSelectionMode(JFileChooser.FILES_ONLY);
				f.setDialogTitle("Selecciona el Fitxer a pujar al SERVIDOR DE FITXERS");
				int returnVal = f.showDialog(f, "Cargar");
				
				if (returnVal == JFileChooser.APPROVE_OPTION) {
					File file = f.getSelectedFile();
					String arxiu = file.getAbsolutePath();
					String nombrearxiu = file.getName();
					BufferedInputStream in;
					try {
						in = new BufferedInputStream(new FileInputStream(
								arxiu));
						long bytes = file.length();// Fitxer.length();		
						System.out.println("tamany:"+file.length());
						byte[] buff = new byte[(int) bytes];
						int i, j = 0;

						while ((i = in.read()) != -1) {							
							buff[j] = (byte) i; //carga les dades en l'array
							j++;
						}
						in.close(); // tancar stream d'entrada
						Object ff = new EnviaFitxer(buff, nombrearxiu,direcSelec);
						outObjecte.writeObject(ff);
                                                JOptionPane.showMessageDialog(null,"Fitxer CARGADO");
						
						//obtinc de nou la llista de Fitxers
						node = (EstructuraFitxers) inObjecte.readObject();
						EstructuraFitxers[] llista = node.getLlista();
						direcSelec = node.getPath();
						omplirLlista(llista, node.getNumeFitx());
						camp2.setText("Número de Fitxers en el Directori: " + llista.length);

					} catch (FileNotFoundException e1) {e1.printStackTrace();} 
					  catch (IOException ee) {ee.printStackTrace();	}					
					  catch (ClassNotFoundException e2) {e2.printStackTrace();}

				}

			}

		});// Fi boto cargar
	}// ..FI CONSTRUCTOR
		// -----------------------------------------------------------------------------

	
	public void run() {				
		try {
			cab.setText("Connectant amb el servidor ........");
             // OBTENIR Directori ARREL
			Arrel = (EstructuraFitxers) inObjecte.readObject();			
			EstructuraFitxers[] nodes = Arrel.getLlista();//	 		
			direcSelec = Arrel.getPath();  
			llistaDirectoris.add(direcSelec);
			//if(Arrel.getNumeFich()> 0)
			omplirLlista(nodes,  Arrel.getNumeFitx());
			cab3.setText("ARREL: " + direcSelec);
			cab.setText("CONNECTAT AL SERVIDOR DE FitxerS");			
            camp2.setText("Número de Fitxers en el Directori: " + Arrel.getNumeFitx());
           
			
		} catch (IOException e1) {
			e1.printStackTrace();
			System.exit(1);
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
			System.exit(1);
		}      
		
	}// fi run
		// -----------------------------------------------------------------

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private static void omplirLlista(EstructuraFitxers[] files, int numero) throws FileNotFoundException {
		if (numero==0) return;
		DefaultListModel modeloLlista = new DefaultListModel();
		llistaDirec.setForeground(Color.blue);
		Font fuente = new Font("Courier", Font.PLAIN, 12);
		llistaDirec.setFont(fuente);
		llistaDirec.removeAll();		
		
		//afegir opció per tornar
		
		if (llistaDirectoris.size() != 1) {
			EstructuraFitxers carpetaAnterior = new EstructuraFitxers(llistaDirectoris.get(llistaDirectoris.size()-1));
			carpetaAnterior.setName("(...Tornar)");
			modeloLlista.addElement(carpetaAnterior);
		}
		
		for (int i = 0; i < files.length; i++)
			modeloLlista.addElement(files[i]);
		
		try {
			llistaDirec.setModel(modeloLlista);
		} catch (NullPointerException n) {	}

	}// Fi omplirLlista

	

	// main---------------------------------------------------------------------
	public static void main(String[] args) throws IOException {
		int PORT = 44441;
		//"192.168.0.195" localhost
		Socket s = new Socket("localhost", PORT);
		clientFitxers hiloC = new clientFitxers(s);
		hiloC.setBounds(0, 0, 540, 500);
		hiloC.setVisible(true);
		new Thread(hiloC).start();
	}// ..FI main

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ioc.dam.m9.uf3.eac2.b1;

import java.io.PrintStream;
import java.io.UnsupportedEncodingException;

/**
 * Programa de prova del OxfordDictionaryClient
 curs 21/22
 * 
 */
public class DictionaryTest {
    
    public static void main(String[] args) throws UnsupportedEncodingException {
        
       //IMPLEMENTA
    
    }
 }   


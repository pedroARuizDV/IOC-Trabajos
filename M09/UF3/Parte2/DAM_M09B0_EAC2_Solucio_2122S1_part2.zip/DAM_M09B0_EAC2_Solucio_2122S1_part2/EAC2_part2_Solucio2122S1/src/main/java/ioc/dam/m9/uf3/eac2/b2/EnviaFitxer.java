/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ioc.dam.m9.uf3.eac2.b2;

import java.io.Serializable;

@SuppressWarnings("serial")
public class EnviaFitxer implements Serializable {
	byte[] contingutFitxer;
	String Nom;
	String Directori;

	public EnviaFitxer(byte[] contingutFitxer, String Nom, String Directori) {
		super();
		this.contingutFitxer = contingutFitxer;
		this.Nom = Nom;
		this.Directori = Directori;
	}

	public String getNom() {
		return Nom;
	}

	public String getDirectori() {
		return Directori;
	}

	public byte[] getContingutFitxer() {
		return contingutFitxer;
	}
}
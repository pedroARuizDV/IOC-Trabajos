/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ioc.dam.m9.uf3.eac2.b2;


import java.io.*;
import java.net.*;
import javax.swing.*;

//SERVIDOR
public class Servidor {
	static Integer PORT = 44441;
	static public EstructuraFitxers NF;
	static ServerSocket servidor;

	// MAIN
	public static void main(String[] args) throws IOException {		
		String Directori = "";
		JFileChooser f =new JFileChooser();			
		f.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
		f.setDialogTitle("SELECCIONA EL Directori on estan els FitxerS");
		int returnVal = f.showDialog(f, "Seleccionar");
		
		if (returnVal == JFileChooser.APPROVE_OPTION) {
			File file = f.getSelectedFile();
			Directori = file.getAbsolutePath();		
			System.out.println(Directori);
		}
		
		if(Directori.equals("")){
			System.out.println("Ha de seleccionar un Directori .....");
			System.exit(1);
		}
		servidor = new ServerSocket(PORT);
		System.out.println("Servidor Iniciat en el Port: "+PORT);		
	
		while (true) {
			try {
				Socket client = servidor.accept();
				System.out.println("Benvingut el client");
				NF = new EstructuraFitxers(Directori);	
				FilServidor fil = new FilServidor(client, NF);
				fil.start(); // Executem el fil
			} catch (IOException e) {
				System.out.println(e.getMessage());
				System.exit(0);
			}
		}// while	
		
	} // main
	
} // ..fin SERVIDOR
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ioc.dam.m9.uf3.eac2.b2;

import java.io.Serializable;

@SuppressWarnings("serial")
public class ObteFitxer implements Serializable {
	byte[] contingutFitxer;

	public ObteFitxer(byte[] contingutFitxer) {
		this.contingutFitxer = contingutFitxer;
	}

	public byte[] getContingutFitxer() {
		return contingutFitxer;
	}
}
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ioc.dam.m9.uf3.eac2.b1;

import java.io.PrintStream;
import java.io.UnsupportedEncodingException;

/**
 * Programa de prova del OxfordDictionaryClient
 curs 19/20
 * 
 */
public class DictionaryTest {
    
    public static void main(String[] args) throws UnsupportedEncodingException {
        
        OxfordDictionaryClient cc = new OxfordDictionaryClient();
        String [] names = {"apple", "Please", "mandarina", "beer"};
        for(String name : names) {
            String traduccio =  cc.translate(name);
            if(traduccio==null) {
                traduccio = "<Aghhrrr, definició no trobada>";
            }
            System.out.println(name+":  -- > "+traduccio);            
        }   
    }
    
}


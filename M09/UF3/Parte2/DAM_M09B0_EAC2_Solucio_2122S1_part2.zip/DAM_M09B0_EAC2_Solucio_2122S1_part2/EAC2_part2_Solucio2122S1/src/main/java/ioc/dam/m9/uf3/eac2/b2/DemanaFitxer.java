/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ioc.dam.m9.uf3.eac2.b2;

import java.io.Serializable;

@SuppressWarnings("serial")
public class DemanaFitxer implements Serializable {
	String nombreFitxer;

	public String getNomFitxer() {
		return nombreFitxer;
	}

	public DemanaFitxer(String nombreFitxer) {
		this.nombreFitxer = nombreFitxer;
	}
}

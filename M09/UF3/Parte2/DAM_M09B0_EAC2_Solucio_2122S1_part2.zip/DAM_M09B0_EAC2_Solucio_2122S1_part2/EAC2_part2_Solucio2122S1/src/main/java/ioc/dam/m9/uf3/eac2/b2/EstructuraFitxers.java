/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ioc.dam.m9.uf3.eac2.b2;

import java.io.*;

public class EstructuraFitxers implements Serializable {

	private static final long serialVersionUID = 1L;
	private String name; // nom
	private String path; // nom complet
	private boolean isDir;// es un Directori

	private EstructuraFitxers[] llista; // llista de Fitxers i carpetes
	private int numeFitx; // numero de fitxers de la carpeta

	
    //constructors
	public EstructuraFitxers(String name) throws FileNotFoundException {
		// Construtor per defecte que s'utilitza en el servidor
		// name: Nom complet (Directori+nom) del Fitxer/Directori
		// en el servidor local
		File file = new File(name);		
		this.name = file.getName();
		this.path = file.getPath();
		this.isDir = file.isDirectory();
		
		this.llista = getLlistaFiles();
		if (file.isDirectory()) {
			File[] Fitxers = file.listFiles();
			this.numeFitx = 0;
			if (!(Fitxers == null))
				this.numeFitx = Fitxers.length;
		}
	}
	public EstructuraFitxers(String name, String path, boolean isDir, 
			int numF) {
		// Aquest constructor s'utilitza en les operacions
		// d'actualització d'arbre presentat en el client
		// No és obligatori implementar aquest mètode
		this.name = name;
		this.path = path;
		this.isDir = isDir;		
		this.numeFitx = numF; // num Fitxers si es Directori
	}

	public int getNumeFitx() {
		return numeFitx;
	}
	public EstructuraFitxers[] getLlista() {
		return llista;
	}
	public String toString() {
		String nom = this.name;
		if (this.isDir)
			nom = "(DIR) " + name;
		return nom;
	}	

	public boolean isDir() {
            
            return isDir;	
        }

	public String getNom() {
		String name_dir = name;
		if (isDir) {
			// En el cas d'un Fitxer sol se presenta el nom
			// del mateix utilitzant el mètode getName() associat a la classe File.
			// En el cas d'un Directori getName() retorna el nom complet
			// és a dir, el path absolut i solament es necessita el nom de la
			// carpeta
			// ja que el atribut path guarda aquesta informació.
			int l = path.lastIndexOf(File.separator);
			name_dir = path.substring(l + 1, path.length());
		}
		return name_dir;
	}

	public String getPath() {	
            return path;	
        }

	//public String getParent() {	return parent;	}

	
	EstructuraFitxers[] getLlistaFiles() {
		EstructuraFitxers[] llista = null;		
		String sDirectori = this.path;
		File f = new File(sDirectori);
		File[] Fitxers = f.listFiles();
		int longitud = Fitxers.length;
		if (longitud > 0) {//per si és selecciona una carpeta buida
			// és un Directori, creo un nou node
			llista = new EstructuraFitxers[longitud]; // array amb tots els Fitxers
			for (int x = 0; x < Fitxers.length; x++) {
				EstructuraFitxers element;
				String nom = Fitxers[x].getName();
				String path = Fitxers[x].getPath();
				boolean isDir = Fitxers[x].isDirectory();
				int num = 0;
				//String parent = Fitxers[x].getParent();
                                //si algun dels Fitxers del Directori seleccionat és 
				//a la vegada un Directori calculo el numero de Fitxers
				if (isDir) {					
					File[] fic = Fitxers[x].listFiles();
					if (!(fic == null))
						num = fic.length;
				}
				element = new EstructuraFitxers(nom, path, isDir,  num);
				llista[x] = element;

			}// for
		}
		return llista;
	}
	
	public void setName(String name) {
		this.name = name;
	}

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ioc.dam.m9.uf1.eac3.b1;



import java.io.BufferedReader; 
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader; 
import java.security.MessageDigest;


/**
 *
 * @author Usuari
 */
public class Hash {
  public static void main(String[] args) {
    try {
     /* if (args.length != 1) {        
          System.out.println("argumentos: <algorisme de resum>");
      }        System.exit(1); */     
    
    
 String algorisme = "SHA-512";            
 MessageDigest md = MessageDigest.getInstance(algorisme);
       try{
            
         
            // Pasa text clar a la funció resum
               
            // Genera el resum SHA1, MD5 o l'algorisme que l'hi haguem passat.
       
            //Pasar els resums a hexadecimal
       
            String s = "";
            for (int i = 0; i < resum.length; i++)
            {
               s += Integer.toHexString((resum[i] >> 4) & 0xf);
               s += Integer.toHexString(resum[i] & 0xf);
            }
            System.out.println("Resum: "+algorisme+" " + s);
           
         }
         //lectura de les dades del fitxer
         catch(java.io.FileNotFoundException fnfe) {System.out.println("ssssssss");}
         catch(java.io.IOException ioe) {}
      
      }   
      //declarar funcions resum
      catch(java.security.NoSuchAlgorithmException nsae) {}
      
   }
}
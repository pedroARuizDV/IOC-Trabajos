/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ioc.dam.m9.uf1.eac3.b3Explicacio;


import java.net.*;
import java.io.*;
import java.awt.*;
import static java.lang.Thread.MIN_PRIORITY;
import java.util.logging.Level;
import java.util.logging.Logger;

public class FakeVNCServer {

    public static void main(String arg[]) throws Exception {

        ServerSocket ss = new ServerSocket(2020);

        System.out.println("Starts listening for clients");

        while (true) {
            try {
                Socket skclient = ss.accept();
                Thread t = new Thread(new ClientThread(skclient));
                t.setPriority(MIN_PRIORITY);
                t.start();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

}

class ClientThread implements Runnable {

    long sleepInterval = 125;
    Socket skclient = null;
    DataOutputStream dos = null;
    DataInputStream dis = null;

    public ClientThread(Socket s) {
        this.skclient = s;
        try {
            dos = new DataOutputStream(s.getOutputStream());
            dis = new DataInputStream(s.getInputStream());
            System.out.println("Client des de " + s.getInetAddress().getHostAddress() + " connectat");
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void run() {
        java.awt.image.BufferedImage img = null;
        Robot r = null;
        try {
            r = new Robot();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        Dimension size = Toolkit.getDefaultToolkit().getScreenSize();
        Rectangle rect = new Rectangle(0, 0, size.width, size.height);

        javax.swing.ImageIcon icon = null;

        System.gc();
        try {
            dos.writeInt(serialize(new javax.swing.ImageIcon(r.createScreenCapture(rect))).length);
        } catch (IOException ex) {
            Logger.getLogger(ClientThread.class.getName()).log(Level.SEVERE, null, ex);
        }

        while (true) {
            try {
                System.gc();
                img = r.createScreenCapture(rect);
                icon = new javax.swing.ImageIcon(img);
                dos.write(serialize(icon));
                System.out.println(dos.size());
                dos.flush();
                icon = null;
                System.gc();
                try {
                    Thread.currentThread().sleep(sleepInterval);
                } catch (Exception e) {
                }
            } catch (Exception ex) {
            }
        }

    }

    public static byte[] serialize(Object obj) {
        if (obj == null) {
            return new byte[0];
        }
        try (ByteArrayOutputStream byteArrayOut = new ByteArrayOutputStream(); ObjectOutputStream objectOut = new ObjectOutputStream(byteArrayOut)) {
            objectOut.writeObject(obj);
            return byteArrayOut.toByteArray();
        } catch (final IOException e) {
            e.printStackTrace();
            return new byte[0];
        }
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ioc.dam.m9.uf1.eac3.b2;

import java.util.Arrays;
import java.util.List;
import javax.swing.JOptionPane;

public class BruteForce {
    /*
       * 
       Aquest projecte et dona totes les claus de l'algorisme Cesar
    
    
    Si volem xifrar amb una clau = 6, simplement desplaçariem la nostra lletra 6
    posicions en l'alfaber a -> seria la g. Per desencriptar seria el procès invers
    exemple 1:
       PER la clau 7 : 
       A B C D E F G H I J K L M --> 7 LLETRES 
       N O P Q R S T U V W X Y Z
      *Si volem desxifrar hola amb una clau 13 ens quedaría així
                H O L A
                O V S H
    */

    private Character[] alfabet = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'};
    private char[] textDecodificat;
    private String[] resultat;
    private List<Character> ListAlfabet; // llista de caracters amb l'objecte Character 

    public BruteForce(){
        //asList torna un tipus List quant se l'invoca passant un array com a parámetre 
        
        ListAlfabet = Arrays.asList(alfabet);
        resultat = new String[alfabet.length];
    }

    public String[] BusquedaDesxifrat(String TextXifrat) {
        // .toCharArray -->     converteix un String amb un array de chars
        //Converteix totes les lletres en majuscules i les guarda en un array de chars
         
        //farem un bucle per veure totes les possibilitats
            
            //farem que el textDecodificat tingui la mateixa longitut que el TextXifrat
            
            
            //anar probant amb tots els caracters del TextXifrat

                // si el missatge no té espais
                
    }

    
}
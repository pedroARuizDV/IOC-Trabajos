/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ioc.dam.m9.uf1.eac3.b3Explicacio;

import java.awt.image.*;
import javax.swing.*;
import java.io.*;
import java.net.*;
import java.awt.*;
import java.awt.event.*;

public class FakeVNCClient {

    Socket s = null;
    DataInputStream dis = null;
    JLabel l = new JLabel();
    JWindow win = new JWindow();
    ImageIcon icon = new ImageIcon();
    JFrame fr = new JFrame();
    String add = null;

    public FakeVNCClient() {
        try {

            String host = "127.0.0.1";
            s = new Socket(host, 2020);
            dis = new DataInputStream(s.getInputStream());
            fr.setTitle("Mostrant " + host + " al port 2020");
            fr.addWindowListener(new WindowCloser());
            fr.getContentPane().add(l);
            l.setIcon(icon);
            Dimension d = fr.getToolkit().getScreenSize();
            fr.setSize(300 * d.width / d.height, 300);
            fr.setVisible(true);

            int screenSize = dis.readInt();

            BufferedImage i = null;
            while (true) {
                try {
                    byte[] data = new byte[screenSize];
                    d = fr.getContentPane().getSize();
                    dis.readFully(data);
                    icon = (ImageIcon) deserialize(data);
                    if (d == null || icon == null) {
                        continue;
                    }
                    if (d.width > 0 && d.height > 0 && (d.width != icon.getIconWidth() || d.height != icon.getIconHeight())) {
                        icon.setImage(icon.getImage().getScaledInstance(d.width, d.height, i.SCALE_FAST));
                    }
                    l.setIcon(icon);
                    l.validate();
                    fr.validate();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static ImageIcon deserialize(byte[] objectBytes) {
        if (objectBytes == null || objectBytes.length == 0) {
            return null;
        }

        try (ByteArrayInputStream byteArrayIn = new ByteArrayInputStream(objectBytes); ObjectInputStream objectIn = new ObjectInputStream(byteArrayIn)) {
            return (ImageIcon) objectIn.readObject();
        } catch (final Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    class WindowCloser extends WindowAdapter {

        public void windowClosing(WindowEvent we) {
            try {
                s.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            System.exit(0);
        }
    }

    public static void main(String arg[]) {
        new FakeVNCClient();
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ioc.dam.m9.uf1.eac3.b3;

/**
 *
 * @author tomas
 */
/**
 *
 * @author david
 */
import java.awt.image.*;
import javax.swing.*;
import java.io.*;
import java.net.*;
import java.awt.*;
import java.awt.event.*;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/**
 *
 * @author david
 */


public class FakeVNCClient {

    Socket s = null;
    DataInputStream dis = null;
    DataOutputStream dos = null;
    JLabel l = new JLabel();
    JWindow win = new JWindow();
    ImageIcon icon = new ImageIcon();
    JFrame fr = new JFrame();
    String add = null;
    public byte[] IV_PARAM = {0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F};

    public FakeVNCClient() {

        try {

            String host = "127.0.0.1";

            s = new Socket(add, 2020);
            dis = new DataInputStream(s.getInputStream());
            dos = new DataOutputStream(s.getOutputStream());

            fr.setTitle("Mostrant " + host + " al port 2020");
            fr.addWindowListener(new WindowCloser());
            fr.getContentPane().add(l);
            l.setIcon(icon);
            Dimension d = fr.getToolkit().getScreenSize();
            fr.setSize(300 * d.width / d.height, 300);
            fr.setVisible(true);

            //GENERA EL PARELL DE CLAUS
            KeyPair keys = randomGenerate(2048);

            //ENVIA LA LONGITUD DE LA CLAU PÚBLICA I LA CLAU PUBLICA
            dos.writeInt(keys.getPublic().getEncoded().length);
            dos.write(keys.getPublic().getEncoded());

            //REP LA CLAU ENCRIPTADA
            byte[] encriptedSecretKey = new byte[256];
            dis.readFully(encriptedSecretKey);
            SecretKey clau = new SecretKeySpec(decryptSecretKey(encriptedSecretKey, keys.getPrivate()), "AES");

            BufferedImage i = null;
            while (true) {
                try {
                    int screenSize = dis.readInt();
                    byte[] data = new byte[screenSize];
                    d = fr.getContentPane().getSize();

                    //REP LA IMATGE I LA DESENCRIPTA
                    dis.readFully(data);
                    icon = deserialize(decryptData(clau, data));
                    if (d == null || icon == null) {
                        continue;
                    }
                    if (d.width > 0 && d.height > 0 && (d.width != icon.getIconWidth() || d.height != icon.getIconHeight())) {
                        icon.setImage(icon.getImage().getScaledInstance(d.width, d.height, i.SCALE_FAST));
                    }
                    l.setIcon(icon);
                    l.validate();
                    fr.validate();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static ImageIcon deserialize(byte[] objectBytes) {
        if (objectBytes == null || objectBytes.length == 0) {
            return null;
        }

        try (ByteArrayInputStream byteArrayIn = new ByteArrayInputStream(objectBytes); ObjectInputStream objectIn = new ObjectInputStream(byteArrayIn)) {
            return (ImageIcon) objectIn.readObject();
        } catch (final Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    class WindowCloser extends WindowAdapter {

        public void windowClosing(WindowEvent we) {
            try {
                s.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            System.exit(0);
        }
    }

    public byte[] decryptData(SecretKey sKey, byte[] data) {
        byte[] decryptedData = null;
        try {
            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            IvParameterSpec iv = new IvParameterSpec(IV_PARAM);
            cipher.init(Cipher.DECRYPT_MODE, sKey, iv);
            decryptedData = cipher.doFinal(data);
        } catch (Exception ex) {
            System.err.println("Error desxifrant les dades: " + ex);
        }
        return decryptedData;
    }

    public byte[] decryptSecretKey(byte[] data, PrivateKey prv) {
        byte[] decryptedData = null;
        try {
            Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding", "SunJCE");
            cipher.init(Cipher.DECRYPT_MODE, prv);
            decryptedData = cipher.doFinal(data);
        } catch (Exception ex) {
            System.err.println("Error desxifrant: " + ex);
        }
        return decryptedData;
    }

    public KeyPair randomGenerate(int len) {
        KeyPair keys = null;
        try {
            KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA");
            keyGen.initialize(len);
            keys = keyGen.genKeyPair();
        } catch (Exception ex) {
            System.err.println("Generador no disponible.");
        }
        return keys;
    }

    public static void main(String arg[]) {
        new FakeVNCClient();
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ioc.dam.m9.uf1.eac3.b3;

/**
 *
 * @author tomas
 */
import java.net.*;
import java.io.*;
import java.awt.*;
import static java.lang.Thread.MIN_PRIORITY;
import java.security.KeyFactory;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class FakeVNCServer  {

    public static void main(String arg[]) throws Exception {

        ServerSocket ss = new ServerSocket(2020);

        System.out.println("Starts listening for clients");

        while (true) {
            try {
                Socket skclient = ss.accept();
                Thread t = new Thread(new ClientThread(skclient));
                t.setPriority(MIN_PRIORITY);
                t.start();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }
}

class ClientThread implements Runnable {

    long sleepInterval = 125;
    Socket skclient = null;
    DataOutputStream dos = null;
    DataInputStream dis = null;
    public static final byte[] IV_PARAM = {0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F};

    public ClientThread(Socket s) {
        this.skclient = s;
        try {
            dos = new DataOutputStream(s.getOutputStream());
            dis = new DataInputStream(s.getInputStream());
            System.out.println("Client des de " + s.getInetAddress().getHostAddress() + " connectat");
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void run() {
        java.awt.image.BufferedImage img = null;
        Robot r = null;
        try {
            r = new Robot();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        Dimension size = Toolkit.getDefaultToolkit().getScreenSize();
        Rectangle rect = new Rectangle(0, 0, size.width, size.height);

        javax.swing.ImageIcon icon = null;

        //GENERA LA CLAU SECRETA
        SecretKey clau = passwordKeyGeneration("AlumneM09", 256);

        //REP LA LONGITUD DE LA CLAU PÚBLICA I LA CLAU PÚBLICA
        PublicKey publicKey;
        try {
            byte[] publicKeyBytes = new byte[dis.readInt()];
            dis.readFully(publicKeyBytes);
            publicKey = KeyFactory.getInstance("RSA").generatePublic(new X509EncodedKeySpec(publicKeyBytes));

            //ENVIA LA CLAU SECRETA ENCRIPTADA
            dos.write(encryptSecretKey(clau.getEncoded(), publicKey));

        } catch (IOException | NoSuchAlgorithmException | InvalidKeySpecException ex) {
            Logger.getLogger(ClientThread.class.getName()).log(Level.SEVERE, null, ex);
        }

        while (true) {
            try {
                System.gc();
                img = r.createScreenCapture(rect);
                icon = new javax.swing.ImageIcon(img);
                byte[] enc_data = encryptData(clau, serialize(icon));

                //ENVIA LA GRANDÀRIA DE LES DADES ENCRIPTADES
                dos.writeInt(enc_data.length);

                //ENVIA LA IMATGE ENCRIPTADA
                dos.write(enc_data);
                dos.flush();
                icon = null;
                System.gc();
                try {
                    Thread.currentThread().sleep(sleepInterval);
                } catch (Exception e) {
                }
            } catch (Exception ex) {
                break;
            }
        }
    }

    public static byte[] serialize(Object obj) {
        if (obj == null) {
            return new byte[0];
        }
        try (ByteArrayOutputStream byteArrayOut = new ByteArrayOutputStream(); ObjectOutputStream objectOut = new ObjectOutputStream(byteArrayOut)) {
            objectOut.writeObject(obj);
            return byteArrayOut.toByteArray();
        } catch (final IOException e) {
            e.printStackTrace();
            return new byte[0];
        }
    }

    public byte[] encryptData(SecretKey sKey, byte[] data) {
        byte[] encryptedData = null;
        try {
            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            IvParameterSpec iv = new IvParameterSpec(IV_PARAM);
            cipher.init(Cipher.ENCRYPT_MODE, sKey, iv);
            encryptedData = cipher.doFinal(data);
        } catch (Exception ex) {
            System.err.println("Error xifrant les dades: " + ex);
        }
        return encryptedData;
    }

    public byte[] encryptSecretKey(byte[] data, PublicKey pub) {
        byte[] encryptedData = null;
        try {
            Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding", "SunJCE");
            cipher.init(Cipher.ENCRYPT_MODE, pub);
            encryptedData = cipher.doFinal(data);
        } catch (Exception ex) {
            System.err.println("Error xifrant: " + ex);
        }
        return encryptedData;
    }
    public SecretKey passwordKeyGeneration(String text, int keySize) {
        SecretKey sKey = null;
        if ((keySize == 128) || (keySize == 192) || (keySize == 256)) {
            try {
                byte[] data;
                data = text.getBytes("UTF-8");
                MessageDigest md;
                md = MessageDigest.getInstance("SHA-256");
                byte[] hash = md.digest(data);
                System.out.println("Hash: " + Arrays.toString(hash));
                byte[] key = Arrays.copyOf(hash, keySize / 8);
                sKey = new SecretKeySpec(key, "AES");
            } catch (UnsupportedEncodingException | NoSuchAlgorithmException ex) {
                System.err.println("Error generant la clau:" + ex);
            }
        }
        return sKey;
    }
}


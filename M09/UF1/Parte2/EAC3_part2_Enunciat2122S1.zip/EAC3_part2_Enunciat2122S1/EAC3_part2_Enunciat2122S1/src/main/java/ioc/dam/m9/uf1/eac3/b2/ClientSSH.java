package ioc.dam.m9.uf1.eac3.b2;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Usuari
 */

import ioc.dam.m9.uf1.eac3.b2.CaracteristiquesUsuari;
import com.jcraft.jsch.Channel;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.UserInfo;
 
public class ClientSSH {
    private static final String user = "tbigorda";
    private static final String host = "127.0.0.1";
    private static final Integer port = 22;
    private static final String pass = "123456";
 
    public static void main(String[] args) throws Exception{
        System.out.println("----- INICI ------");
 
        
        //IMPLEMENTA
        
 
        System.out.println("------ FINAL ------");
    }
}
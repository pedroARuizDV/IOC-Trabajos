/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ioc.dam.m9.uf1.eac3.b1;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.SocketException;
import java.security.KeyStore;
import javax.net.SocketFactory;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;

public class FitxerClientSegur {

    private static String CLAU_CLIENT = "C:\\Program Files\\Java\\jre1.8.0_261\\bin\\client_ks"; //heu de ficar la vostra direcció
    private static String CLAU_CLIENT_PASSWORD = "456456";
    private static PrintWriter writer;
    private static BufferedReader reader;
    private static Socket s;

    public static void main(String[] args) throws Exception {

        //Estableix el magatzem de claus a utilitzar per validar el certificat del servidor
        System.setProperty("javax.net.ssl.trustStore", CLAU_CLIENT);
        System.setProperty("javax.net.debug", "ssl,handshake");

        FitxerClientSegur client = new FitxerClientSegur();

        //IMPLEMENTA
            
        
            //Envio missatge al servidor
       
        
            
            //Llegeixo missatge que rebo del servidor

       

    }

    private Socket clientSenseCert() throws Exception {
        SocketFactory sf = SSLSocketFactory.getDefault();
        Socket s = sf.createSocket("localhost", 8443);
        return s;
    }

    Socket clientAmbCert() throws Exception {
        SSLContext context = SSLContext.getInstance("TLS");
        KeyStore ks = KeyStore.getInstance("jceks");

        ks.load(new FileInputStream(CLAU_CLIENT), null);
        KeyManagerFactory kf = KeyManagerFactory.getInstance("SunX509");
        kf.init(ks, CLAU_CLIENT_PASSWORD.toCharArray());
        context.init(kf.getKeyManagers(), null, null);

        SocketFactory factory = context.getSocketFactory();
        Socket s = factory.createSocket("localhost", 8443);
        return s;
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ioc.dam.m9.uf1.eac3.b1;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.SocketException;
import java.security.KeyStore;
import java.util.Scanner;
import javax.net.SocketFactory;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;

public class FitxerClientSegur {

    private static String CLAU_CLIENT = "C:\\Program Files\\Java\\jre1.8.0_261\\bin\\client_ks";
    private static String CLAU_CLIENT_PASSWORD = "456456";
   public static void main(String[] args) throws Exception {
     
  //Estableix el magatzem de claus a utilitzar per validar el certificat del servidor
  String missatge="Hola que tal";
  System.setProperty("javax.net.ssl.trustStore", CLAU_CLIENT);
  System.setProperty("javax.net.debug", "ssl,handshake");
  
  FitxerClientSegur client = new FitxerClientSegur();
  Socket s = client.clientAmbCert();
  Scanner lector=new Scanner(System.in);
  
  PrintWriter writer = new PrintWriter(s.getOutputStream());
  BufferedReader reader = new BufferedReader(new InputStreamReader(s.getInputStream()));
  //OutputStream os = s.getOutputStream();
  //os.write(missatge.getBytes());
  
  writer.println("Hola Servidor (Meritxell), Soc el Client (Núria) i tenim una connexió segura");
    writer.flush();
  while(true){
      String resposta="";
      System.out.println("Escriu un missatge i fica EXIT per sortir ");
      resposta=lector.nextLine();
      
      if(resposta.equals("EXIT")){
          writer.flush();
          s.close();
          break;
      }
      writer.println(resposta);
      writer.flush();
       //System.out.println(reader.readLine());

      
  }
    
     
   
   

  
  
  
 }

 private Socket clientSenseCert() throws Exception {
  SocketFactory sf = SSLSocketFactory.getDefault();
  Socket s = sf.createSocket("localhost", 8443);
  return s;
 }

 private Socket clientAmbCert() throws Exception {
  SSLContext context = SSLContext.getInstance("TLS");
  KeyStore ks = KeyStore.getInstance("jceks");
  
  ks.load(new FileInputStream(CLAU_CLIENT), null);
  KeyManagerFactory kf = KeyManagerFactory.getInstance("SunX509");
  kf.init(ks, CLAU_CLIENT_PASSWORD.toCharArray());
  context.init(kf.getKeyManagers(), null, null);
  
  SocketFactory factory = context.getSocketFactory();
  Socket s = factory.createSocket("localhost", 8443);
  return s;
 }
}
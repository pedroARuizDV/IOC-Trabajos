package ioc.dam.m9.uf1.eac3.b2;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Usuari
 */

import ioc.dam.m9.uf1.eac3.b2.CaracteristiquesUsuari;
import com.jcraft.jsch.Channel;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.UserInfo;
 
public class ClientSSH {
    private static final String user = "tbigorda";
    private static final String host = "127.0.0.1";
    private static final Integer port = 22;
    private static final String pass = "123456";
 
    public static void main(String[] args) throws Exception{
        System.out.println("----- INICI ------");
 
        JSch jsch = new JSch();
        Session session = jsch.getSession(user, host, port);
        UserInfo ui = new CaracteristiquesUsuari(pass, null);
        session.setUserInfo(ui);
        session.setPassword(pass);
       
        session.connect();
              
        Channel channel=session.openChannel("exec");
        System.out.println("conectat al servidor ssh");

     //   ChannelExec channelExec = (ChannelExec)session.openChannel("exec");
        String command = "cmd /C dir ";
        ((ChannelExec)channel).setCommand(command);
        InputStream in=channel.getInputStream();
        channel.connect();
      
       // InputStream in = channelExec.getInputStream();
 
        BufferedReader reader = new BufferedReader(new InputStreamReader(in));
        String linea = null;
        int index = 0;
 
        while ((linea = reader.readLine()) != null) {
            System.out.println(++index + " : " + linea);
        }
        System.out.println(pass);
        channel.disconnect();
        session.disconnect();
 
        System.out.println("------ FINAL ------");
    }
}
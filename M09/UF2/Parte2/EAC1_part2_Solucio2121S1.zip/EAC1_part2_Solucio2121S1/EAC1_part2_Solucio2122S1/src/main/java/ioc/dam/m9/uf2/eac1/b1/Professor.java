/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ioc.dam.m9.uf2.eac1.b1;

/**
 *
 * @author tomas
 */

public class Professor extends Thread {

    private Despatx despatx;

    public Professor(Despatx despatx) {
        this.despatx = despatx;
    }

   

    public void run() {

        while (true) {

            try {
                despatx.esperarAlumne();
                //Parlar amb l'alumne
                sleep(5000);
                despatx.acabarXerrada();
                //Decansa una mica
                sleep(1000);
            } catch (InterruptedException e) {
            }
        }

    }
}


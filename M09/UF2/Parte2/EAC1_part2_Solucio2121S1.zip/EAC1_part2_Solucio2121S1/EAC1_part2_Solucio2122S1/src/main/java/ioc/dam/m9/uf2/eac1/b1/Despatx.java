/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ioc.dam.m9.uf2.eac1.b1;

/**
 *
 * @author tomas
 */
public class Despatx {

    private int nCadires;
    private int nCadiresOcupades = 0;
    private boolean cadiraProfeOcupada = false;
    private boolean fiXerrada = false;
    private boolean profeDormit = false;

    public Despatx(int nCadires) {
        this.nCadires = nCadires;
    }

    public synchronized boolean entrar(int alumneId)
            throws InterruptedException {

        if (nCadiresOcupades == nCadires) {

            System.out.println("---- L'alumne " + alumneId + " se'n va sense parlar");
            return false;
        } else {

            if (!profeDormit) {

                nCadiresOcupades++;
                System.out.println("---- L'alumne " + alumneId + " s'asseu a esperar");
                while (cadiraProfeOcupada) {
                    wait();
                }

                nCadiresOcupades--;
            }

            cadiraProfeOcupada = true;
            fiXerrada = false;

            if (profeDormit) {
                System.out.println("---- L'alumne " + alumneId + " desperta al profe");
                notifyAll();
            }

            System.out.println("---- L'alumne " + alumneId + " entra a xerrar");
            while (!fiXerrada) {
                wait();
            }

            cadiraProfeOcupada = false;

            //Que passi el següent
            notifyAll();

            System.out.println("---- L'alumne " + alumneId + " se va després de xerrar");
            return true;
        }

    }

    public synchronized void esperarAlumne()
            throws InterruptedException {

        profeDormit = true;
        while (!cadiraProfeOcupada) {
            System.out.println("++++ Profe esperant alumne");
            wait();
        }
        profeDormit = false;
        System.out.println("++++ Profe xerrant");
    }

    public synchronized void acabarXerrada() {
        fiXerrada = true;
        System.out.println("++++ Profe acaba de xerrar");
        notifyAll();
    }

}


package ioc.dam.m9.uf2.eac1.b2;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;

/**
 *
 * @author Usuari
 */
public class CaixerAutomatic {

    private static final int MAX_TIME = 1500;

    private final int numCaixerAutomatic;
    private boolean lliure = true;
    private Queue<Integer> q = new LinkedList();
    private int clientUtilitzant;

    public CaixerAutomatic(int id) {
        numCaixerAutomatic = id;

    }

    public synchronized void passaACuaCaixer(int numCli) {
        q.add(numCli);
       System.out.println("Es dirigeix al caixer automàtic " + numCaixerAutomatic + "  el client " + numCli);
       System.out.println("Client " + numCli + " es fica a la cua del caixer automàtic  " + numCaixerAutomatic);

    }

     public synchronized void atendre() {
        while (!isLliure()) {
            try {
                wait();
            } catch (InterruptedException ex) {
                System.out.println(ex.getMessage());

            }
        }
        clientUtilitzant = q.poll();
        setLliure(false);
        System.out.println("Està al caixerAutomàtic: " + numCaixerAutomatic + " realitzant una operació el client " + clientUtilitzant);

  
       Resultats.clients_atessos++;      

    }

    public synchronized void surt() {
        System.out.println("Finalitzada l'operacio marxa del caixer automàtic " + numCaixerAutomatic + "  el client " + clientUtilitzant);
        setLliure(true);
        notifyAll();

    }

    public synchronized boolean isLliure() {
        return lliure;
    }

    public synchronized void setLliure(boolean lliure) {
        this.lliure = lliure;
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ioc.dam.m9.uf2.eac1.b2;

import java.util.Random;

/**
 *
 * 
 */
public class Client extends Thread {
     private static final int MAX_DELAY = 3000; 

    int id;
      Banc sup;
      boolean sortir;
      public static float temps_espera;

    public Client(int id, Banc sup) {
        this.id = id;
        this.sup = sup;
    }

   

  
   public void run() {
       
       Random r= new Random();
       sup.arribaClient(id);
        try {
            
        System.out.println("Client " + id + " realizant Operació bancaria ");
        Thread.sleep(new Random().nextInt(MAX_DELAY));
   
            //Fer operacio
            long s = System.currentTimeMillis();       
            
            int numCaixa=r.nextInt(sup.numCaixers);
            sup.passaACuaCaixerAutomatic(id, numCaixa);
            sup.atendre(numCaixa);
            
            Thread.sleep(new Random().nextInt(MAX_DELAY));
            sup.surt(numCaixa);
            long espera = System.currentTimeMillis() - s;    
            Resultats.temps_espera += espera;    

            System.out.println("Client " + id + " sortint després d'esperar " + espera + " milisegons"); 

            
        } catch (InterruptedException ex) {
            System.out.println(ex.getMessage());
        }
       
       
   }
}

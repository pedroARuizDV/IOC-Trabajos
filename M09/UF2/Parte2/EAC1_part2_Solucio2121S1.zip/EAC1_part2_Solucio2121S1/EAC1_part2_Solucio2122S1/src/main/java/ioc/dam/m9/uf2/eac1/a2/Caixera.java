/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ioc.dam.m9.uf2.eac1.a2;

/**
 *
 * @author Usuari
 */
public class Caixera {

	private String nom;

	// Constructor, getter y setter

    public Caixera(String nom) {
        this.nom = nom;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

        
	public void processarCompra(Client client, long timeStamp) {

		System.out.println("La Caixera " + this.nom + 
				" COMENÇA A PROCESSAR LA COMPRA DEL CLIENT: " + client.getNom() + 
				" EN EL Temps: " + (System.currentTimeMillis() - timeStamp) / 1000	+
				"seg");
                int s=0;
		for (int i = 0; i < client.getCarroCompra().length; i++) { 
				
                                this.esperarXsegons(client.getCarroCompra()[i]);
                                
				System.out.println("Processat el producte " + (i + 1) +  
				" ->Temps: " + (System.currentTimeMillis() - timeStamp) / 1000 + 
				"seg");
		}

		System.out.println("La caixera " + this.nom + " HA ACABAT DE PROCESSAR " + 
				client.getNom() + " EN EL TEMPS: " + 
				(System.currentTimeMillis() - timeStamp) / 1000 + "seg");

	}


	private void esperarXsegons(int segons) {
		try {
			Thread.sleep(segons * 1000);
		} catch (InterruptedException ex) {
			Thread.currentThread().interrupt();
		}
	}

}
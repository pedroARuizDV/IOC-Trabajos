/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ioc.dam.m9.uf2.eac1.b1;

/**
 *
 * @author tomas
 */
import java.util.logging.Level;
import java.util.logging.Logger;

public class DamM9 {

    public static void main(String[] args)  {

        final int nCadires = 4;
        final int nAlumnes = 10;
        Despatx despatx = new Despatx(nCadires);
        Professor tomas = new Professor(despatx);
        Alumne[] alumnes = new Alumne[nAlumnes];

        //IMPLEMENTA

    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ioc.dam.m9.uf2.eac1.b1;

/**
 *
 * @author tomas
 */
public class Alumne extends Thread {

    private final Despatx despatx;
    private final int alumneId;
    private boolean fiXerrada = false;

    public Alumne(Despatx despatx, int alumneId) {
        this.despatx = despatx;
        this.alumneId = alumneId;
    }

 
    @Override
    public void run() {

        while (!fiXerrada) {

            try {
                sleep(2000);
                fiXerrada = despatx.entrar(alumneId);
                //Xerrada
                if (!fiXerrada) {

                    //M'espero i ho torno a intentar
                    sleep(4000);
                }
            } catch (InterruptedException e) {
            }

        }
    }
}


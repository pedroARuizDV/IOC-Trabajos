/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ioc.dam.m9.uf2.eac1.b1;

/**
 *
 * @author tomas
 */
public class Despatx {

    private int nCadires;
    private int nCadiresOcupades = 0;
    private boolean cadiraProfeOcupada = false;
    private boolean fiXerrada = false;
    private boolean profeDormit = false;

    public Despatx(int nCadires) {
        this.nCadires = nCadires;
    }

    public synchronized boolean entrar(int alumneId)
            throws InterruptedException {

       //IMPLEMENTA
        
            //Que passi el següent
            notifyAll();

            System.out.println("---- L'alumne " + alumneId + " se va després de xerrar");
            return true;
        }

    }

    public synchronized void esperarAlumne()
            throws InterruptedException {

        
            //IMPLEMENTA

    }

    public synchronized void acabarXerrada() {
        
        //IMPLEMENTA

    }

}

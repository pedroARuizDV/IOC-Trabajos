package ioc.dam.m9.uf2.eac1.b2;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.Random;

/**
 *
 * 
 */
public class Client extends Thread {
     private static final int MAX_DELAY = 3000; 

    int id;
      Banc sup;
      boolean sortir;
      public static float temps_espera;

    public Client(int id, Banc sup) {
       //implementar
    }

   

  
   public void run() {
       
      
       
       
            
        //implementar
       
       
   }
}
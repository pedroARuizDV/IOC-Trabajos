
package ioc.dam.m9.uf2.eac1.b2;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;

/**
 *
 * @author Usuari
 */



public class CaixerAutomatic {

    private static final int MAX_TIME = 1500;

    private final int numCaixerAutomatic;
    private boolean lliure = true;
    private Queue<Integer> q = new LinkedList();
    private int clientUtilitzant;

    public CaixerAutomatic(int id) {
        numCaixerAutomatic = id;

    }

    public synchronized void passaACuaCaixer(int numCli) {
        
        //IMPLEMENTA
        
    }

     public synchronized void atendre() {
            
        //IMPLEMENTA

    }

    public synchronized void surt() {
               //IMPLEMENTA

    }

    public synchronized boolean isLliure() {
                //IMPLEMENTA

    }

    public synchronized void setLliure(boolean lliure) {
                //IMPLEMENTA

    }

}
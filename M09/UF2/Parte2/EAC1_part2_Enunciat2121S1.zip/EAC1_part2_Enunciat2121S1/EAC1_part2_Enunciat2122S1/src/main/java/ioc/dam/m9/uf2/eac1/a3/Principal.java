/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ioc.dam.m9.uf2.eac1.a3;

import ioc.dam.m9.uf2.eac1.a3.CaixeraThread;

/**
 *
 * @author Usuari
 */
public class Principal {

	public static void main(String[] args) {

		Client cliente1 = new Client("Client 1", new int[] { 2, 2, 1, 5, 2, 3 });
		Client cliente2 = new Client("Client 2", new int[] { 1, 3, 5, 1, 1 });

		// Temps inicial de referencia
		long initialTime = System.currentTimeMillis();
                
		CaixeraThread caixera1 = new CaixeraThread("Caixera 1", cliente1, initialTime);
		CaixeraThread caixera2 = new CaixeraThread("Caixera 2", cliente2, initialTime);

		caixera1.start();
		caixera2.start();
	}
} 

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ioc.dam.m9.uf2.eac1.a3;

/**
 *
 * @author Usuari
 */
public class Client {

	private String nom;
	private int[] carroCompra;

	// Constructor, getter y setter

    public Client(String nom, int[] carroCompra) {
        this.nom = nom;
        this.carroCompra = carroCompra;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public int[] getCarroCompra() {
        return carroCompra;
    }

    public void setCarroCompra(int[] carroCompra) {
        this.carroCompra = carroCompra;
    }

}


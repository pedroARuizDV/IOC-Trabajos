

package ioc.dam.m9.uf2.eac1.b2;

/**
 *
 * @author Usuari
 */
public class Resultats{ 
    public static float temps_espera; 
    public static float clients_atessos; 
}


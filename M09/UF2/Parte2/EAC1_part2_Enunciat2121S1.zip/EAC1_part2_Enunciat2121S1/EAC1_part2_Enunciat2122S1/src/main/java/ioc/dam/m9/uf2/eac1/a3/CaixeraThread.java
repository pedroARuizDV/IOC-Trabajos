/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ioc.dam.m9.uf2.eac1.a3;

/**
 *
 * @author Usuari
 */
public class CaixeraThread extends Thread {

	private String nom;

	private Client client;

	private long initialTime;

	// Constructor, getter & setter

    public CaixeraThread() {
    }

    public CaixeraThread(String nom, Client client, long initialTime) {
        this.nom = nom;
        this.client = client;
        this.initialTime = initialTime;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public Client getClient() {
        return client;
    }

    public void setClient(Client client) {
        this.client = client;
    }

    public long getInitialTime() {
        return initialTime;
    }

    public void setInitialTime(long initialTime) {
        this.initialTime = initialTime;
    }

         
        
	@Override
	public void run() {

		System.out.println("La caixera " + this.nom + " Comença a Processar la COMPRA DEL CLIENT " 
					+ this.client.getNom() + " EN EL TEMPS: " 
					+ (System.currentTimeMillis() - this.initialTime) / 1000 
					+ "seg");

		for (int i = 0; i < this.client.getCarroCompra().length; i++) { 
			this.esperarXsegons(client.getCarroCompra()[i]); 
			System.out.println("Processat el producte " + (i + 1) 
			+ " del client " + this.client.getNom() + "->TEMPS: " 
			+ (System.currentTimeMillis() - this.initialTime) / 1000 
			+ "seg");

		}

		System.out.println("La caixera " + this.nom + " HA ACABAT DE PROCESSAR " 
						+ this.client.getNom() + " EN EL TEMPS: " 
						+ (System.currentTimeMillis() - this.initialTime) / 1000 
						+ "seg");
	}

	private void esperarXsegons(int segons) {
		try {
			Thread.sleep(segons * 1000);
		} catch (InterruptedException ex) {
			Thread.currentThread().interrupt();
		}
	}

}

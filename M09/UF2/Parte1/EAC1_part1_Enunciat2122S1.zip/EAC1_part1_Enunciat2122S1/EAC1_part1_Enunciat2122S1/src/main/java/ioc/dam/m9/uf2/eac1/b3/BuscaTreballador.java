package ioc.dam.m9.uf2.eac1.b3;

import java.util.ArrayList;
import java.util.concurrent.RecursiveTask;

/**
 *
 * @author 
 */
public class BuscaTreballador extends RecursiveTask<Treballador> {

    private ArrayList<Treballador> llistat;
    private int primer;
    private int ultim;
    private int codi;
    private static boolean trobat = false;

    public BuscaTreballador(ArrayList<Treballador> llistat, int primer, int ultim, int codi) {
       
        //IMPLEMENTA

    }

    protected Treballador compute() {
        
        
        //IMPLEMENTA
        
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ioc.dam.m9.uf2.eac1.b2;

/**
 * Programa principal de l'exercici "Servei Al Surfer"
 * 
 */
public class Programa {
    
    public static void main(String[] args){
        ServeiAlSurfer sas = new ServeiAlSurfer();
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ioc.dam.m9.uf2.eac1.b1;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.logging.Level;
import java.util.logging.Logger;


public class Comandes {
    
    public static void main(String[] args) {
        
        try {
            
            // Crear ProcessBuilder.
            
            // Utilitzem la comanda "notepad.exe" i obrim el fitxer
           
            
             
            // Tancar manualment Notepad
            System.out.println("Notepad tancat");  
                        
            //Utilitzem la comanda cmd.exe
            
            
            
                
               
        
            //llegim el contingut de la comanda DIR    
                
                
           
            
        } catch (IOException ex) {
            Logger.getLogger(Comandes.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

}
        
        
        
        
        
    

        
       
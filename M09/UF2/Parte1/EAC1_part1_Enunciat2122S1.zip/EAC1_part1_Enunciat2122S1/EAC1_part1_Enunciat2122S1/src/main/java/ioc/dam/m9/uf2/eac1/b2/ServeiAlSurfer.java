/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ioc.dam.m9.uf2.eac1.b2;

/**
 *
 * 
 */
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Aquesta classe proporciona un servei de consultes del vent 
 * pensat per surfers que desitgen saber la platja que té més 
 * vent d'una llista fixada de platges favorites.
 * 
 *
 */
public class ServeiAlSurfer implements Runnable{

    String [] codisPlatges = { "Barceloneta", "Bogatell", "Cabrera", "Calade-Santa-Cristina", "Comandancia", "Desembocaduradel-Tordera", "Masnou", "Empuriabrava", "Garraf", "La-Rotonda", "Latigo", "Miami-Platja", "Montgat", "Nova-Mar-Bella-Barcelona", "Peyo-s", "Platja-de-Sant-Pol", "Playade-Premia", "Playade-Sant-Sebastia", "Port-de-Mataro", "Port-Ginesta-Castelldefels", "Roc-San-Cayetano", "Saint-Andreu-de-Llavaneres", "Sant-Marti", "Segur-de-Calafell", "Torre-Bank", "Vilassar" ,
                    "La-Salvaje","Deba","Guibeleco","Hondarribia","Islade-Izaro","Karramarro","La-Concha","Menakoz","Mundaka","Mutriku","Orio","Orrua","Pena-Roja","Playade-Aizkorri","Playade-Arrietara","Playade-Arrigunaga","Playade-Barrika","Playade-Ereaga","Playade-Gaztetape","Playade-Gros","Playade-Karraspio","Playade-Laga","Playade-Laida","Playade-Ogeia","Playade-Ondarreta_Pikua","Playade-Ondarreta_Picodel-Tenis","Plentzia","Punta-Galea","Roca-Puta","Sopelana","Zarautz","Zumaya" };

    /**
     * En el constructor engeguem un servei d'execució programada que periòdicament
     * llanci la consulta de la platja amb més vent.
     */
    public ServeiAlSurfer() {
        
        //IMPLEMENTA
        // Creem un scheduled executor per programar l'execució d'un fil periòdicament.
        
        // Programem la consulta de vents cada 20 segons ( hauria de ser 1 cop al dia )
        

        try {
            // Esperem el temps que ens interessi mantenir el servei
            // actiu
            
            // Aturem el servei.
        } catch (InterruptedException ex) {}
        
        
    }
    
    @Override
    public void run() {
        System.out.println("Fent la consulta dels vents a les diverses platges");
        ferConsulta();
    }
    
    /**
     * Aquest mètode consulta amb la classe ConsultaVent la velocitat
     * del vent per cadascuna de les platges de l'array codisPlatges.
     * Mostra per la consola un missatge com el següent:
     * 
     *          Platja amb més vent:La-Salvaje, vent:45 km/h
     * 
     * Que correspon a la platja de la llista que tindrà més vent l'endemà 
     *  de la consulta.
     * 
     * Les consultes cal fer-les usant un patró Executor, per poder
     * llançar cada consulta en fils separats, cosa que implicarà una 
     * millora notable del rendiment.
     * 
     */
    public void ferConsulta(){
        try {
            
            //IMPLEMENTA
                
            }
        } catch (Exception ex) {
            Logger.getLogger(ServeiAlSurfer.class.getName()).log(Level.SEVERE, null, ex);
        }                       
    }


}


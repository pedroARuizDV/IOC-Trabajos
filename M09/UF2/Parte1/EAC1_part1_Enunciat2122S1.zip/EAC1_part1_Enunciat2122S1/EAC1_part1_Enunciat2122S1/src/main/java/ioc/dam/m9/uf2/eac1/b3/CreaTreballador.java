package ioc.dam.m9.uf2.eac1.b3;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

/**
 *
 * @author 
 */
public class CreaTreballador {
    
    ArrayList<Treballador>treballador = new ArrayList();
    
    ArrayList<Treballador> obtenirLlistat(){
        Random r = new Random();
        for (int i = 1; i <= 7000; i++) {
            Treballador al= new Treballador(i,Math.abs(r.nextInt(1000000)));
            treballador.add(al);
                     
        }
        Collections.shuffle(treballador);
        return treballador;
        
        
        
        
    }
    
    
}

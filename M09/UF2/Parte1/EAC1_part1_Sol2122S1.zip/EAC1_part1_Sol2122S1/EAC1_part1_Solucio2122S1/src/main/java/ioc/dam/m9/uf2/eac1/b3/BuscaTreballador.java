package ioc.dam.m9.uf2.eac1.b3;

import java.util.ArrayList;
import java.util.concurrent.RecursiveTask;

/**
 *
 * @author 
 */
public class BuscaTreballador extends RecursiveTask<Treballador> {

    private ArrayList<Treballador> llistat;
    private int primer;
    private int ultim;
    private int codi;
    private static boolean trobat = false;

    public BuscaTreballador(ArrayList<Treballador> llistat, int primer, int ultim, int codi) {
        this.llistat = llistat;
        this.primer = primer;
        this.ultim = ultim;
        this.codi = codi;

    }

    protected Treballador compute() {
        Treballador a = null;
        if (ultim - primer < 10) {
            for (int i = primer; i <= ultim; i++) {
                if (llistat.get(i).codi == codi) {
                    a = llistat.get(i);
                    trobat = true;
                    return a;
                }

            }
            return a;
        } else {
            if (!trobat) {
                int mig = ((primer + ultim) / 2);
                BuscaTreballador f1 = new BuscaTreballador(llistat, primer, mig, codi);
                BuscaTreballador f2 = new BuscaTreballador(llistat, mig + 1, ultim, codi);
                f1.fork();
                f2.fork();
                Treballador al1 = f2.join();
                Treballador al2 = f1.join();
                if (al1 != null) {
                    trobat = true;
                    a = al1;
                } else if (al2 != null) {
                    trobat = true;
                    a = al2;
                }
            }

            return a;

        }

    }

}

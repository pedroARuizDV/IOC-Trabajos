package ioc.dam.m9.uf2.eac1.b3;

/**
 *
 * @author 
 */
public class Treballador {
    int codi;
    int followers;

    public Treballador(int codi, int followers) {
        this.codi = codi;
        this.followers = followers;
    }
    
    
}

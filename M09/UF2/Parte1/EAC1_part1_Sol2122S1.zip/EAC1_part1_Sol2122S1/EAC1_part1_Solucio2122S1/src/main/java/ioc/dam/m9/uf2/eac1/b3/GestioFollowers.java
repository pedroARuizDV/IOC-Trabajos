package ioc.dam.m9.uf2.eac1.b3;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.concurrent.ForkJoinPool;

/**
 *
 * @author
 */
public class GestioFollowers {

    public static void main(String[] args) {
        Scanner lector=new Scanner(System.in);
        ForkJoinPool pool = new ForkJoinPool();
        CreaTreballador l = new CreaTreballador();
        ArrayList<Treballador> llista = l.obtenirLlistat();
        System.out.println("Introduïm codi del treballador a buscar");
        int codi=lector.nextInt();
        BuscaTreballador f = new BuscaTreballador(llista, 0, llista.size() - 1, codi);
        Treballador a = pool.invoke(f);

        if (a == null) {
            System.out.println("El treballador intruduït NO existeix");

        } else {
            System.out.println("el codi del treballador és: " +a.codi + " té : " + a.followers + " followers.");

        }
    }

}

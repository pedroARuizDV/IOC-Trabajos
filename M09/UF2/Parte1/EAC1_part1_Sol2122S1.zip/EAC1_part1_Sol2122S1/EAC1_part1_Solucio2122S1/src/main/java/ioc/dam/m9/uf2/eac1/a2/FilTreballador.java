/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ioc.dam.m9.uf2.eac1.a2;

/**
 *
 * @author Usuari
 */


import java.util.Calendar;
import java.util.GregorianCalendar;

 class FilTreballador implements Runnable {

    private String tasca;

    public FilTreballador(String s) {
        this.tasca = s;
    }

    @Override
    public void run() {
        System.out.println(Thread.currentThread().getName() + " Inici Tasca = " + tasca);
        ProcessarTasca();
        Calendar calendario = new GregorianCalendar();
        System.out.println("Hora execució tasca: "
                + calendario.get(Calendar.HOUR_OF_DAY) + ":"
                + calendario.get(Calendar.MINUTE) + ":"
                + calendario.get(Calendar.SECOND));
        System.out.println(Thread.currentThread().getName() + " Tasca en execució.");
        System.out.println(Thread.currentThread().getName() + " Finalitza.");
    }

    private void ProcessarTasca() {
        try {
            Thread.sleep(4444);
        } catch (InterruptedException e) {
            System.out.println("Error!!");
        }
    }
}
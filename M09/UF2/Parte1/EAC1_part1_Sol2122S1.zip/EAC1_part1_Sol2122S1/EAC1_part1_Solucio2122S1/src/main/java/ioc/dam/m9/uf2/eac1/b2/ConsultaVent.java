/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ioc.dam.m9.uf2.eac1.b2;

/**
 *
 * @author tomas
 */
import java.util.concurrent.Callable;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

/**
 * Utilitza la pàgina web http://es.surf-forecast.com/
 * per consultar la força del vent a una platja de les
 * que es disposa informació. Cal proporcionar un 
 * codi de platja conegut per la web.
 * 
 * 
 */
public class ConsultaVent implements Callable<Integer>{
    private String mCodiPlatja;

    public ConsultaVent(String codiPlatja) {
        this.mCodiPlatja = codiPlatja;
    }
    
    @Override
    public Integer call() throws Exception {
        return ConsultaVent.forcaVent(this.mCodiPlatja);
    }
    
    /**
     * Funció que consulta a la pàgina web de la platja i 
     * n'extreu la velocitat actual del vent. 
     * NOTES: 
     *         - aquesta funció requereix connexió a Internet
     *         - està programada usant l' API JSoup.
     * 
     * @param codiPlatja és el codi de la platja de la que busquem el vent
     * @return la velocitat del vent en kilòmetres per hora
     */
    public static int forcaVent(String codiPlatja) {
        try {

            Document doc = Jsoup.connect("http://es.surf-forecast.com/breaks/" + codiPlatja + "/forecasts/feed/m").get();
            String title = doc.toString();
            
           /* Elements e = doc.select("#table-wind");
            for (Element km : e){
                
                System.out.println(km.text()+"sssssss");
            }*/
          
           Elements e = doc.select("#table-wind");
           
           String km=e.text();
            String[] kms = km.split(" ");
            String primer=kms[2];
            // Elements e = doc.select("#table-current");    
            //Elements e = doc.select("#table-wind .data-speed span");

            return Integer.parseInt(primer);

        } catch (Exception e) {
            e.printStackTrace();
            return -1;
        }
    }

    public String getCodiPlatja() {
        return mCodiPlatja;
    }

}

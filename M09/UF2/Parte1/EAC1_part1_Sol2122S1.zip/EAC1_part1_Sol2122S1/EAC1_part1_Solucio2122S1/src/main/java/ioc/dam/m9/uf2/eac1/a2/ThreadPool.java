/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ioc.dam.m9.uf2.eac1.a2;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 *
 * @author Usuari
 */
public class ThreadPool {

    public static void main(String[] args) {
        ExecutorService executor = Executors.newCachedThreadPool();
        for (int i = 0; i < 100; i++) {
            Runnable treballador = new FilTreballador("" + i);
            executor.execute(treballador);
        }
        executor.shutdown();
        while (!executor.isTerminated()) {
        }
        System.out.println("Tots els fils han finalitzat d'una forma correcta");
    }
}